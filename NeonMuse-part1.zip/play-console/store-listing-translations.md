# Neon Muse - translated Google Play listings (ready to paste)

In Play Console: Grow > Store presence > Main store listing > Manage translations > Add your own translations.
Pick each language below, paste the four fields, and save. The graphics can stay the same for every language.
The English listing is in store-listing.md. These translations were written with AI help, so have a native speaker skim them before launch if you can.

Limits: app name 30 characters, short description 80, full description 4,000, release notes 500.

---

## Japanese (ja-JP)

**App name**
Neon Muse: 放置系クリッカー

**Short description**
タップして召喚、美しいアニメのミューズを集めよう。広告なしの無料放置クリッカー。

**Full description**
Neon Museは無料のアニメ放置クリッカーです。タップでスパークを稼ぎ、世界にひとりだけのミューズを召喚し、着せ替えを楽しみながら、オフラインの間もコレクションを育てましょう。

タップ、強化、アセンド
• コンボを重ねるとフィーバーモードに突入、スパーク2倍
• 12段階の強化、ボーナスオーブ、フレンジー、オフライン収益
• アセンドで手に入るスターが、すべての収益を永久にアップ

無限に広がるミューズ召喚
• 召喚するたびに、名前・属性・カラー・称号・レア度・ボーナスがすべて新しいキャラクターが誕生。女性も男性も登場し、同じメンバーになるプレイヤーはいません。
• ツンデレ、クーデレから灯りの乙女、魔女、騎士まで15の属性
• コモンからミシックまで6つのレア度に、探しがいのあるシークレットレア
• 2人のミューズをフュージョンして、名前とオーラが混ざり合ったより強いキャラクターに
• 95項目の図鑑を埋めて永続ボーナス

ミューズには心がある
• ミューズにはそれぞれ個性があります。気分、好きなおやつ・プレゼント・デートスポット・天気は、あなたのゲームだけのもの。
• チョーカーの石が今の気分を表します。ごきげんなミューズは稼ぎが増え、プレゼントもくれます。
• おしゃべり、おやつ、デートで絆をレベル30まで深めよう。ごきげんなミューズはより高いレア度へ進化します。
• 光と闇、どちらへ導くかはあなた次第。天使の輪・光る瞳・純白の翼、または角・赤い瞳・傷あと・コウモリの翼。
• 魅力・機知・優しさ・いたずら・元気・センスの6つの性格ステータスが絆とともに成長し、収益をアップ。
• お願いごと、あなたへの質問、ミューズ同士のうわさ話。天気や祝日、あなたの誕生日にも反応します。
• 出会うのは女性か男性。いつでも変えられます。

毎日遊びたくなる仕掛け
• 毎日のログインボーナスと、続けるほど大きくなるボーナス
• デイリー・ウィークリーミッションで進める無料の月間ミューズパス
• 限定の「今月のミューズ」と、毎年完成させるアルバム
• リアルな季節と11の祝日イベント、それぞれに無料の祝日キャラクター
• 誕生日にはちょっとしたサプライズ
• チャレンジの連続達成で、ミシックの上の「セレスティアル」を獲得

ステージを自分好みに
• 500以上の衣装とカラーバリエーション
• 18種類のアニメ背景に加え、天気や昼夜で変わる生成シーン
• タップやコンボに合わせて盛り上がるシンセウェーブのサウンドトラック

自分のペースで遊べる
• 完全無料：広告なし、課金なし、アカウント不要
• オフライン対応、オートセーブとセーブスロット3つ
• 日本語を含む16言語に対応
• グラフィック、サウンド、左手レイアウトなど充実の設定
• 文字サイズ、ハイコントラスト、色覚に配慮したカラー、動きや点滅を減らす設定、スクリーンリーダー対応

Game by MREVILA55。遊んでくれてありがとう！

**Release notes**
1.6アップデート：新レアリティ「ゾンビ」登場！ ゾンビはどれも一点もので、色も名前もゾンビらしい性格も個性的。ホーム画面ウィジェットとGalaxy Watchの歩数タイルに対応。リーダーボード、シェアカード、友だちと一緒にもらえる招待特典も追加。すべてのミューズをHDで描き直し、新しいルックとステージ、迫力を増したフィーバー演出。リマインダーはお好みでオンに。端末の時計に合わせて、日の出から星空の夜まで移り変わる昼夜サイクル。プライバシーポリシーは初回起動時に表示され、いつでも設定から確認できます。

---

## Chinese, Simplified (zh-CN)

**App name**
Neon Muse：放置点击

**Short description**
点击、召唤、收集美丽的动漫缪斯。免费放置点击游戏，无广告。

**Full description**
Neon Muse 是一款免费的动漫放置点击游戏。点击赚取火花，召唤独一无二的缪斯，为她们换装，看着收藏不断壮大，离线时也一样。

点击、升级、飞升
• 连击会进入狂热模式，火花翻倍
• 12 级升级、奖励光球、狂暴爆发和离线收益
• 飞升获得星星，永久提升所有收益

无尽的缪斯召唤
• 每次召唤都会诞生一位全新角色，拥有自己的名字、属性、配色、称号、稀有度和加成，男女角色都有。每位玩家的阵容都独一无二。
• 15 种属性，从傲娇、冷娇到灯笼少女、魔女和骑士
• 从普通到神话共 6 种稀有度，还有隐藏稀有等你寻找
• 融合两位缪斯，得到名字与光环交融的更强角色
• 收集 95 条图鉴，获得永久加成

每位缪斯都有一颗心
• 每位缪斯都有自己的性格：心情、最爱的点心、礼物、约会地点和天气，都专属于你的游戏。
• 颈饰上的宝石显示她们的心情。开心的缪斯赚得更多，还会送你礼物。
• 聊天、分享点心、一起约会，把羁绊提升到 30 级。开心的缪斯会进化到更高的稀有度。
• 引导她们走向光明或黑暗：光环、发光的眼睛和洁白羽翼，或是犄角、红色的眼睛、伤疤和蝙蝠翅膀。
• 魅力、机智、善良、恶作剧、活力和品味六项性格属性会随羁绊成长，提升你的收益。
• 缪斯会许下心愿、问你问题、彼此八卦，还会对天气、节日和你的生日做出反应。
• 想遇见女性还是男性，由你决定，随时可改。

每天都想回来
• 每日连续登录礼物，坚持越久奖励越高
• 每日和每周任务，推进免费的月度缪斯通行证
• 专属的本月缪斯，以及每年可完成的相册
• 真实季节和 11 个节日，每个节日都有活动和免费节日角色
• 生日当天还有小惊喜
• 完成挑战连续纪录，解锁神话之上的天界角色

打造你的舞台
• 500 多套服装和配色可解锁
• 18 个动态动漫背景，以及带天气和昼夜光影的生成场景
• 随你的点击和连击而变化的合成波配乐

随心游玩
• 完全免费：无广告、无内购、无需账号
• 支持离线，自动存档并提供 3 个存档位
• 支持包括简体中文在内的 16 种语言
• 完整设置：画面、声音、左手布局等
• 无障碍选项：文字大小、高对比度、色盲友好配色、减少动态与闪烁、屏幕阅读器支持

Game by MREVILA55。感谢游玩！

**Release notes**
1.6 更新：全新稀有度“丧尸”登场！每位丧尸都独一无二，拥有自己的配色、名字和丧尸性格。新增主屏幕小组件和 Galaxy Watch 步数卡片。新增排行榜、分享卡片，以及让你和好友都能获得奖励的邀请。所有缪斯以高清重绘，新造型、新舞台，狂热特效更华丽。提醒可按需开启。新增昼夜循环：舞台随设备时钟从日出变换到星夜。隐私政策会在首次启动时显示，并可随时在设置中查看。

---

## Chinese, Traditional (zh-TW)

**App name**
Neon Muse：放置點擊

**Short description**
點擊、召喚、收集美麗的動漫繆思。免費放置點擊遊戲，沒有廣告。

**Full description**
Neon Muse 是一款免費的動漫放置點擊遊戲。點擊賺取火花，召喚獨一無二的繆思，幫她們換裝，看著收藏不斷擴大，離線時也一樣。

點擊、升級、飛昇
• 連擊會進入狂熱模式，火花加倍
• 12 階升級、獎勵光球、狂暴爆發和離線收益
• 飛昇獲得星星，永久提升所有收益

無盡的繆思召喚
• 每次召喚都會誕生一位全新角色，擁有自己的名字、屬性、配色、稱號、稀有度和加成，男女角色都有。每位玩家的陣容都獨一無二。
• 15 種屬性，從傲嬌、冷嬌到燈籠少女、魔女和騎士
• 從普通到神話共 6 種稀有度，還有隱藏稀有等你尋找
• 融合兩位繆思，得到名字與光環交融的更強角色
• 收集 95 條圖鑑，獲得永久加成

每位繆思都有一顆心
• 每位繆思都有自己的個性：心情、最愛的點心、禮物、約會地點和天氣，都專屬於你的遊戲。
• 頸飾上的寶石顯示她們的心情。開心的繆思賺得更多，還會送你禮物。
• 聊天、分享點心、一起約會，把羈絆提升到 30 級。開心的繆思會進化到更高的稀有度。
• 引導她們走向光明或黑暗：光環、發光的眼睛和潔白羽翼，或是犄角、紅色的眼睛、傷疤和蝙蝠翅膀。
• 魅力、機智、善良、惡作劇、活力和品味六項性格屬性會隨羈絆成長，提升你的收益。
• 繆思會許下心願、問你問題、彼此八卦，還會對天氣、節日和你的生日做出反應。
• 想遇見女性還是男性，由你決定，隨時可改。

每天都想回來
• 每日連續登入禮物，持續越久獎勵越高
• 每日和每週任務，推進免費的每月繆思通行證
• 專屬的本月繆思，以及每年可完成的相簿
• 真實季節和 11 個節日，每個節日都有活動和免費節日角色
• 生日當天還有小驚喜
• 完成挑戰連續紀錄，解鎖神話之上的天界角色

打造你的舞台
• 500 多套服裝和配色可解鎖
• 18 個動態動漫背景，以及帶有天氣和晝夜光影的生成場景
• 隨你的點擊和連擊而變化的合成波配樂

隨心遊玩
• 完全免費：沒有廣告、沒有內購、不需帳號
• 支援離線，自動存檔並提供 3 個存檔欄位
• 支援包含繁體中文在內的 16 種語言
• 完整設定：畫面、聲音、左手配置等
• 無障礙選項：文字大小、高對比、色盲友善配色、減少動態與閃爍、螢幕閱讀器支援

Game by MREVILA55。感謝遊玩！

**Release notes**
1.6 更新：全新稀有度「喪屍」登場！每位喪屍都獨一無二，擁有自己的配色、名字和喪屍性格。新增主畫面小工具和 Galaxy Watch 步數資訊卡。新增排行榜、分享卡片，以及讓你和好友都能獲得獎勵的邀請。所有繆斯以高畫質重繪，新造型、新舞台，狂熱特效更華麗。提醒可依需要開啟。新增晝夜循環：舞台隨裝置時鐘從日出變換到星夜。隱私權政策會在首次啟動時顯示，並可隨時在設定中查看。

---

## Korean (ko-KR)

**App name**
Neon Muse: 방치형 클리커

**Short description**
탭하고 소환해서 아름다운 애니 뮤즈를 모아 보세요. 광고 없는 무료 방치형 클리커.

**Full description**
Neon Muse는 무료 애니메이션 방치형 클리커입니다. 탭으로 스파크를 모으고, 세상에 하나뿐인 뮤즈를 소환하고, 옷을 갈아입히며 컬렉션을 키워 보세요. 접속하지 않는 동안에도 성장합니다.

탭, 강화, 승천
• 콤보를 쌓으면 피버 모드로 스파크 2배
• 12단계 강화, 보너스 오브, 광란 버스트, 오프라인 수익
• 승천으로 얻는 별이 모든 수익을 영구히 높여 줍니다

끝없는 뮤즈 소환
• 소환할 때마다 이름, 아키타입, 색상, 칭호, 등급, 보너스가 모두 새로운 캐릭터가 탄생합니다. 여성과 남성 캐릭터 모두 등장하며, 같은 멤버를 가진 플레이어는 없습니다.
• 츤데레, 쿨데레부터 등불 소녀, 마녀, 기사까지 15가지 아키타입
• 일반부터 신화까지 6단계 등급과 찾아내야 할 비밀 레어
• 뮤즈 두 명을 융합해 이름과 오라가 섞인 더 강한 캐릭터로
• 95개 항목의 도감을 채워 영구 보너스 획득

모든 뮤즈에게는 마음이 있어요
• 뮤즈마다 고유한 성격이 있어요. 기분, 좋아하는 간식·선물·데이트 장소·날씨가 당신의 게임에서만 새로 정해집니다.
• 초커의 보석이 지금 기분을 보여 줘요. 기분 좋은 뮤즈는 더 많이 벌어 주고 선물도 가져와요.
• 대화하고, 간식을 나누고, 데이트하며 유대를 30레벨까지 키우세요. 기분 좋은 뮤즈는 더 높은 등급으로 진화해요.
• 빛 또는 어둠으로 이끌어 보세요. 후광, 빛나는 눈, 깃털 날개 또는 뿔, 붉은 눈, 흉터, 박쥐 날개.
• 매력, 재치, 다정함, 장난, 활력, 스타일 여섯 가지 성격 스탯이 유대와 함께 성장하며 수익을 올려 줘요.
• 뮤즈는 소원을 빌고, 당신에 대해 묻고, 서로 수다를 떨며, 날씨와 기념일, 당신의 생일에도 반응해요.
• 여성 또는 남성과 만나세요. 언제든 바꿀 수 있어요.

매일 돌아오고 싶은 이유
• 매일 출석 선물과 꾸준히 할수록 커지는 보너스
• 일일·주간 미션으로 채우는 무료 월간 뮤즈 패스
• 한정 이달의 뮤즈와 매년 완성하는 앨범
• 실제 계절과 11가지 기념일 이벤트, 기념일마다 무료 캐릭터
• 생일에는 작은 깜짝 선물
• 챌린지 연속 달성으로 신화 위의 천상 등급 캐릭터 획득

나만의 무대 꾸미기
• 500개 이상의 의상과 색상 변형
• 18가지 애니메이션 배경과 날씨, 낮과 밤 조명이 바뀌는 생성 장면
• 탭과 콤보에 맞춰 달아오르는 신스웨이브 사운드트랙

내 방식대로 플레이
• 100% 무료: 광고 없음, 결제 없음, 계정 불필요
• 오프라인 플레이, 자동 저장과 저장 슬롯 3개
• 한국어를 포함한 16개 언어 지원
• 그래픽, 사운드, 왼손 레이아웃 등 다양한 설정
• 접근성 옵션: 글자 크기, 고대비, 색각 이상 친화 색상, 움직임·깜빡임 줄이기, 스크린 리더 지원

Game by MREVILA55. 플레이해 주셔서 감사합니다!

**Release notes**
1.6 업데이트: 새 등급 '좀비' 등장! 모든 좀비는 고유한 색, 이름, 좀비다운 성격을 가진 단 하나뿐인 변종이에요. 홈 화면 위젯과 갤럭시 워치 걸음 수 타일이 추가됐어요. 리더보드, 공유 카드, 친구와 함께 보상받는 초대도 생겼어요. 모든 뮤즈를 HD로 새로 그리고, 새 룩과 스테이지, 더 화려한 피버 효과를 더했어요. 알림은 원할 때만 켜세요. 기기 시계에 맞춰 해돋이부터 별이 빛나는 밤까지 바뀌는 낮과 밤. 개인정보처리방침은 처음 실행할 때 표시되며 언제든 설정에서 볼 수 있어요.

---

## Spanish (es-419 and es-ES)

**App name**
Neon Muse: Clicker idle

**Short description**
Toca, invoca y colecciona musas anime. Clicker idle gratis y sin anuncios.

**Full description**
Neon Muse es un clicker idle anime gratuito. Toca para ganar chispas, invoca musas únicas, vístelas y mira cómo crece tu colección, incluso cuando no estás jugando.

TOCA, MEJORA, ASCIENDE
• Combos que activan el modo Fiebre con chispas dobles
• 12 niveles de mejoras, orbes de bonificación, frenesí y ganancias sin conexión
• Asciende para conseguir Estrellas que aumentan para siempre todo lo que ganas

MUSAS SIN FIN
• Cada invocación crea un personaje totalmente nuevo, mujer u hombre, con su propio nombre, arquetipo, colores, título, rareza y bonificación. No hay dos jugadores con el mismo elenco.
• 15 arquetipos, desde tsundere y kuudere hasta doncella de los faroles, bruja y caballera
• Seis rarezas, de Común a Mítica, y rarezas secretas por descubrir
• Fusiona dos musas en una fusión más fuerte, con un nombre combinado y un aura brillante
• Completa las 95 entradas del Códice para obtener bonificaciones permanentes

CADA MUSA TIENE CORAZÓN
• Cada musa tiene su propia personalidad: estados de ánimo, golosinas, regalos, lugares de cita y clima favoritos, creados para tu partida.
• Un collar del ánimo muestra cómo se siente. Las musas felices generan más y te traen regalos.
• Charla, comparte golosinas, sal en citas y sube su vínculo hasta el nivel 30. Las musas felices evolucionan a rarezas superiores.
• Llévalas hacia la Luz o la Sombra: halos, ojos brillantes y alas de plumas, o cuernos, ojos rojos, cicatrices y alas de murciélago.
• Seis estadísticas de personalidad (Encanto, Ingenio, Bondad, Travesura, Energía y Estilo) crecen con su vínculo y aumentan tus ganancias.
• Las musas piden deseos, te hacen preguntas, chismean entre ellas y reaccionan al clima, las fiestas y tu cumpleaños.
• Conoce mujeres u hombres. Tú eliges, cuando quieras.

UN MOTIVO PARA VOLVER
• Regalos de racha diaria y una bonificación que crece cada día que juegas
• Misiones diarias y semanales que llenan un Pase Musa mensual gratuito
• Una Musa del mes exclusiva y un álbum anual por completar
• Estaciones reales y 11 festividades, cada una con su evento y un personaje gratis
• Una sorpresa el día de tu cumpleaños
• Rachas de desafíos que desbloquean Celestiales, el nivel por encima de Mítico

DECORA TU ESCENARIO
• Más de 500 atuendos y variaciones de color para desbloquear
• 18 fondos anime animados, además de escenas generadas con clima e iluminación de día a noche
• Una banda sonora synthwave que se anima con tus toques y combos

JUEGA A TU MANERA
• 100 % gratis: sin anuncios, sin compras y sin cuenta
• Funciona sin conexión, con guardado automático y 3 ranuras de guardado
• Disponible en 16 idiomas, incluido el español
• Ajustes completos: gráficos, sonido, diseño para zurdos y más
• Accesibilidad: texto más grande, alto contraste, colores aptos para daltonismo, menos movimiento y destellos, y compatibilidad con lectores de pantalla

Game by MREVILA55. ¡Gracias por jugar!

**Release notes**
Actualización 1.6: ¡llegan los Zombis! Una rareza nueva: cada zombi es una variante única con sus propios colores, nombre y personalidad. Nuevos widgets para la pantalla de inicio y un mosaico de pasos para Galaxy Watch. Clasificaciones, tarjetas para compartir e invitaciones con premios para ti y tus amigos. Musas redibujadas en HD, nuevos looks y escenarios, y más efectos de Fiebre. Recordatorios opcionales. Ciclo de día y noche según tu reloj, del amanecer a la noche estrellada.

---

## Portuguese, Brazil (pt-BR)

**App name**
Neon Muse: Clicker idle

**Short description**
Toque, invoque e colecione musas de anime. Clicker idle grátis e sem anúncios.

**Full description**
Neon Muse é um clicker idle de anime gratuito. Toque para ganhar faíscas, invoque musas únicas, monte o visual delas e veja sua coleção crescer, mesmo quando você não está jogando.

TOQUE, MELHORE, ASCENDA
• Combos que ativam o modo Febre com faíscas em dobro
• 12 níveis de melhorias, orbes de bônus, frenesi e ganhos offline
• Ascenda para ganhar Estrelas que aumentam tudo o que você ganha para sempre

MUSAS SEM FIM
• Cada invocação cria um personagem totalmente novo, mulher ou homem, com nome, arquétipo, cores, título, raridade e bônus próprios. Nenhum jogador tem o mesmo elenco.
• 15 arquétipos, de tsundere e kuudere a donzela das lanternas, bruxa e cavaleira
• Seis raridades, de Comum a Mítica, e raridades secretas para descobrir
• Funda duas musas em uma fusão mais forte, com nome combinado e aura brilhante
• Complete as 95 entradas do Códice para ganhar bônus permanentes

CADA MUSA TEM UM CORAÇÃO
• Cada musa tem sua própria personalidade: humor, doces, presentes, lugares de encontro e clima favoritos, criados para o seu jogo.
• Uma gargantilha do humor mostra como ela se sente. Musas felizes rendem mais e trazem presentes.
• Converse, divida doces, saia em encontros e aumente o vínculo até o nível 30. Musas felizes evoluem para raridades maiores.
• Leve-as para a Luz ou a Sombra: auréolas, olhos brilhantes e asas de penas, ou chifres, olhos vermelhos, cicatrizes e asas de morcego.
• Seis atributos de personalidade (Charme, Esperteza, Bondade, Travessura, Energia e Estilo) crescem com o vínculo e aumentam seus ganhos.
• As musas fazem pedidos, perguntam sobre você, fofocam umas das outras e reagem ao clima, aos feriados e ao seu aniversário.
• Conheça mulheres ou homens. Você escolhe, quando quiser.

UM MOTIVO PARA VOLTAR
• Presentes de sequência diária e um bônus que cresce a cada dia jogado
• Missões diárias e semanais que enchem um Passe Musa mensal gratuito
• Uma Musa do mês exclusiva e um álbum anual para completar
• Estações reais e 11 datas comemorativas, cada uma com evento e personagem grátis
• Uma surpresa no dia do seu aniversário
• Sequências de desafios que liberam Celestiais, o nível acima de Mítico

MONTE SEU PALCO
• Mais de 500 roupas e variações de cor para desbloquear
• 18 cenários de anime animados, além de cenas geradas com clima e iluminação do dia à noite
• Uma trilha synthwave que se anima com seus toques e combos

JOGUE DO SEU JEITO
• 100% grátis: sem anúncios, sem compras e sem conta
• Funciona offline, com salvamento automático e 3 espaços de save
• Disponível em 16 idiomas, incluindo português
• Configurações completas: gráficos, som, layout para canhotos e mais
• Acessibilidade: texto maior, alto contraste, cores para daltonismo, menos movimento e clarões, e suporte a leitores de tela

Game by MREVILA55. Obrigado por jogar!

**Release notes**
Atualização 1.6: chegaram os Zumbis! Uma raridade nova, e cada zumbi é uma variante única, com cores, nome e personalidade de zumbi. Novos widgets para a tela inicial e um bloco de passos no Galaxy Watch. Placares, cartões para compartilhar e convites com recompensas para você e seus amigos. Musas redesenhadas em HD, novos visuais e cenários, e efeitos de Febre maiores. Lembretes opcionais. Ciclo de dia e noite que segue seu relógio, do nascer do sol à noite estrelada.

---

## French (fr-FR)

**App name**
Neon Muse : Clicker idle

**Short description**
Tapotez, invoquez et collectionnez des muses anime. Clicker idle gratuit.

**Full description**
Neon Muse est un clicker idle anime gratuit. Tapotez pour gagner des étincelles, invoquez des muses uniques, habillez-les et regardez votre collection grandir, même quand vous n'êtes pas là.

TAPOTEZ, AMÉLIOREZ, ÉLEVEZ-VOUS
• Des combos qui déclenchent le mode Fièvre avec étincelles doublées
• 12 paliers d'améliorations, orbes bonus, frénésie et gains hors ligne
• Élevez-vous pour obtenir des Étoiles qui boostent vos gains pour toujours

DES MUSES À L'INFINI
• Chaque invocation crée un personnage tout neuf, femme ou homme, avec son nom, son archétype, ses couleurs, son titre, sa rareté et son bonus. Aucun joueur n'a la même équipe.
• 15 archétypes, de la tsundere à la kuudere en passant par la demoiselle aux lanternes, la sorcière et la chevalière
• Six raretés, de Commune à Mythique, et des raretés secrètes à dénicher
• Fusionnez deux muses en une fusion plus puissante, au nom mêlé et à l'aura éclatante
• Remplissez les 95 entrées du Codex pour des bonus permanents

CHAQUE MUSE A UN CŒUR
• Chaque muse a sa personnalité : humeurs, friandises, cadeaux, lieux de rendez-vous et météo préférés, créés pour votre partie.
• Un collier d'humeur montre ce qu'elle ressent. Les muses heureuses rapportent plus et vous offrent des cadeaux.
• Discutez, partagez des friandises, sortez en rendez-vous et faites grandir le lien jusqu'au niveau 30. Les muses heureuses évoluent vers des raretés supérieures.
• Menez-les vers la Lumière ou l'Ombre : auréoles, yeux lumineux et ailes de plumes, ou cornes, yeux rouges, cicatrices et ailes de chauve-souris.
• Six stats de personnalité (Charme, Esprit vif, Gentillesse, Bêtise, Énergie et Style) grandissent avec le lien et augmentent vos gains.
• Les muses font des vœux, vous posent des questions, papotent entre elles et réagissent à la météo, aux fêtes et à votre anniversaire.
• Rencontrez des femmes ou des hommes. À vous de choisir, à tout moment.

UNE RAISON DE REVENIR
• Des cadeaux de série quotidienne et un bonus qui grandit chaque jour de jeu
• Des missions quotidiennes et hebdomadaires qui remplissent un Pass Muse mensuel gratuit
• Une Muse du mois exclusive et un album annuel à compléter
• De vraies saisons et 11 fêtes, chacune avec son événement et un personnage offert
• Une surprise le jour de votre anniversaire
• Des séries de défis qui débloquent les Célestes, le rang au-dessus de Mythique

SUBLIMEZ VOTRE SCÈNE
• Plus de 500 tenues et variantes de couleur à débloquer
• 18 décors anime animés, plus des scènes générées avec météo et lumière du jour à la nuit
• Une bande-son synthwave qui s'emballe avec vos touches et vos combos

JOUEZ À VOTRE FAÇON
• 100 % gratuit : sans pub, sans achat, sans compte
• Fonctionne hors ligne, avec sauvegarde automatique et 3 emplacements
• Disponible en 16 langues, dont le français
• Réglages complets : graphismes, son, disposition pour gauchers et plus
• Accessibilité : texte agrandi, contraste élevé, couleurs adaptées au daltonisme, moins d'animations et de flashs, compatibilité avec les lecteurs d'écran

Game by MREVILA55. Merci de jouer !

**Release notes**
Mise à jour 1.6 : voici les Zombies ! Une nouvelle rareté : chaque zombie est une variante unique avec ses couleurs, son nom et sa personnalité. Nouveaux widgets pour l'écran d'accueil et une vignette de pas sur Galaxy Watch. Classements, cartes à partager et invitations récompensant toi et tes amis. Muses redessinées en HD, nouveaux looks et décors, effets de Fièvre plus forts. Rappels facultatifs. Cycle jour-nuit qui suit ton horloge, du lever du soleil à la nuit étoilée.

---

## German (de-DE)

**App name**
Neon Muse: Idle-Clicker

**Short description**
Tippen, beschwören, sammeln: Anime-Musen. Gratis Idle-Clicker ohne Werbung.

**Full description**
Neon Muse ist ein kostenloser Anime-Idle-Clicker. Tippe, um Funken zu verdienen, beschwöre einzigartige Musen, style sie und sieh zu, wie deine Sammlung wächst, auch wenn du gerade nicht spielst.

TIPPEN, VERBESSERN, AUFSTEIGEN
• Combos, die in den Fieber-Modus mit doppelten Funken münden
• 12 Upgrade-Stufen, Bonuskugeln, Raserei-Schübe und Offline-Einnahmen
• Steige auf und erhalte Sterne, die alle Einnahmen dauerhaft steigern

ENDLOSE MUSEN
• Jede Beschwörung erschafft eine brandneue Figur, Frau oder Mann, mit eigenem Namen, Archetyp, Farben, Titel, Seltenheit und Bonus. Keine zwei Spieler haben dieselbe Besetzung.
• 15 Archetypen, von Tsundere und Kuudere bis Laternenmädchen, Hexe und Ritterin
• Sechs Seltenheiten von Gewöhnlich bis Mythisch, dazu geheime Raritäten zum Aufspüren
• Verschmelze zwei Musen zu einer stärkeren Fusion mit gemischtem Namen und leuchtender Aura
• Fülle die 95 Einträge im Kodex für dauerhafte Boni

JEDE MUSE HAT EIN HERZ
• Jede Muse hat ihre eigene Persönlichkeit: Stimmungen, Lieblingsleckereien, Geschenke, Date-Orte und Wetter, neu erstellt für dein Spiel.
• Ein Stimmungs-Choker zeigt, wie sie sich fühlt. Glückliche Musen bringen mehr ein und machen dir Geschenke.
• Plaudere, teile Leckereien, geh auf Dates und steigere eure Bindung bis Stufe 30. Glückliche Musen entwickeln sich zu höheren Seltenheiten.
• Führe sie ins Licht oder in den Schatten: Heiligenscheine, leuchtende Augen und Federflügel oder Hörner, rote Augen, Narben und Fledermausflügel.
• Sechs Persönlichkeitswerte (Charme, Witz, Güte, Unfug, Energie und Stil) wachsen mit eurer Bindung und steigern deine Einnahmen.
• Musen äußern Wünsche, fragen nach dir, tratschen übereinander und reagieren auf Wetter, Feiertage und deinen Geburtstag.
• Triff Frauen oder Männer. Du entscheidest, jederzeit.

EIN GRUND ZURÜCKZUKOMMEN
• Geschenke für deine tägliche Serie und ein Bonus, der mit jedem Spieltag wächst
• Tägliche und wöchentliche Missionen für einen kostenlosen monatlichen Musen-Pass
• Eine exklusive Muse des Monats und ein Jahresalbum zum Vervollständigen
• Echte Jahreszeiten und 11 Feiertage, jeder mit eigenem Event und einer Gratis-Figur
• Eine Überraschung an deinem Geburtstag
• Herausforderungs-Serien, die Himmlische freischalten, die Stufe über Mythisch

DEINE BÜHNE
• Über 500 Outfits und Farbvarianten zum Freischalten
• 18 animierte Anime-Hintergründe, dazu generierte Szenen mit Wetter und Tag-Nacht-Licht
• Ein Synthwave-Soundtrack, der mit deinen Taps und Combos mitgeht

SPIEL, WIE DU WILLST
• 100 % kostenlos: keine Werbung, keine Käufe, kein Konto
• Funktioniert offline, mit automatischem Speichern und 3 Speicherplätzen
• In 16 Sprachen verfügbar, auch auf Deutsch
• Umfangreiche Einstellungen: Grafik, Ton, Linkshänder-Layout und mehr
• Barrierefreiheit: größere Schrift, hoher Kontrast, farbenblind-freundliche Farben, weniger Bewegung und Blitze, Screenreader-Unterstützung

Game by MREVILA55. Danke fürs Spielen!

**Release notes**
Update 1.6: Die Zombies sind da! Eine neue Seltenheit, und jeder Zombie ist eine einzigartige Variante mit eigenen Farben, Namen und Charakter. Neue Startbildschirm-Widgets und eine Schritte-Kachel für die Galaxy Watch. Bestenlisten, Teilkarten und Einladungen mit Belohnungen für dich und deine Freunde. Alle Musen neu in HD, neue Looks und Bühnen, größere Fieber-Effekte. Erinnerungen nur, wenn du willst. Ein Tag-Nacht-Wechsel nach deiner Uhr, vom Sonnenaufgang bis zur Sternennacht.

---

## Italian (it-IT)

**App name**
Neon Muse: Clicker idle

**Short description**
Tocca, evoca e colleziona muse anime. Clicker idle gratis e senza pubblicità.

**Full description**
Neon Muse è un clicker idle anime gratuito. Tocca per guadagnare scintille, evoca muse uniche, vestile come preferisci e guarda la tua collezione crescere, anche quando non giochi.

TOCCA, POTENZIA, ASCENDI
• Combo che attivano la modalità Febbre con scintille doppie
• 12 livelli di potenziamenti, sfere bonus, frenesia e guadagni offline
• Ascendi per ottenere Stelle che aumentano per sempre tutti i guadagni

MUSE SENZA FINE
• Ogni evocazione crea un personaggio tutto nuovo, donna o uomo, con nome, archetipo, colori, titolo, rarità e bonus propri. Nessun giocatore ha lo stesso cast.
• 15 archetipi, dalla tsundere alla kuudere fino a fanciulla delle lanterne, strega e cavaliera
• Sei rarità, da Comune a Mitico, e rarità segrete da scovare
• Fondi due muse in una fusione più forte, con un nome misto e un'aura luminosa
• Completa le 95 voci del Codex per bonus permanenti

OGNI MUSA HA UN CUORE
• Ogni musa ha la sua personalità: umori, dolcetti, regali, luoghi per appuntamenti e meteo preferiti, creati per la tua partita.
• Un girocollo dell'umore mostra come si sente. Le muse felici rendono di più e ti portano regali.
• Chiacchiera, condividi dolcetti, esci per appuntamenti e fai crescere il legame fino al livello 30. Le muse felici si evolvono a rarità più alte.
• Guidale verso la Luce o l'Ombra: aureole, occhi luminosi e ali piumate, oppure corna, occhi rossi, cicatrici e ali di pipistrello.
• Sei statistiche di personalità (Fascino, Arguzia, Gentilezza, Marachella, Energia e Stile) crescono con il legame e aumentano i tuoi guadagni.
• Le muse esprimono desideri, ti fanno domande, spettegolano tra loro e reagiscono al meteo, alle feste e al tuo compleanno.
• Incontra donne o uomini. Scegli tu, quando vuoi.

UN MOTIVO PER TORNARE
• Regali per la serie giornaliera e un bonus che cresce ogni giorno di gioco
• Missioni giornaliere e settimanali che riempiono un Pass Musa mensile gratuito
• Un'esclusiva Musa del mese e un album annuale da completare
• Stagioni reali e 11 feste, ognuna con il suo evento e un personaggio gratis
• Una sorpresa nel giorno del tuo compleanno
• Serie di sfide che sbloccano i Celestiali, il livello sopra il Mitico

IL TUO PALCO
• Oltre 500 outfit e varianti di colore da sbloccare
• 18 sfondi anime animati, più scene generate con meteo e luce dal giorno alla notte
• Una colonna sonora synthwave che si accende con i tuoi tocchi e le tue combo

GIOCA COME VUOI
• 100% gratis: niente pubblicità, niente acquisti, niente account
• Funziona offline, con salvataggio automatico e 3 slot di salvataggio
• Disponibile in 16 lingue, italiano compreso
• Impostazioni complete: grafica, audio, layout per mancini e altro
• Accessibilità: testo più grande, contrasto elevato, colori adatti al daltonismo, meno movimento e lampeggi, supporto per screen reader

Game by MREVILA55. Grazie per aver giocato!

**Release notes**
Aggiornamento 1.6: arrivano gli Zombie! Una nuova rarità, e ogni zombie è una variante unica con colori, nome e personalità da zombie. Nuovi widget per la schermata Home e un riquadro dei passi per Galaxy Watch. Classifiche, card da condividere e inviti con premi per te e i tuoi amici. Muse ridisegnate in HD, nuovi look e scenari, effetti Febbre più spettacolari. Promemoria facoltativi. Ciclo giorno e notte che segue il tuo orologio, dall'alba alla notte stellata.

---

## Russian (ru-RU)

**App name**
Neon Muse: idle-кликер

**Short description**
Касайтесь, призывайте и собирайте прекрасных аниме-муз. Бесплатный idle-кликер.

**Full description**
Neon Muse — бесплатный аниме idle-кликер. Касайтесь экрана, чтобы зарабатывать искры, призывайте уникальных муз, наряжайте их и смотрите, как растёт ваша коллекция, даже когда вас нет в игре.

КАСАНИЯ, УЛУЧШЕНИЯ, ВОЗНЕСЕНИЕ
• Комбо, переходящие в режим лихорадки с двойными искрами
• 12 уровней улучшений, бонусные сферы, всплески безумия и офлайн-доход
• Возносясь, вы получаете Звёзды, которые навсегда увеличивают весь доход

БЕСКОНЕЧНЫЕ МУЗЫ
• Каждый призыв создаёт совершенно нового персонажа, женщину или мужчину, со своим именем, архетипом, цветами, титулом, редкостью и бонусом. Ни у кого нет такого же состава.
• 15 архетипов: от цундэрэ и кудэрэ до девы фонарей, ведьмы и рыцаря
• Шесть редкостей от обычной до мифической и секретные редкости, которые нужно найти
• Объединяйте двух муз в более сильное слияние со смешанным именем и сияющей аурой
• Заполните 95 записей Кодекса ради постоянных бонусов

У КАЖДОЙ МУЗЫ ЕСТЬ СЕРДЦЕ
• У каждой Музы свой характер: настроение, любимые угощения, подарки, места для свиданий и погода — всё создаётся для вашей игры.
• Камень на чокере показывает настроение. Радостные Музы приносят больше дохода и дарят подарки.
• Разговаривайте, угощайте, ходите на свидания и укрепляйте связь до 30-го уровня. Радостные Музы эволюционируют до более высокой редкости.
• Ведите их к Свету или Тьме: нимб, сияющие глаза и пернатые крылья — или рога, красные глаза, шрамы и крылья летучей мыши.
• Шесть черт характера (Обаяние, Остроумие, Доброта, Шалость, Энергия и Стиль) растут вместе со связью и увеличивают ваш доход.
• Музы загадывают желания, расспрашивают о вас, сплетничают друг о друге и реагируют на погоду, праздники и ваш день рождения.
• Знакомьтесь с женщинами или мужчинами. Выбор за вами, в любой момент.

ПОВОД ВОЗВРАЩАТЬСЯ
• Подарки за ежедневную серию и бонус, который растёт с каждым днём игры
• Ежедневные и еженедельные задания для бесплатного месячного Пропуска Музы
• Эксклюзивная Муза месяца и годовой альбом для коллекции
• Настоящие сезоны и 11 праздников, у каждого своё событие и бесплатная героиня
• Сюрприз в ваш день рождения
• Серии испытаний, открывающие Небесных — ранг выше Мифического

ВАША СЦЕНА
• Более 500 нарядов и цветовых вариантов
• 18 анимированных аниме-фонов и генерируемые сцены с погодой и сменой дня и ночи
• Синтвейв-саундтрек, который заводится от ваших нажатий и комбо

ИГРАЙТЕ ПО-СВОЕМУ
• Полностью бесплатно: без рекламы, без покупок, без аккаунта
• Работает офлайн, с автосохранением и 3 слотами сохранения
• 16 языков, включая русский
• Подробные настройки: графика, звук, раскладка для левшей и не только
• Специальные возможности: крупный текст, высокий контраст, цвета для дальтоников, меньше движения и вспышек, поддержка экранного диктора

Game by MREVILA55. Спасибо, что играете!

**Release notes**
Обновление 1.6: пришли Зомби! Новая редкость, и каждый зомби — уникальный вариант со своими цветами, именем и характером. Новые виджеты для главного экрана и плитка шагов для Galaxy Watch. Таблицы лидеров, карточки для публикации и приглашения с наградами для вас и друзей. Все Музы перерисованы в HD, новые образы и сцены, яркие эффекты жара. Напоминания — по желанию. Смена дня и ночи по вашим часам — от рассвета до звёздной ночи.

---

## Polish (pl-PL)

**App name**
Neon Muse: Idle Clicker

**Short description**
Dotykaj, przywołuj i zbieraj piękne muzy anime. Darmowy idle clicker bez reklam.

**Full description**
Neon Muse to darmowy idle clicker w stylu anime. Dotykaj, by zdobywać iskry, przywołuj niepowtarzalne muzy, ubieraj je i patrz, jak rośnie twoja kolekcja, nawet gdy nie grasz.

DOTYKAJ, ULEPSZAJ, WZNOŚ SIĘ
• Combo, które przechodzą w tryb gorączki z podwójnymi iskrami
• 12 poziomów ulepszeń, kule bonusowe, wybuchy szału i zarobki offline
• Wznieś się, by zdobyć Gwiazdy, które na zawsze zwiększają wszystkie zarobki

NIESKOŃCZONE MUZY
• Każde przywołanie tworzy zupełnie nową postać, kobietę lub mężczyznę, z własnym imieniem, archetypem, kolorami, tytułem, rzadkością i bonusem. Żaden gracz nie ma takiej samej obsady.
• 15 archetypów, od tsundere i kuudere po pannę latarni, wiedźmę i rycerkę
• Sześć rzadkości od zwykłej do mitycznej oraz sekretne rzadkości do odkrycia
• Połącz dwie muzy w silniejszą fuzję z połączonym imieniem i lśniącą aurą
• Wypełnij 95 wpisów Kodeksu, by zdobyć stałe bonusy

KAŻDA MUZA MA SERCE
• Każda Muza ma własną osobowość: nastroje, ulubione smakołyki, prezenty, miejsca na randki i pogodę, tworzone dla twojej gry.
• Choker nastroju pokazuje, jak się czuje. Szczęśliwe Muzy zarabiają więcej i przynoszą prezenty.
• Rozmawiaj, dziel się smakołykami, chodź na randki i rozwijaj więź aż do poziomu 30. Szczęśliwe Muzy ewoluują do wyższej rzadkości.
• Prowadź je ku Światłu albo Cieniowi: aureole, świecące oczy i pierzaste skrzydła albo rogi, czerwone oczy, blizny i skrzydła nietoperza.
• Sześć cech osobowości (Urok, Błyskotliwość, Życzliwość, Psota, Energia i Styl) rośnie razem z więzią i zwiększa twoje zarobki.
• Muzy wypowiadają życzenia, pytają o ciebie, plotkują o sobie nawzajem i reagują na pogodę, święta i twoje urodziny.
• Poznawaj kobiety albo mężczyzn. Ty wybierasz, w każdej chwili.

POWÓD, BY WRACAĆ
• Prezenty za codzienną serię i bonus rosnący z każdym dniem gry
• Misje dzienne i tygodniowe wypełniające darmowy miesięczny Karnet Muzy
• Ekskluzywna Muza miesiąca i roczny album do skompletowania
• Prawdziwe pory roku i 11 świąt, każde z wydarzeniem i darmową postacią
• Niespodzianka w dniu twoich urodzin
• Serie wyzwań, które odblokowują Niebiańskie postacie, rangę ponad Mityczną

TWOJA SCENA
• Ponad 500 strojów i wariantów kolorystycznych do odblokowania
• 18 animowanych teł anime oraz generowane sceny z pogodą i światłem od dnia do nocy
• Synthwave'owa ścieżka dźwiękowa, która nakręca się z twoimi stuknięciami i combo

GRAJ PO SWOJEMU
• W 100% za darmo: bez reklam, bez zakupów, bez konta
• Działa offline, z autozapisem i 3 slotami zapisu
• 16 języków, w tym polski
• Pełne ustawienia: grafika, dźwięk, układ dla leworęcznych i więcej
• Dostępność: większy tekst, wysoki kontrast, kolory dla daltonistów, mniej ruchu i błysków, obsługa czytników ekranu

Game by MREVILA55. Dzięki za grę!

**Release notes**
Aktualizacja 1.6: nadchodzą Zombie! Nowa rzadkość, a każde zombie to jedyny w swoim rodzaju wariant z własnymi kolorami, imieniem i charakterem. Nowe widżety na ekran główny i kafelek kroków na Galaxy Watch. Rankingi, karty do udostępniania i zaproszenia z nagrodami dla ciebie i znajomych. Muzy narysowane na nowo w HD, nowe wyglądy i sceny, większe efekty Gorączki. Przypomnienia tylko na życzenie. Cykl dnia i nocy zgodny z twoim zegarem, od wschodu słońca po gwiaździstą noc.

---

## Turkish (tr-TR)

**App name**
Neon Muse: Idle Clicker

**Short description**
Dokun, çağır, anime ilham perilerini topla. Reklamsız, ücretsiz idle oyun.

**Full description**
Neon Muse ücretsiz bir anime idle clicker oyunudur. Kıvılcım kazanmak için dokun, eşsiz ilham perileri çağır, onları giydir ve sen oyunda değilken bile koleksiyonunun büyümesini izle.

DOKUN, GELİŞTİR, YÜKSEL
• Çift kıvılcımlı Coşku moduna dönüşen kombolar
• 12 geliştirme kademesi, bonus küreler, çılgınlık patlamaları ve çevrimdışı kazanç
• Yüksel ve tüm kazancını kalıcı olarak artıran Yıldızları topla

SONSUZ İLHAM PERİSİ
• Her çağırma kendi adı, arketipi, renkleri, unvanı, nadirliği ve bonusu olan yepyeni bir karakter yaratır; kadın da olabilir erkek de. Hiçbir oyuncunun kadrosu aynı değildir.
• Tsundere ve Kuudere'den fener kızı, cadı ve şövalyeye 15 arketip
• Sıradan'dan Mitik'e altı nadirlik ve bulunmayı bekleyen gizli nadirler
• İki ilham perisini birleştirip karışık isimli, parlayan auralı daha güçlü bir füzyon oluştur
• Kalıcı bonuslar için 95 kayıtlık Kodeksi doldur

HER İLHAM PERİSİNİN BİR KALBİ VAR
• Her İlham Perisinin kendine özgü bir kişiliği var: ruh hali, en sevdiği ikramlar, hediyeler, randevu yerleri ve hava, senin oyunun için oluşturulur.
• Ruh hali gerdanlığı nasıl hissettiğini gösterir. Mutlu İlham Perileri daha çok kazandırır ve sana hediye getirir.
• Sohbet et, ikram paylaş, randevuya çık ve bağınızı 30. seviyeye kadar büyüt. Mutlu İlham Perileri daha nadir kademelere evrimleşir.
• Onları Işığa ya da Gölgeye yönlendir: haleler, parlayan gözler ve tüylü kanatlar ya da boynuzlar, kırmızı gözler, yara izleri ve yarasa kanatları.
• Altı kişilik özelliği (Çekicilik, Zekâ, İyilik, Yaramazlık, Enerji ve Tarz) bağınızla birlikte büyür ve kazancını artırır.
• İlham Perileri dilek tutar, seni sorar, birbirleri hakkında dedikodu yapar; havaya, bayramlara ve doğum gününe tepki verir.
• Kadınlarla ya da erkeklerle tanış. Seçim senin, istediğin zaman.

GERİ DÖNMEK İÇİN BİR NEDEN
• Günlük seri hediyeleri ve oynadığın her gün büyüyen bir bonus
• Ücretsiz aylık İlham Perisi Biletini dolduran günlük ve haftalık görevler
• Özel Ayın İlham Perisi ve her yıl tamamlanacak bir albüm
• Gerçek mevsimler ve her biri kendi etkinliği ve ücretsiz karakteriyle 11 bayram
• Doğum gününde küçük bir sürpriz
• Mitik'in üstündeki Gökselleri açan meydan okuma serileri

SAHNENİ SÜSLE
• Açılacak 500'den fazla kıyafet ve renk çeşidi
• 18 hareketli anime arka planı, ayrıca hava durumu ve gündüz-gece ışığıyla üretilen sahneler
• Dokunuşlarına ve kombolarına göre coşan bir synthwave müzik

İSTEDİĞİN GİBİ OYNA
• %100 ücretsiz: reklam yok, satın alma yok, hesap yok
• Çevrimdışı çalışır, otomatik kayıt ve 3 kayıt yuvası
• Türkçe dahil 16 dil
• Kapsamlı ayarlar: grafik, ses, solak düzeni ve daha fazlası
• Erişilebilirlik: büyük yazı, yüksek kontrast, renk körlüğüne uygun renkler, daha az hareket ve yanıp sönme, ekran okuyucu desteği

Game by MREVILA55. Oynadığın için teşekkürler!

**Release notes**
1.6 güncellemesi: Zombiler geldi! Yeni bir nadirlik ve her zombi kendi renkleri, adı ve zombi kişiliğiyle eşsiz bir varyant. Yeni ana ekran widget'ları ve Galaxy Watch adım kutucuğu. Liderlik tabloları, paylaşım kartları ve sana ve arkadaşlarına ödül kazandıran davetler. Tüm İlham Perileri HD olarak yeniden çizildi, yeni görünümler ve sahneler, daha büyük Ateş efektleri. İsteğe bağlı hatırlatmalar. Saatine göre değişen gece-gündüz döngüsü: gün doğumundan yıldızlı geceye.

---

## Indonesian (id)

**App name**
Neon Muse: Idle Clicker

**Short description**
Ketuk, panggil, dan koleksi muse anime. Idle clicker gratis tanpa iklan.

**Full description**
Neon Muse adalah game idle clicker anime gratis. Ketuk untuk mendapatkan percikan, panggil muse yang unik, dandani mereka, dan saksikan koleksimu terus bertambah, bahkan saat kamu tidak bermain.

KETUK, TINGKATKAN, BANGKIT
• Kombo yang memicu mode Fever dengan percikan dua kali lipat
• 12 tingkat peningkatan, orb bonus, amukan, dan penghasilan offline
• Bangkit untuk mendapatkan Bintang yang meningkatkan semua penghasilan selamanya

MUSE TANPA BATAS
• Setiap pemanggilan menciptakan karakter baru, perempuan atau laki-laki, dengan nama, arketipe, warna, gelar, kelangkaan, dan bonusnya sendiri. Tidak ada dua pemain dengan susunan yang sama.
• 15 arketipe, dari tsundere dan kuudere hingga gadis lentera, penyihir, dan kesatria
• Enam tingkat kelangkaan dari Biasa hingga Mitis, ditambah kelangkaan rahasia untuk diburu
• Fusikan dua muse menjadi fusi yang lebih kuat dengan nama gabungan dan aura bercahaya
• Isi 95 entri Kodeks untuk bonus permanen

SETIAP MUSE PUNYA HATI
• Setiap muse punya kepribadian sendiri: suasana hati, camilan, hadiah, tempat kencan, dan cuaca favorit, dibuat khusus untuk game-mu.
• Choker suasana hati menunjukkan perasaannya. Muse yang senang menghasilkan lebih banyak dan memberimu hadiah.
• Ngobrol, berbagi camilan, pergi kencan, dan tingkatkan ikatan hingga level 30. Muse yang senang berevolusi ke kelangkaan lebih tinggi.
• Bawa mereka ke Cahaya atau Bayangan: lingkaran cahaya, mata bersinar, dan sayap bulu, atau tanduk, mata merah, bekas luka, dan sayap kelelawar.
• Enam statistik kepribadian (Pesona, Kecerdikan, Kebaikan, Keisengan, Energi, dan Gaya) tumbuh bersama ikatan dan menambah penghasilanmu.
• Muse membuat permintaan, bertanya tentangmu, bergosip tentang satu sama lain, dan bereaksi pada cuaca, hari raya, dan ulang tahunmu.
• Temui wanita atau pria. Pilihanmu, kapan saja.

ALASAN UNTUK KEMBALI
• Hadiah rentetan harian dan bonus yang terus bertambah setiap hari kamu bermain
• Misi harian dan mingguan untuk mengisi Muse Pass bulanan gratis
• Muse Bulan Ini yang eksklusif dan album tahunan untuk dilengkapi
• Musim sungguhan dan 11 hari raya, masing-masing dengan event dan karakter gratis
• Kejutan di hari ulang tahunmu
• Rangkaian tantangan yang membuka Surgawi, tingkat di atas Mitis

HIAS PANGGUNGMU
• Lebih dari 500 kostum dan variasi warna untuk dibuka
• 18 latar anime animasi, plus adegan buatan dengan cuaca dan pencahayaan siang hingga malam
• Musik synthwave yang makin seru mengikuti ketukan dan kombomu

MAIN SESUKAMU
• 100% gratis: tanpa iklan, tanpa pembelian, tanpa akun
• Bisa dimainkan offline, dengan simpan otomatis dan 3 slot simpanan
• Tersedia dalam 16 bahasa, termasuk Bahasa Indonesia
• Pengaturan lengkap: grafis, suara, tata letak kidal, dan lainnya
• Aksesibilitas: teks lebih besar, kontras tinggi, warna ramah buta warna, gerakan dan kilatan dikurangi, dukungan pembaca layar

Game by MREVILA55. Terima kasih sudah bermain!

**Release notes**
Pembaruan 1.6: Zombi telah tiba! Kelangkaan baru, dan setiap zombi adalah varian unik dengan warna, nama, dan kepribadian zombinya sendiri. Widget layar utama baru dan kartu langkah di Galaxy Watch. Papan peringkat, kartu untuk dibagikan, dan undangan berhadiah untukmu dan temanmu. Semua Muse digambar ulang dalam HD, gaya dan panggung baru, efek Fever lebih meriah. Pengingat opsional. Siklus siang dan malam mengikuti jammu, dari matahari terbit hingga malam berbintang.

---

## Vietnamese (vi)

**App name**
Neon Muse: Idle Clicker

**Short description**
Chạm, triệu hồi, sưu tầm nàng thơ anime. Game idle miễn phí, không quảng cáo.

**Full description**
Neon Muse là game idle clicker phong cách anime miễn phí. Chạm để kiếm tia sáng, triệu hồi những nàng thơ độc nhất, phối đồ cho các nàng và ngắm bộ sưu tập lớn dần, kể cả khi bạn không chơi.

CHẠM, NÂNG CẤP, PHI THĂNG
• Combo dẫn tới chế độ Cuồng nhiệt với tia sáng nhân đôi
• 12 bậc nâng cấp, quả cầu thưởng, bùng nổ điên cuồng và thu nhập ngoại tuyến
• Phi thăng để nhận Sao giúp tăng vĩnh viễn mọi thu nhập

NÀNG THƠ VÔ TẬN
• Mỗi lần triệu hồi tạo ra một nhân vật hoàn toàn mới, nam hoặc nữ, với tên, kiểu nhân vật, màu sắc, danh hiệu, độ hiếm và phần thưởng riêng. Không người chơi nào có đội hình giống nhau.
• 15 kiểu nhân vật, từ tsundere, kuudere đến thiếu nữ đèn lồng, phù thủy và kỵ sĩ
• Sáu độ hiếm từ Thường đến Thần thoại, cùng các độ hiếm bí mật chờ khám phá
• Dung hợp hai nàng thơ thành một bản mạnh hơn với tên kết hợp và hào quang rực rỡ
• Hoàn thành 95 mục Codex để nhận thưởng vĩnh viễn

NÀNG THƠ NÀO CŨNG CÓ TRÁI TIM
• Mỗi Nàng Thơ có tính cách riêng: tâm trạng, món ngon, quà, nơi hẹn hò và thời tiết yêu thích, được tạo riêng cho game của bạn.
• Vòng cổ tâm trạng cho thấy họ đang cảm thấy thế nào. Nàng Thơ vui vẻ kiếm được nhiều hơn và tặng quà cho bạn.
• Trò chuyện, chia sẻ món ngon, đi hẹn hò và nâng gắn kết lên cấp 30. Nàng Thơ vui vẻ sẽ tiến hóa lên độ hiếm cao hơn.
• Dẫn dắt họ về Ánh sáng hoặc Bóng tối: vầng hào quang, đôi mắt phát sáng và cánh lông vũ, hoặc sừng, mắt đỏ, vết sẹo và cánh dơi.
• Sáu chỉ số tính cách (Quyến rũ, Lanh lợi, Tốt bụng, Nghịch ngợm, Năng lượng và Phong cách) tăng theo gắn kết và giúp bạn kiếm nhiều hơn.
• Nàng Thơ có điều ước, hỏi về bạn, buôn chuyện về nhau và phản ứng với thời tiết, ngày lễ và sinh nhật của bạn.
• Gặp gỡ nữ hoặc nam. Bạn chọn, bất cứ lúc nào.

LÝ DO ĐỂ QUAY LẠI
• Quà chuỗi hằng ngày và phần thưởng tăng dần theo mỗi ngày chơi
• Nhiệm vụ ngày và tuần để lấp đầy Thẻ Nàng Thơ hằng tháng miễn phí
• Nàng Thơ của tháng độc quyền và album hằng năm để hoàn thành
• Mùa thật và 11 ngày lễ, mỗi dịp có sự kiện và nhân vật miễn phí
• Bất ngờ nhỏ vào ngày sinh nhật của bạn
• Chuỗi thử thách mở khóa nhân vật Thiên Giới, bậc trên Thần thoại

TRANG TRÍ SÂN KHẤU
• Hơn 500 trang phục và biến thể màu để mở khóa
• 18 phông nền anime động, cùng cảnh được tạo với thời tiết và ánh sáng ngày đêm
• Nhạc synthwave sôi động theo từng cú chạm và combo của bạn

CHƠI THEO CÁCH CỦA BẠN
• Miễn phí 100%: không quảng cáo, không mua hàng, không cần tài khoản
• Chơi ngoại tuyến, tự động lưu và 3 ô lưu
• Hỗ trợ 16 ngôn ngữ, có tiếng Việt
• Cài đặt đầy đủ: đồ họa, âm thanh, bố cục tay trái và nhiều hơn nữa
• Trợ năng: chữ lớn hơn, tương phản cao, màu thân thiện với người mù màu, giảm chuyển động và nhấp nháy, hỗ trợ trình đọc màn hình

Game by MREVILA55. Cảm ơn bạn đã chơi!

**Release notes**
Bản cập nhật 1.6: Xác sống đã đến! Độ hiếm mới, mỗi xác sống là một biến thể độc nhất với màu sắc, tên và tính cách riêng. Widget màn hình chính mới và ô đếm bước trên Galaxy Watch. Bảng xếp hạng, thẻ chia sẻ và lời mời mang lại phần thưởng cho bạn và bạn bè. Mọi Nàng Thơ được vẽ lại bằng HD, diện mạo và sân khấu mới, hiệu ứng Cuồng Nhiệt hoành tráng hơn. Nhắc nhở tùy chọn. Chu kỳ ngày đêm theo đồng hồ của bạn, từ bình minh đến đêm đầy sao.

---

## Thai (th)

**App name**
Neon Muse: เกมคลิกเกอร์

**Short description**
แตะ อัญเชิญ และสะสมมิวส์อนิเมะแสนสวย เกมไอเดิลคลิกเกอร์ฟรี ไม่มีโฆษณา

**Full description**
Neon Muse คือเกมไอเดิลคลิกเกอร์สไตล์อนิเมะที่เล่นฟรี แตะเพื่อสะสมประกาย อัญเชิญมิวส์ที่ไม่ซ้ำใคร แต่งตัวให้เธอ แล้วดูคอลเลกชันเติบโตขึ้นเรื่อยๆ แม้ตอนที่คุณไม่ได้เล่น

แตะ อัปเกรด จุติ
• คอมโบที่พาเข้าสู่โหมดฟีเวอร์ ได้ประกายสองเท่า
• อัปเกรด 12 ระดับ ลูกแก้วโบนัส โหมดคลั่ง และรายได้ระหว่างออฟไลน์
• จุติเพื่อรับดาวที่เพิ่มรายได้ทั้งหมดอย่างถาวร

มิวส์ไม่มีที่สิ้นสุด
• การอัญเชิญทุกครั้งสร้างตัวละครใหม่ทั้งหญิงและชาย ที่มีชื่อ อาร์คีไทป์ สี ฉายา ความหายาก และโบนัสเป็นของตัวเอง ไม่มีผู้เล่นคนไหนได้ทีมเหมือนกัน
• 15 อาร์คีไทป์ ตั้งแต่ซึนเดเระ คูเดเระ ไปจนถึงสาวโคมไฟ แม่มด และอัศวิน
• ความหายาก 6 ระดับตั้งแต่ธรรมดาถึงเทพปกรณัม พร้อมระดับหายากลับให้ตามหา
• ฟิวชันมิวส์สองคนให้กลายเป็นตัวละครที่แข็งแกร่งขึ้น พร้อมชื่อผสมและออร่าเรืองแสง
• เติมโคเด็กซ์ 95 รายการเพื่อรับโบนัสถาวร

มิวส์ทุกคนมีหัวใจ
• มิวส์แต่ละคนมีบุคลิกของตัวเอง ทั้งอารมณ์ ขนม ของขวัญ สถานที่เดต และสภาพอากาศที่ชอบ สร้างขึ้นเฉพาะเกมของคุณ
• โชคเกอร์บอกอารมณ์จะบอกว่าพวกเขารู้สึกอย่างไร มิวส์ที่มีความสุขทำรายได้มากขึ้นและให้ของขวัญคุณ
• คุย แบ่งขนม ไปเดต และเพิ่มความผูกพันได้ถึงระดับ 30 มิวส์ที่มีความสุขจะวิวัฒนาการสู่ความหายากที่สูงขึ้น
• นำพวกเขาไปสู่แสงสว่างหรือความมืด: รัศมี ดวงตาเรืองแสง และปีกขนนก หรือเขา ดวงตาสีแดง แผลเป็น และปีกค้างคาว
• ค่าสถานะนิสัยหกอย่าง ได้แก่ เสน่ห์ ไหวพริบ ความใจดี ความซน พลัง และสไตล์ จะเติบโตตามความผูกพันและเพิ่มรายได้ของคุณ
• มิวส์จะอธิษฐาน ถามเรื่องของคุณ ซุบซิบกันเอง และตอบสนองต่อสภาพอากาศ เทศกาล และวันเกิดของคุณ
• พบผู้หญิงหรือผู้ชาย คุณเลือกได้ทุกเมื่อ

เหตุผลที่อยากกลับมา
• ของขวัญเข้าเล่นต่อเนื่องทุกวัน และโบนัสที่เพิ่มขึ้นทุกวันที่เล่น
• ภารกิจรายวันและรายสัปดาห์สำหรับมิวส์พาสรายเดือนแบบฟรี
• มิวส์ประจำเดือนสุดพิเศษ และอัลบั้มรายปีให้สะสมจนครบ
• ฤดูกาลจริงและ 11 เทศกาล แต่ละเทศกาลมีอีเวนต์และตัวละครฟรี
• เซอร์ไพรส์เล็กๆ ในวันเกิดของคุณ
• สถิติต่อเนื่องจากชาเลนจ์ที่ปลดล็อกตัวละครระดับสวรรค์ เหนือกว่าระดับเทพปกรณัม

แต่งเวทีของคุณ
• ชุดและสีมากกว่า 500 แบบให้ปลดล็อก
• ฉากหลังอนิเมะเคลื่อนไหว 18 แบบ พร้อมฉากที่สร้างขึ้นซึ่งมีสภาพอากาศและแสงกลางวันถึงกลางคืน
• เพลงซินธ์เวฟที่คึกคักตามการแตะและคอมโบของคุณ

เล่นในแบบของคุณ
• ฟรี 100%: ไม่มีโฆษณา ไม่มีการซื้อ ไม่ต้องมีบัญชี
• เล่นออฟไลน์ได้ บันทึกอัตโนมัติ และมีช่องบันทึก 3 ช่อง
• รองรับ 16 ภาษา รวมถึงภาษาไทย
• การตั้งค่าครบครัน: กราฟิก เสียง เลย์เอาต์สำหรับคนถนัดซ้าย และอื่นๆ
• ตัวเลือกการเข้าถึง: ตัวอักษรใหญ่ขึ้น คอนทราสต์สูง สีที่เป็นมิตรกับผู้ตาบอดสี ลดการเคลื่อนไหวและแสงกะพริบ รองรับโปรแกรมอ่านหน้าจอ

Game by MREVILA55 ขอบคุณที่เล่นนะครับ!

**Release notes**
อัปเดต 1.6: ซอมบี้มาแล้ว! ความหายากระดับใหม่ ซอมบี้แต่ละตัวเป็นแบบเฉพาะไม่ซ้ำใคร มีสี ชื่อ และนิสัยซอมบี้เป็นของตัวเอง วิดเจ็ตหน้าจอหลักใหม่ และไทล์นับก้าวบน Galaxy Watch กระดานผู้นำ การ์ดแชร์ และคำเชิญที่ให้รางวัลทั้งคุณและเพื่อน มิวส์ทุกตัววาดใหม่แบบ HD ลุคและเวทีใหม่ เอฟเฟกต์ฟีเวอร์อลังการขึ้น การแจ้งเตือนเปิดได้ตามต้องการ วงจรกลางวันกลางคืนตามนาฬิกาของคุณ ตั้งแต่พระอาทิตย์ขึ้นจนถึงคืนเต็มไปด้วยดาว นโยบายความเป็นส่วนตัวจะแสดงเมื่อเปิดครั้งแรก และดูได้เสมอในการตั้งค่า
