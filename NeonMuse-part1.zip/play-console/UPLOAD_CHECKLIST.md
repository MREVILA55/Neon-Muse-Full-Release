# Neon Muse - Google Play upload checklist (every form, every answer)

Package name: com.mrevila55.neonmuse (permanent once published)
Version: 1.6.0 (version code 14), the Undead update: Zombies, home screen widgets, the Galaxy Watch app, leaderboards,
invites, share cards, reminders and HD art. The watch app is version code 1000014 (see STEP 9). If Play Console says a
version code is already used, raise it (app/build.gradle and wear/build.gradle in the Android Studio project) and rebuild.
NEW IN 1.6, do these once: STEP 5 (two content rating answers change; Data safety adds leaderboard scores to one line), STEP 9 (Wear OS), STEP 10
(leaderboards) and STEP 11 (creator program).
Privacy policy: https://claude.ai/artifact/3qNpeiqK65xtXf2WqmQvto

---------------------------------------------------------------------
STEP 1. Create your developer account (once)
---------------------------------------------------------------------
- Go to play.google.com/console and sign up with the Google account you want to own the game.
- Account type: Personal. One-time fee: $25.
- Verify your identity (government ID), phone and email. Google may also ask you to confirm you have
  an Android phone through the Play Console app.
- Approval can take a few days. Start this first.

---------------------------------------------------------------------
STEP 2. Build the upload file (.aab) on your computer (about 30 minutes)
---------------------------------------------------------------------
EASIEST: use NeonMuse-AndroidStudio.zip instead. It is a ready Android Studio project with the game already
inside, so there is no Node.js and no setup script: unzip it, File > Open the folder in Android Studio, let
Gradle sync, then Build > Generate Signed App Bundle. README_FIRST.txt inside walks through every click.

The steps below are the other route, through Capacitor (this folder):
1. Install Node.js 22 or newer (nodejs.org) and the latest Android Studio (developer.android.com/studio).
2. Unzip NeonMuse-Android.zip. Open the folder.
3. Windows: double-click setup-android.bat. Mac/Linux: run ./setup-android.sh in a terminal.
   At the end it prints compileSdkVersion = 36 and targetSdkVersion = 36 (Google requires 36).
4. Run: npx cap open android   (Android Studio opens; wait for "Gradle sync" to finish.)
5. Build > Generate Signed App Bundle or APK > Android App Bundle > Next.
6. Key store path: Create new. Save the .jks file somewhere safe, pick a password, alias "upload".
   BACK UP the .jks file and both passwords in two places. You need them for every future update.
7. Choose "release" and Finish. The file is android/app/release/app-release.aab.
8. Optional but smart: plug in your phone (USB debugging on) and press Run to try the game on it.

---------------------------------------------------------------------
STEP 3. Create the app in Play Console
---------------------------------------------------------------------
Create app:
- App name: Neon Muse: Idle Clicker
- Default language: English (United States)
- App or game: Game
- Free or paid: Free (this can't be changed to paid later)
- Tick both declarations (Developer Program Policies, US export laws) and Create app.

---------------------------------------------------------------------
STEP 4. Main store listing (Grow > Store presence > Main store listing)
---------------------------------------------------------------------
Paste the name, short description and full description from store/store-listing.md.
Then add the other languages: Manage translations > Add your own translations, and paste each one from
store/store-listing-translations.md (15 languages, same four fields). The translated texts do not mention companions
yet; they are still accurate, and you can add a companions line in each language later.
Upload from store/graphics/:
- App icon: play-icon-512.png
- Feature graphic: feature-graphic-1024x500.png
- Phone screenshots (8): use the order in store-listing.md (Graphics). The Zombie summon goes first in 1.6.
- Wear OS screenshot: wear-1-tile.png (see STEP 9).
Store settings: Category Game > Casual. Tags: Idle, Casual, Anime, Offline, Single player.
Contact email: mrevila55business@gmail.com (shown publicly on the store page).
Website (optional): https://www.youtube.com/@mrevila55

---------------------------------------------------------------------
STEP 5. App content (Policy > App content). Answer exactly like this
---------------------------------------------------------------------
Privacy policy
- URL: https://claude.ai/artifact/3qNpeiqK65xtXf2WqmQvto
  (Open it in a private/incognito window first to make sure it loads without signing in.)

App access
- "All functionality in my app is available without any access restrictions."

Ads
- "No, my app does not contain ads."

Content rating (IARC questionnaire)
- Email: your contact email. Category: Game (not a social, store or reference app).
- Violence: No. (Some characters hold swords or staffs in their artwork, but there is no fighting. "Mischief"
  in the Hearts update means harmless pranks like swapping sugar for salt.)
- Blood: YES (1.6). The Zombie characters are drawn with stitched wounds, bruises and small blood stains on
  their skin and clothes. Nobody is hurt in the game and there is no fighting, so pick the mildest option the
  questionnaire offers (blood shown, not violence).
- Fear / horror: answer YES to mild horror themes (1.6). Zombies are undead characters with pale or green skin
  and stitches. They are friendly and played for laughs ("Braaains... I mean, hello!"), nothing jumps out and
  nothing scary happens, but answering Yes keeps the rating honest. Vampire and gothic outfits, the Halloween
  scene's cartoon cobwebs and bats, and the "Shadow" horns and scars stay cosmetic.
- If you already have a rating from 1.5: App content > Content rating > Edit questionnaire, change these two
  answers, and submit again before you publish 1.6.
- Sexuality: Nudity - No. Sexual activity - No. Sexual innuendo / suggestive themes - YES.
  (Stylized adult characters in fashion and fantasy outfits, some showing cleavage, and light
  flirty compliments like "Good evening, cutie." Players can also go on light, dating-sim style dates with
  the characters. Nothing explicit, and a setting turns flirting off.)
- Language / profanity: No.
- Drugs, alcohol, tobacco: No.
- Gambling or simulated gambling: No. (Summons give random characters. Summon tokens and gems can be bought,
  so this is a "random items purchasable with real money" game: answer Yes where the questionnaire asks about
  purchasable random items. The odds of every rarity are shown on the Summon screen, as Google Play requires.)
- Users can interact or share content with each other: No. (1.6: leaderboards show Play Games names and scores, and
  share cards go out through the phone's own share sheet, but players can't message or contact each other in the game.)
- Shares the user's location: No.
- Digital purchases: Yes (gems, summon tokens, spark packs, Starter Pack, Gem Card, Muse Pass).
- Unrestricted web browsing inside the app: No. (Social links open the phone's own browser.)
- Submit. The rating comes out automatically; expect a teen-level rating.

Target audience and content
- Target age groups: 18 and over only.
  (This doesn't stop anyone from downloading. It tells Google who the game is made for. Choosing
  younger groups brings stricter checks for a game with suggestive outfits.)
- "Could your app unintentionally appeal to children?" No.

Data safety (the app now has optional cloud save through Google Play Games)
- "Does your app collect or share any of the required user data types?" Yes.
- Is all user data encrypted in transit? Yes.  Can users request deletion? Yes.
- Data types (all "Collected", none "Shared", all optional for the player):
  - App activity > Other actions: saved game progress and (1.6) leaderboard scores. Purpose: App functionality.
  - App info and performance > Crash logs, Diagnostics: by the Google Play Games SDK. Purpose: Analytics.
  - Personal info > User IDs: the Play Games profile. Purpose: App functionality.
  Google's guidance: https://developer.android.com/games/pgs/data-collection
  (If you leave cloud save switched off - Project ID still 000000000000 - you can keep answering "No".)

Purchases: Google Play handles payments, so the app itself collects no payment or financial info.
  In Data safety, nothing needs adding for purchases.

Step tracking (the app asks for "Physical activity" / ACTIVITY_RECOGNITION only when the player turns it on)
- Data safety: steps are read on the phone and never leave it, so they are not "collected" (Google only counts data
  that leaves the device). Nothing to add for steps.
- App content > Health apps: tick "Activity and fitness" (step rewards). It is not a medical app.
- Permissions declaration: none needed (Physical activity is a normal runtime permission, not a restricted one).

"Where you are" (approximate location, ACCESS_COARSE_LOCATION, asked for only when the player turns it on in Settings)
- Data safety: add Location > Approximate location: Collected (Android's Geocoder, a Google service, turns it into a
  city name), not shared, processed ephemerally: Yes, optional: Yes, purpose: App functionality.
- Location permissions policy: foreground, approximate only, so no extra declaration is needed (that's only for
  background location).

New in 1.6 (nothing to add to Data safety for these, here is why):
- Leaderboards: they are part of Google Play Games services, already covered by the Play Games answers above.
  Scores are posted only while the player is signed in.
- Reminders: notifications are made on the phone (no server, no push service, no Firebase). The phone asks
  for the Notifications permission (Android 13+) only after the player says yes in the game.
- Home screen widgets and the Galaxy Watch app: their data stays on the player's own phone and watch
  (the watch talks to the phone through Google Play services' Wearable Data Layer). Nothing reaches you.
- Invites and creator codes: the codes are made on the phone. After installing from a link, the app reads Google
  Play's install referrer once to find the code in that link. A creator's code is attached to a Google Play
  order as the creator's tag (cr_NAME), which is not the player's data.
- Share cards: the picture is made on the phone and goes only where the player shares it.

Advertising ID
- "Does your app use advertising ID?" No.

Government apps: No.  Financial features: "My app doesn't provide any financial features."
Health apps: Activity and fitness (step rewards and egg warming; see the Step rewards note).  News apps: No.

---------------------------------------------------------------------
STEP 6. Pricing and countries
---------------------------------------------------------------------
- Free. Countries: all countries, or start with a few (US, UK, Canada, Australia, New Zealand).

---------------------------------------------------------------------
STEP 7. Closed test (required for new personal accounts)
---------------------------------------------------------------------
Google won't open the public store to a new personal account until at least 12 testers have stayed
in a closed test for 14 days in a row.
1. Test and release > Testing > Closed testing > Create track (or use "Alpha").
2. Testers: create an email list and add 15-20 Gmail addresses (aim above 12 in case people drop out).
3. Create release > upload app-release.aab > release name "1.6.0" > release notes from store-listing.md.
4. Review release > Start rollout to Closed testing. Google reviews it (often a few days).
5. Copy the "Join on Android" link and send it to your testers. They tap it, accept, then install
   from Google Play. They must stay opted in for 14 days; ask them to open the game a few times.
6. After 14 days: Dashboard > Apply for production. Sample answers are in SOFT_LAUNCH.md.

---------------------------------------------------------------------
STEP 8. Production
---------------------------------------------------------------------
- Production > Create release > add the same .aab (or a newer one) > Review > Start rollout.
- Optional: staged rollout (20%, then 50%, then 100%).
- Every future update: version code +1, same .jks key.

---------------------------------------------------------------------
STEP 9. The Galaxy Watch app (Wear OS), new in 1.6
---------------------------------------------------------------------
The watch app counts steps on the watch and shows them in a tile with your companion. It is a separate bundle
with the same package name and the same signing key as the phone app.
1. Android Studio: Build > Generate Signed App Bundle > choose the "wear" module > the SAME .jks and alias.
   The file is wear/release/wear-release.aab (version code 1000014).
2. Play Console > Test and release > Advanced settings > Form factors > Add form factor > Wear OS.
3. Store listing: upload the Wear OS screenshot (graphics/wear-1-tile.png, square, no frame) in the Wear OS
   section of the main store listing, and tick "Wear OS" in the form-factor opt-in there.
4. Test and release > Wear OS only tracks > Closed testing (or Production) > Create release > upload
   wear-release.aab. Same release notes. Review and roll out.
5. Google reviews Wear OS apps separately against its Wear OS app quality rules. The watch app only uses
   the Physical activity permission (for steps), works without the phone and has no ads.
If you don't want the watch app yet, skip this step. The phone app works the same without it.

---------------------------------------------------------------------
STEP 10. Leaderboards (Google Play Games), new in 1.6
---------------------------------------------------------------------
The game posts three scores while the player is signed in to Play Games: best combo, collection size and steps
this week. Do this after the Play Games Services setup in README_FIRST.txt (CLOUD SAVE).
1. Play Console > Grow users > Play Games Services > Setup and management > Leaderboards > Add leaderboard. Make three:
   - "Best combo"        Score format: Numeric, Ordering: Larger is better
   - "Collection"        Numeric, Larger is better
   - "Steps this week"   Numeric, Larger is better (it resets every week by itself)
2. Copy each leaderboard's ID (it looks like CgkI...EAIQAQ).
3. In the Android Studio project open app/src/main/res/values/strings.xml and replace
   REPLACE_WITH_BEST_COMBO_ID, REPLACE_WITH_COLLECTION_ID and REPLACE_WITH_STEPS_THIS_WEEK_ID with them.
4. Build the .aab again and publish the Play Games Services changes (Setup and management > Publishing).
Until the IDs are filled in, the Leaderboards button stays hidden and nothing is posted.

---------------------------------------------------------------------
STEP 11. The creator program, new in 1.6
---------------------------------------------------------------------
- Creators get a code (MREVILA55 is the founding code). A player who enters it, or installs from the creator's link,
  gets the creator's free welcome gift once.
- For 14 days after, purchases carry the creator's tag (cr_NAME) as the order's obfuscated profile ID. To pay creators
  their share, look the orders up with the Google Play Developer API (purchases.products.get returns
  obfuscatedExternalProfileId) or in your Play Console order exports. The game never sends anything to you or the creator.
- Adding a creator: send me their name, code, links and welcome gift, and I'll add them in the next update.

---------------------------------------------------------------------
What's different in the Google Play version (already done)
---------------------------------------------------------------------
- No donations: the Cash App button, the Donate button and the PayPal/partner and Linktree links are out
  (Google Play's Payments policy doesn't allow sending players to outside payment methods).
  The thank-you screen keeps YouTube, Twitch, TikTok and X, plus a "Rate Neon Muse" link.
- No play counter. The only data that leaves the phone is the optional Google Play Games cloud save and leaderboards (see Data safety).
- Swimwear, lingerie and similarly minimal outfits are left out (Google Play's content policy):
  Monster, Bunny, Island Dancer, Sarong, Little Imp, Mermaid, Android, Valkyrie, Noir Bodysuit,
  Silver Lace, Black Widow and Moonlight Empress. Their art isn't in the app at all.
  The web version's lingerie, swimwear and other minimal looks stay out, including three Zombie looks
  (Bandage Bikini, Black Lace Revenant, Widow's Shroud). 11 of the 14 Zombie designs are in the app.
- In-app purchases through Google Play Billing: 14 products, listed in IN_APP_PRODUCTS.md. Create them in Play Console
  (Monetize with Play > Products > In-app products). Everything can still be earned by playing.
- The 33 secret lingerie, swimwear and succubus looks of the web version are not in the app, and their art isn't in it.
- Cloud save through Google Play Games: set it up with README_FIRST.txt in the Android Studio project.

If Google ever rejects or flags the app, the email names the screen or image. Send it to me and
I'll change exactly that and rebuild.
