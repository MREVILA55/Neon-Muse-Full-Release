# Neon Muse - Google Play store listing (ready to paste)

This is the English listing. Translated listings for the other 15 languages are in store-listing-translations.md.

## App name (30 characters max)
Neon Muse: Idle Clicker

## Short description (80 characters max)
Tap, summon and collect anime muses, zombies and companions. Free idle clicker.

## Full description (4,000 characters max)
Neon Muse is a free anime idle clicker. Tap to earn sparks, summon one-of-a-kind muses, dress them up and watch your collection grow, even while you're away.

TAP, UPGRADE, ASCEND
• Tap combos that build into Fever mode for double sparks
• 12 upgrade tiers, bonus orbs, frenzy bursts and offline earnings
• Ascend for Stars that boost everything you earn, forever

SUMMON ENDLESS MUSES
• Every summon is a brand-new character, woman or man, with their own name, archetype, colors, rarity and bonus
• 15 archetypes, from Tsundere and Kuudere to Lantern Maiden, Witch and Knight
• Six rarities from Common to Mythic, plus secret rares to hunt down
• NEW: Zombies, a rarity of their own. Every Zombie is a one-of-a-kind variant of a hand-drawn undead design, with its own colors, name and zombie personality, and each design opens a new outfit
• Three Spotlight banners every week with a new Mythic muse and companion, every Friday at noon
• Fuse two muses: the fusion keeps one look and inherits features from the other

COMPANIONS
• 98 little creatures to hatch across 10 elements. Eggs warm up while you play, tap and walk
• Six rarities with rarity glows, and talents that boost your sparks, taps, orbs and gifts
• Feed, play and cuddle them. Happy companions help more and bring gifts
• One hovers beside your muse on stage, and she talks about it

MUSE LIFE
• Your muses talk to each other in a group chat. They make plans, tease, give advice, gossip and sometimes get jealous
• Every muse has her own seven-chapter story with dialogue, from the first meeting to the ending
• They learn your habits and remember the big moments you share
• A letter every day, weekly date night, festivals and a photo album

MUSE POWERS
• Every muse has a signature ability, rolled just for them. Rarer muses get stronger ones
• Unleash it for a burst of power, then level it up. Rarity auras glow up to a Mythic rainbow

EVERY MUSE HAS A HEART
• They use your name, ask about your day and remember it, and tell you what they need
• Every muse has her own personality, moods, favorite treats and date spots. Happy muses earn more
• Talk, share treats, go on dates and grow your bond up to level 30. Happy muses evolve
• Lead them to Light or Shadow: halos and feathered wings, or horns and bat wings
• Meet women or men. Your choice, any time.

A REASON TO COME BACK
• Step rewards: walk with your phone and earn sparks, with daily, weekly, monthly and yearly step goals
• Daily streak gifts and a bonus that grows every day you play
• Daily and weekly missions that fill a free monthly Muse Pass
• An exclusive Muse of the Month, and a yearly album to complete
• Real seasons and 11 holidays, each with its own event and a free holiday character
• Challenge streaks that unlock Celestials, the tier above Mythic

ON YOUR HOME SCREEN AND WRIST
• Home screen widgets with your muse's latest line, waiting sparks, steps and companion. A Discreet option shows only her face, or your companion
• A Galaxy Watch app that counts your steps and shows them in a tile

STYLE YOUR STAGE
• Nearly 600 outfits and color variations to unlock
• 36 anime stages with weather, plus generated scenes
• NEW: a day and night cycle that follows your phone's clock and the seasons, from sunrise to starry nights
• A synthwave soundtrack that builds with your taps and combos

PLAY YOUR WAY
• Free to play with no ads. Optional in-app purchases; everything can be earned by playing
• Leaderboards with Google Play Games, share cards for your best summons, and invite codes that reward you and your friends
• Optional reminders, only when you want them
• Works offline, with autosave, 3 save slots and optional cloud save with Google Play Games. Your save is backed up before every update
• Play in 16 languages, including Japanese, Chinese, Korean and Spanish
• Accessibility: bigger text, high contrast, color-blind-friendly colors, less motion and screen reader support

Game by MREVILA55. Thank you for playing!

## Release notes (What's new)
Zombies are here: a new rarity, and every Zombie is a one-of-a-kind variant with its own colors, name and zombie personality. New home screen widgets and a Galaxy Watch steps tile. Leaderboards, share cards and invites that reward you and a friend. Every muse redrawn in HD, new looks and stages, and bigger Fever effects. A day and night cycle that follows your clock, from sunrise to starry nights. Optional reminders you control. The privacy policy is always in Settings.

## Category and tags
- App or game: Game
- Category: Casual
- Tags (pick up to 5 from Google's list): Idle, Casual, Anime, Offline, Single player

## Contact details (Store settings)
- Email (required, shown publicly on the store page): mrevila55business@gmail.com
- Website (optional): https://www.youtube.com/@mrevila55

## Graphics (all in store/graphics/)
| Field | File | Google's rule |
|---|---|---|
| App icon | play-icon-512.png | 512 x 512 PNG, max 1 MB |
| Feature graphic | feature-graphic-1024x500.png | 1024 x 500, no transparency |
| Phone screenshots | phone-1-title.png ... phone-8-muse.png | 2 to 8, 1080 x 1920 |
| Wear OS screenshot (1.6) | wear-1-tile.png | square, at least 384 x 384, no device frame |

Suggested screenshot order: 1 title, 3 summon (a Zombie, new in 1.6), 6 companions, 5 Muse Powers, 8 Muse tab, 2 game (character chat), 7 group chat, 4 wardrobe.
