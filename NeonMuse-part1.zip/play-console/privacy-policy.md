# Privacy Policy - Neon Muse

Last updated November 7, 2026

Neon Muse is a game for adults 18 and older, made by MREVILA55. It runs on your device: as a web game, as the Android app on Google Play, and as an optional companion app for Galaxy Watch. It has no ads, no analytics and no tracking, and it never sells or shares your personal information. The optional features below only work if you turn them on.

## Data on your device

Your progress, the characters and companions you collect, your settings, the name you ask the Muses to call you and what they learn from your answers (like your hobbies or how your day went) are saved only on your device: in your browser's storage on the web, or in the app's own storage on Android. They are deleted if you clear the browser's site data, clear the app's data or uninstall the app, and you can wipe them any time with Settings > Data > Delete progress.

## Your birthday (optional)

If you enter your birthday, the game keeps only the month and day, on your device, to give you a birthday reward. It is never sent anywhere, and you can remove it any time in Settings.

## Purchases (Android app)

The Android app offers optional in-app purchases through Google Play. Google handles the payment under its own policy. MREVILA55 sees the order details Google gives developers (such as the item, date, price and country) and never sees your card or bank details. The web version has no purchases; its optional tip link opens an outside payment service, which has its own policy.

## Creator codes and invites

You can enter a creator's code or a friend's invite code. If you install the Android app from a creator's or friend's link, the app reads Google Play's install referrer once, right after installing, to find the code in that link. Invite and thank-you codes are made on your device from a random number and contain nothing about you.

When a creator's code is active and you buy something within 14 days of using it, the app attaches that creator's code (for example cr_MREVILA55) to the Google Play order so the creator can be paid their share. Only the code is attached.

## Notifications (Android app, optional)

If you allow notifications, the app schedules reminders on your phone, for example when an egg is ready to hatch, when new Spotlights arrive, when your daily gift is waiting or when your Muse misses you. There are two a day at most, and none at night while quiet hours are on. They are made and scheduled on your phone; there is no notification server, and nothing is sent to MREVILA55. Turn them off in Settings > Game or in your phone's settings.

## Home screen widgets (Android app, optional)

If you add a Neon Muse widget, it shows your Muse, your companion, your steps and short messages using information the app saves for it in its own storage on your phone. Discreet widgets show no character art. Removing the widget or uninstalling the app removes this information.

## Step tracking (optional)

If you turn on step tracking in the Android app, the game reads your phone's built-in step counter (Android's Physical activity permission) to give step rewards. Your step counts stay on your phone, are not part of the cloud save and are never sent to MREVILA55. You can turn this off any time in your phone's app settings.

The optional Galaxy Watch app counts steps on your watch (the watch's Physical activity permission) and sends today's step count to the phone app, and the phone sends your companion's picture and name to the watch. This uses Google Play services' Wearable Data Layer, which syncs between your own paired devices and may pass through your Google account when they are apart. Nothing is sent to MREVILA55.

## Where you are (Android app, optional)

If you turn on Where you are in the app's settings, the app reads your phone's approximate (city-level) location so the Muses can mention the city you're in. Android's built-in Geocoder, a Google service, turns the location into a place name. The game keeps only the city, region and country names, on your phone, outside the cloud save, and never sends them to MREVILA55. Turning it off erases the saved place.

## Cloud save and leaderboards (Android app, optional)

If you sign in to Google Play Games, the app keeps a copy of your save in your own Google Play Games account (Google's saved games), so you can restore it on a new phone. While you're signed in, your best combo, collection size and steps this week are posted to the game's Google Play Games leaderboards, where other players can see them with your Play Games profile name, depending on your Play Games visibility settings. Google stores this under [Google's privacy policy](https://policies.google.com/privacy), and Google Play Games services may also collect diagnostics to provide the service. MREVILA55 can't see your saved game. You can manage or delete it from your Play Games profile or Google account. Signing in is optional, and the game works without it.

## Sharing

Share cards and invite messages are made on your device and only leave it when you choose to share them, through your device's share menu or by copying them. The app you share to handles them under its own policy.

## Emails to MREVILA55

Become a Muse and the creator program open your own email app with a draft. Nothing is sent unless you send it. If you email MREVILA55, what you send, including any pictures, is used only to reply to you and, if you both agree, to make your Muse. Ask any time and your emails and pictures will be deleted.

## Internet use

The game sends nothing about you to MREVILA55. The web version only downloads its own files from the site that hosts it, and that site (for example itch.io) may keep standard server logs under its own policy. The Android app has everything built in and talks only to Google Play services, for purchases, the install referrer, Play Games and the watch link. It asks for three permissions, each only when you turn on the feature that needs it: Physical activity (steps), approximate location (Where you are) and notifications.

## Links to other sites

The thank-you screen and the creators' pages link to MREVILA55's and the creators' channels and pages, such as YouTube, Twitch, TikTok, X and Linktree, plus the game's Google Play page. They open in your browser only when you tap them, those sites have their own privacy policies, and the game doesn't send them anything.

## No ads or analytics

The game has no advertising and no analytics or tracking tools. The only sign-in is the optional Google Play Games sign-in in the Android app.

## Adults only

Neon Muse is made for adults 18 and older and is not directed at anyone younger. It doesn't knowingly collect information from anyone under 18. If you think someone under 18 has emailed MREVILA55, write to the address below and it will be deleted.

## Changes to this policy

If this policy changes, the new version will be posted at this same address with a new date, and the game will show it in Settings.

## Contact

Questions about this policy or your data: mrevila55business@gmail.com

Neon Muse is a game by MREVILA55.
