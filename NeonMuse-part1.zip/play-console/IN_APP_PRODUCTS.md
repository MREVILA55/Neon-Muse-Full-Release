# Neon Muse - in-app products for Google Play Console

Play Console > Monetize with Play > Products > In-app products > Create product, once for each row.
The Product ID must match exactly (it can't be changed later). Set each to Active.
Prices are suggestions in US dollars; Play Console converts them for other countries.
You need a payments profile (Play Console > Setup > Payments profile) before you can create products.

| Product ID | Name | Description | Price | Type in the game |
|---|---|---|---|---|
| nm_starter_pack | Starter Pack | 480 gems, 5 summon tokens and a guaranteed Legendary (one time per player) | $2.99 | One-time (acknowledged, never consumed) |
| nm_gem_card | Monthly Gem Card | 300 gems now, then 90 gems every day you play for 30 days | $4.99 | Consumable |
| nm_muse_pass | Premium Muse Pass | Premium track of this month's Muse Pass: gems every tier, a summon every 5 tiers, a Mythic at the end | $4.99 | Consumable (one per month) |
| nm_gems_80 | 80 gems | 80 gems (double on the first purchase) | $0.99 | Consumable |
| nm_gems_400 | 400 gems | 400 gems + 20 bonus (double on the first purchase) | $4.99 | Consumable |
| nm_gems_850 | 850 gems | 850 gems + 80 bonus (double on the first purchase) | $9.99 | Consumable |
| nm_gems_2200 | 2,200 gems | 2,200 gems + 300 bonus (double on the first purchase) | $24.99 | Consumable |
| nm_gems_4500 | 4,500 gems | 4,500 gems + 800 bonus (double on the first purchase) | $49.99 | Consumable |
| nm_gems_9500 | 9,500 gems | 9,500 gems + 2,000 bonus (double on the first purchase) | $99.99 | Consumable |
| nm_summon_1 | 1 summon token | One summon on Neon Dreams or the classic summon | $0.99 | Consumable |
| nm_summon_11 | 11 summon tokens | 10 summons plus 1 free | $7.99 | Consumable |
| nm_sparks_1h | 1 hour of sparks | Sparks equal to 1 hour of your earnings | $0.99 | Consumable |
| nm_sparks_8h | 8 hours of sparks | Sparks equal to 8 hours of your earnings | $4.99 | Consumable |
| nm_sparks_24h | 24 hours of sparks | Sparks equal to 24 hours of your earnings | $9.99 | Consumable |

All products are "In-app products" (not subscriptions). The app consumes the consumables after it gives the item, so
players can buy them again; the Starter Pack is acknowledged once and stays owned.

How it works in the app: BillingBridge.java (Google Play Billing Library 7.1.1).
- Each purchase is delivered exactly once per game, and Google Play is only told it's finished after the item is in the save.
  If the app closes mid-purchase, or a pending payment clears later, the item arrives the next time the game opens or comes back to the front.
- A product this version doesn't know is never consumed: it waits in Google Play until an update can deliver it.
- Prices on the cards come from Google Play in the player's own currency.
- A small purchase log is kept on the device. If an older save is loaded, the app closes before saving, or progress is reset,
  the purchases are delivered into that game again, exactly as bought (same gems, same Starter Pack Legendary).
- Spark packs lock in the amount shown when the player taps Buy (they get that or more).
- The Monthly Gem Card pays days the player missed when they come back, and a second card adds 30 more days instead of replacing the first.
- A Premium Muse Pass bought while one is already active is saved for the next month's pass.
- Settings > Data has Purchase history (what each purchase delivered) and Restore purchases.

Not on sale yet: Creator Packs and brand collabs (they use sample creators), so they don't need products.

Testing: Play Console > Setup > License testing > add your Gmail accounts. Those accounts can buy with test cards and
are never charged. Purchases only work in a build installed from Google Play (internal or closed testing track).

Good to know: there's no server checking receipts, so purchases are trusted on the phone. That's normal for a
single-player game; a server check can be added later if needed.
