package com.mrevila55.neonmuse.wear;

import androidx.wear.protolayout.ActionBuilders;
import androidx.wear.protolayout.ColorBuilders;
import androidx.wear.protolayout.DeviceParametersBuilders;
import androidx.wear.protolayout.DimensionBuilders;
import androidx.wear.protolayout.LayoutElementBuilders;
import androidx.wear.protolayout.ModifiersBuilders;
import androidx.wear.protolayout.ResourceBuilders;
import androidx.wear.protolayout.TimelineBuilders;
import androidx.wear.protolayout.material.CircularProgressIndicator;
import androidx.wear.protolayout.material.ProgressIndicatorColors;
import androidx.wear.protolayout.material.Text;
import androidx.wear.protolayout.material.Typography;
import androidx.wear.protolayout.material.layouts.EdgeContentLayout;
import androidx.wear.tiles.RequestBuilders;
import androidx.wear.tiles.TileBuilders;
import androidx.wear.tiles.TileService;

import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

/** The Steps tile: a neon ring toward today's goal, your companion and the count. Tap to open the watch app. */
public class StepTileService extends TileService {
    private static final int PINK = 0xFFFF5FD2, CYAN = 0xFF5FF3FF, TRACK = 0x33FFFFFF, SOFT = 0xFFFFC4EE, DIM = 0xB3FFFFFF;

    private String resVersion() {
        return "p" + WatchStore.p(this).getLong("picV", 0);
    }

    @Override
    protected ListenableFuture<TileBuilders.Tile> onTileRequest(RequestBuilders.TileRequest req) {
        DeviceParametersBuilders.DeviceParameters dev = req.getDeviceConfiguration();
        long steps = WatchStore.steps(this), goal = WatchStore.goal(this);
        float frac = Math.min(1f, steps / (float) goal);
        boolean hasPet = WatchStore.pet(this) != null;

        CircularProgressIndicator ring = new CircularProgressIndicator.Builder()
                .setProgress(frac)
                .setStrokeWidth(7f)
                .setCircularProgressIndicatorColors(new ProgressIndicatorColors(steps >= goal ? 0xFFFFD166 : PINK, TRACK))
                .setContentDescription(WatchStore.fmt(steps) + " / " + WatchStore.fmt(goal))
                .build();

        LayoutElementBuilders.Column.Builder col = new LayoutElementBuilders.Column.Builder()
                .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER);
        if (hasPet) {
            col.addContent(new LayoutElementBuilders.Image.Builder().setResourceId("pet")
                    .setWidth(DimensionBuilders.dp(46)).setHeight(DimensionBuilders.dp(46)).build());
            col.addContent(new LayoutElementBuilders.Spacer.Builder().setHeight(DimensionBuilders.dp(2)).build());
        }
        col.addContent(new Text.Builder(this, WatchStore.fmt(steps)).setTypography(Typography.TYPOGRAPHY_DISPLAY3)
                .setColor(ColorBuilders.argb(0xFFFFFFFF)).build());
        String of = WatchStore.str(this, "ofGoal"); if (of.isEmpty()) of = "of {0}";
        col.addContent(new Text.Builder(this, of.replace("{0}", WatchStore.fmt(goal))).setTypography(Typography.TYPOGRAPHY_CAPTION2)
                .setColor(ColorBuilders.argb(DIM)).build());

        String pn = WatchStore.str(this, "pet"), mood = WatchStore.str(this, "mood"), egg = WatchStore.str(this, "egg");
        int eggP = WatchStore.p(this).getInt("eggP", -1);
        String second = !pn.isEmpty() ? pn + (mood.isEmpty() ? "" : " · " + mood) : !egg.isEmpty() && eggP >= 0 ? egg + " " + eggP + "%" : getString(R.string.app_name);

        EdgeContentLayout layout = new EdgeContentLayout.Builder(dev)
                .setResponsiveContentInsetEnabled(true)
                .setEdgeContent(ring)
                .setPrimaryLabelTextContent(new Text.Builder(this, getString(R.string.tile_steps)).setTypography(Typography.TYPOGRAPHY_CAPTION1)
                        .setColor(ColorBuilders.argb(CYAN)).build())
                .setContent(col.build())
                .setSecondaryLabelTextContent(new Text.Builder(this, second).setTypography(Typography.TYPOGRAPHY_CAPTION2)
                        .setColor(ColorBuilders.argb(SOFT)).setMaxLines(1).build())
                .build();

        ModifiersBuilders.Clickable open = new ModifiersBuilders.Clickable.Builder().setId("open")
                .setOnClick(new ActionBuilders.LaunchAction.Builder().setAndroidActivity(new ActionBuilders.AndroidActivity.Builder()
                        .setPackageName(getPackageName()).setClassName(WatchActivity.class.getName()).build()).build()).build();
        LayoutElementBuilders.Box root = new LayoutElementBuilders.Box.Builder()
                .setWidth(DimensionBuilders.expand()).setHeight(DimensionBuilders.expand())
                .setModifiers(new ModifiersBuilders.Modifiers.Builder().setClickable(open).build())
                .addContent(layout).build();

        TileBuilders.Tile tile = new TileBuilders.Tile.Builder()
                .setResourcesVersion(resVersion())
                .setFreshnessIntervalMillis(10 * 60_000L)
                .setTileTimeline(TimelineBuilders.Timeline.fromLayoutElement(root))
                .build();
        return Futures.immediateFuture(tile);
    }

    @Override
    protected ListenableFuture<ResourceBuilders.Resources> onTileResourcesRequest(RequestBuilders.ResourcesRequest req) {
        ResourceBuilders.Resources.Builder r = new ResourceBuilders.Resources.Builder().setVersion(resVersion());
        android.graphics.Bitmap pet = WatchStore.pet(this);
        byte[] png = WatchStore.petBytes(this, 140);
        if (pet != null && png != null) {
            float s = Math.min(1f, 140f / Math.max(pet.getWidth(), pet.getHeight()));
            r.addIdToImageMapping("pet", new ResourceBuilders.ImageResource.Builder()
                    .setInlineResource(new ResourceBuilders.InlineImageResource.Builder().setData(png)
                            .setWidthPx(Math.max(1, Math.round(pet.getWidth() * s))).setHeightPx(Math.max(1, Math.round(pet.getHeight() * s)))
                            .setFormat(ResourceBuilders.IMAGE_FORMAT_UNDEFINED).build())
                    .build());
        }
        return Futures.immediateFuture(r.build());
    }
}
