package com.mrevila55.neonmuse.wear;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.health.services.client.HealthServices;
import androidx.health.services.client.data.DataType;
import androidx.health.services.client.data.PassiveListenerConfig;

import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.Wearable;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** What the watch knows: today's steps (from Wear OS Health Services), and your companion and goal from the phone. */
final class WatchStore {
    private WatchStore() { }
    static final String PATH_PET = "/nm/pet", PATH_PIC = "/nm/pic", PATH_STEPS = "/nm/steps";

    static SharedPreferences p(Context c) { return c.getSharedPreferences("nm_watch", Context.MODE_PRIVATE); }
    static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    /** Today's steps: the watch's own daily count, or the phone's if that's higher. */
    static long steps(Context c) {
        SharedPreferences s = p(c); String d = today();
        long w = d.equals(s.getString("day", "")) ? s.getLong("steps", 0) : 0;
        long ph = d.equals(s.getString("pDay", "")) ? s.getLong("pSteps", 0) : 0;
        return Math.max(w, ph);
    }

    static synchronized void setSteps(Context c, long n) {
        SharedPreferences s = p(c); String d = today();
        long was = d.equals(s.getString("day", "")) ? s.getLong("steps", 0) : 0;
        if (n < was && d.equals(s.getString("day", ""))) return;
        s.edit().putString("day", d).putLong("steps", n).apply();
    }

    static long goal(Context c) { return Math.max(1, p(c).getLong("goal", 5000)); }
    static String str(Context c, String k) { return p(c).getString(k, ""); }

    static Bitmap pet(Context c) {
        File f = new File(c.getFilesDir(), "pet.png");
        if (!f.exists()) return null;
        try { return BitmapFactory.decodeFile(f.getPath()); } catch (Throwable t) { return null; }
    }

    static byte[] petBytes(Context c, int maxPx) {
        Bitmap b = pet(c);
        if (b == null) return null;
        float s = Math.min(1f, maxPx / (float) Math.max(b.getWidth(), b.getHeight()));
        if (s < 1f) b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * s)), Math.max(1, Math.round(b.getHeight() * s)), true);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, o);
        return o.toByteArray();
    }

    static void savePet(Context c, byte[] png) {
        File tmp = new File(c.getFilesDir(), "pet.tmp"), dst = new File(c.getFilesDir(), "pet.png");
        if (png == null || png.length == 0) { dst.delete(); return; }
        try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(png); } catch (Exception e) { tmp.delete(); return; }
        if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst); }
        p(c).edit().putLong("picV", System.currentTimeMillis()).apply();
    }

    static byte[] read(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        } catch (Exception e) { return null; }
    }

    /** Sends today's count to the phone: every 100 steps, every 15 minutes, or right away when asked. */
    static void sendSteps(Context c, boolean force) {
        SharedPreferences s = p(c);
        long n = steps(c), last = s.getLong("sent", -1), at = s.getLong("sentAt", 0);
        String d = today();
        boolean due = force || !d.equals(s.getString("sentDay", "")) || n - last >= 100 || (n != last && System.currentTimeMillis() - at > 15 * 60_000L);
        if (!due || n <= 0) return;
        s.edit().putLong("sent", n).putLong("sentAt", System.currentTimeMillis()).putString("sentDay", d).apply();
        try {
            PutDataMapRequest r = PutDataMapRequest.create(PATH_STEPS);
            r.getDataMap().putString("day", d);
            r.getDataMap().putLong("steps", n);
            Wearable.getDataClient(c).putDataItem(r.asPutDataRequest().setUrgent());
        } catch (Throwable ignored) { }
    }

    /** Asks Wear OS to keep today's step count for us, even while the app is closed. */
    static void register(Context c) {
        try {
            Set<DataType<?, ?>> types = new HashSet<>(Collections.singleton(DataType.STEPS_DAILY));
            PassiveListenerConfig cfg = new PassiveListenerConfig.Builder().setDataTypes(types).build();
            HealthServices.getClient(c).getPassiveMonitoringClient().setPassiveListenerServiceAsync(StepService.class, cfg);
        } catch (Throwable ignored) { }
    }

    static String fmt(long n) { return String.format(Locale.getDefault(), "%,d", n); }
}
