package com.mrevila55.neonmuse.wear;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.wear.tiles.TileService;

import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemBuffer;
import com.google.android.gms.wearable.Wearable;

/**
 * Neon Muse on your Galaxy Watch: today's steps around a neon ring, your companion in the middle.
 * Steps count all day through Wear OS Health Services and go to the game on your phone.
 */
public class WatchActivity extends Activity implements SensorEventListener {
    static final int REQ = 11;
    private RingView ring;
    private SensorManager sm;
    private long liveBase = -1, dailyAtStart = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ring = new RingView(this);
        setContentView(ring);
        ring.setOnClickListener(v -> { if (!granted()) ask(); else { WatchStore.sendSteps(this, true); ring.pulse(); } });
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (granted()) WatchStore.register(this); else ask();
        loadFromPhone();
    }

    private boolean granted() { return checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED; }
    private void ask() { requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ); }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) { WatchStore.register(this); startLive(); }
        ring.invalidate();
    }

    /** What the phone sent before this app was installed (or while it was closed). */
    private void loadFromPhone() {
        try {
            for (String path : new String[]{WatchStore.PATH_PET, WatchStore.PATH_PIC}) {
                Wearable.getDataClient(this).getDataItems(Uri.parse("wear://*" + path)).addOnSuccessListener(buf -> {
                    final DataItemBuffer items = buf;
                    new Thread(() -> {
                        try { for (DataItem it : items) PetListener.apply(getApplicationContext(), it.freeze()); }
                        catch (Throwable ignored) { }
                        finally { items.release(); }
                        runOnUiThread(() -> { ring.reload(); try { TileService.getUpdater(this).requestUpdate(StepTileService.class); } catch (Throwable ignored) { } });
                    }).start();
                });
            }
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onResume() { super.onResume(); ring.reload(); startLive(); }

    @Override
    protected void onPause() {
        if (sm != null) sm.unregisterListener(this);
        liveBase = -1;
        WatchStore.sendSteps(this, false);
        super.onPause();
    }

    /** While the app is open the count moves with every step. */
    private void startLive() {
        if (!granted() || sm == null) return;
        Sensor s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (s == null) return;
        dailyAtStart = WatchStore.steps(this);
        liveBase = -1;
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        long raw = (long) e.values[0];
        if (liveBase < 0) { liveBase = raw; return; }
        long now = dailyAtStart + Math.max(0, raw - liveBase);
        if (now > WatchStore.steps(this)) { WatchStore.setSteps(this, now); ring.reload(); }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) { }

    /** The whole screen: a neon ring that fills toward your goal, your companion, the count and what's next. */
    static final class RingView extends View {
        private static final int PINK = Color.rgb(255, 95, 210), CYAN = Color.rgb(95, 243, 255), GOLD = Color.rgb(255, 209, 102);
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private Bitmap pet;
        private long steps, goal;
        private float shown = 0, pulse = 0;
        private final Context c;

        RingView(Context c) { super(c); this.c = c; setBackgroundColor(Color.BLACK); setKeepScreenOn(false); }

        void reload() { steps = WatchStore.steps(c); goal = WatchStore.goal(c); pet = WatchStore.pet(c); invalidate(); }
        void pulse() { pulse = 1; invalidate(); }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, R = Math.min(w, h) / 2;
            float d = getResources().getDisplayMetrics().density;
            // a soft glow behind everything
            p.setShader(new RadialGradient(cx, cy * 1.15f, R, Color.argb(90, 120, 30, 140), Color.TRANSPARENT, Shader.TileMode.CLAMP));
            cv.drawCircle(cx, cy, R, p); p.setShader(null);
            // the ring
            float sw = 9 * d, inset = sw / 2 + 4 * d;
            RectF rr = new RectF(cx - R + inset, cy - R + inset, cx + R - inset, cy + R - inset);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.argb(40, 255, 255, 255)); cv.drawArc(rr, 0, 360, false, p);
            float target = Math.min(1f, steps / (float) Math.max(1, goal));
            shown += (target - shown) * 0.18f;
            if (Math.abs(target - shown) > 0.002f || pulse > 0.01f) postInvalidateOnAnimation();
            SweepGradient sg = new SweepGradient(cx, cy, new int[]{CYAN, PINK, GOLD, CYAN}, new float[]{0f, 0.45f, 0.8f, 1f});
            android.graphics.Matrix m = new android.graphics.Matrix(); m.setRotate(-90, cx, cy); sg.setLocalMatrix(m);
            p.setShader(sg);
            if (shown > 0.003f) cv.drawArc(rr, -90, 360 * shown, false, p);
            p.setShader(null); p.setStyle(Paint.Style.FILL);
            if (steps >= goal) { p.setColor(Color.argb(60, 255, 209, 102)); cv.drawCircle(cx, cy, R - sw * 2, p); }
            // companion
            float top = cy - R * 0.62f;
            if (pet != null) {
                float box = R * 0.62f, s = Math.min(box / pet.getWidth(), box / pet.getHeight());
                float pw = pet.getWidth() * s, ph = pet.getHeight() * s, bounce = pulse * 6 * d;
                cv.drawBitmap(pet, null, new RectF(cx - pw / 2, top + box - ph - bounce, cx + pw / 2, top + box - bounce), p);
                top += box + 4 * d;
            } else top = cy - R * 0.28f;
            if (pulse > 0) pulse *= 0.86f;
            // the count
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setTextAlign(Paint.Align.CENTER); t.setColor(Color.WHITE);
            t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); t.setTextSize(R * 0.30f);
            cv.drawText(WatchStore.fmt(steps), cx, top + t.getTextSize() * 0.85f, t);
            float y = top + t.getTextSize() * 0.85f;
            t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); t.setTextSize(R * 0.11f); t.setColor(Color.argb(180, 255, 255, 255));
            String of = WatchStore.str(c, "ofGoal"); if (of.isEmpty()) of = "of {0}";
            y += t.getTextSize() * 1.4f;
            cv.drawText(of.replace("{0}", WatchStore.fmt(goal)), cx, y, t);
            // who's walking with you, or the egg
            String pn = WatchStore.str(c, "pet"), mood = WatchStore.str(c, "mood"), egg = WatchStore.str(c, "egg");
            int eggP = WatchStore.p(c).getInt("eggP", -1);
            String line = !pn.isEmpty() ? pn + (mood.isEmpty() ? "" : " · " + mood) : !egg.isEmpty() && eggP >= 0 ? egg + " " + eggP + "%" : "";
            if (!granted(c)) line = c.getString(com.mrevila55.neonmuse.wear.R.string.allow_steps);
            if (!line.isEmpty()) {
                t.setColor(Color.rgb(255, 196, 238)); t.setTextSize(R * 0.10f);
                y += t.getTextSize() * 1.7f;
                String fit = android.text.TextUtils.ellipsize(line, new android.text.TextPaint(t), R * 1.3f, android.text.TextUtils.TruncateAt.END).toString();
                cv.drawText(fit, cx, y, t);
            }
        }

        private static boolean granted(Context c) { return c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED; }
    }
}
