package com.mrevila55.neonmuse.wear;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Keeps step counting on after the watch restarts or the app updates. */
public class WatchBoot extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) WatchStore.register(c);
    }
}
