package com.mrevila55.neonmuse.wear;

import androidx.health.services.client.PassiveListenerService;
import androidx.health.services.client.data.DataPointContainer;
import androidx.health.services.client.data.DataType;
import androidx.health.services.client.data.IntervalDataPoint;
import androidx.wear.tiles.TileService;

import java.util.List;

/** Wear OS hands us today's step total every so often, even while the app is closed. */
public class StepService extends PassiveListenerService {
    @Override
    public void onNewDataPointsReceived(DataPointContainer data) {
        List<IntervalDataPoint<Long>> pts = data.getData(DataType.STEPS_DAILY);
        if (pts == null || pts.isEmpty()) return;
        IntervalDataPoint<Long> newest = pts.get(0);
        for (IntervalDataPoint<Long> d : pts) if (d.getEndDurationFromBoot().compareTo(newest.getEndDurationFromBoot()) > 0) newest = d;
        Long v = newest.getValue();
        if (v == null) return;
        WatchStore.setSteps(this, v);
        WatchStore.sendSteps(this, false);
        try { TileService.getUpdater(this).requestUpdate(StepTileService.class); } catch (Throwable ignored) { }
    }
}
