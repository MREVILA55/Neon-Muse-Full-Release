package com.mrevila55.neonmuse.wear;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.wear.tiles.TileService;

import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Your companion, its picture, your goal and the phone's step count, sent by Neon Muse on your phone. */
public class PetListener extends WearableListenerService {
    @Override
    public void onDataChanged(DataEventBuffer events) {
        boolean any = false;
        for (DataEvent e : events) {
            if (e.getType() != DataEvent.TYPE_CHANGED) continue;
            any |= apply(this, e.getDataItem());
        }
        if (any) try { TileService.getUpdater(this).requestUpdate(StepTileService.class); } catch (Throwable ignored) { }
    }

    /** Also used when the watch app first opens, to pick up what the phone sent before it was installed. */
    static boolean apply(Context c, DataItem item) {
        String path = item.getUri().getPath();
        DataMap m = DataMapItem.fromDataItem(item).getDataMap();
        if (WatchStore.PATH_PET.equals(path)) {
            SharedPreferences.Editor e = WatchStore.p(c).edit()
                    .putLong("goal", Math.max(1, m.getLong("goal", 5000)))
                    .putString("muse", m.getString("muse", "")).putString("pet", m.getString("pet", ""))
                    .putString("mood", m.getString("mood", "")).putString("ofGoal", m.getString("ofGoal", "of {0}"))
                    .putString("egg", m.getString("egg", "")).putInt("eggP", m.getInt("eggP", -1));
            if (WatchStore.today().equals(m.getString("day", ""))) e.putString("pDay", m.getString("day")).putLong("pSteps", m.getLong("steps", 0));
            e.apply();
            return true;
        }
        if (WatchStore.PATH_PIC.equals(path)) {
            Asset a = m.getAsset("pic");
            if (a == null) { WatchStore.savePet(c, null); return true; }
            try {
                DataClient.GetFdForAssetResponse r = Tasks.await(Wearable.getDataClient(c).getFdForAsset(a));
                try (InputStream in = r.getInputStream()) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
                    while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
                    WatchStore.savePet(c, b.toByteArray());
                }
                return true;
            } catch (Exception ignored) { return false; }
        }
        return false;
    }
}
