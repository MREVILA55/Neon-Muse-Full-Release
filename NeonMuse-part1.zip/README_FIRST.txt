NEON MUSE - ANDROID STUDIO PROJECT (version 1.6.0, version code 14; watch app 1000014)
=====================================================================
This folder is a complete Android Studio project for the Google Play edition of Neon Muse.
Everything the app needs is in here: the game, the icons, the Java code and the cloud save.

WHAT'S INSIDE
- app/src/main/assets/www/        the game (Google Play edition, 16 languages, works offline)
    index.html, cast3.js, cast4.js, manifest.webmanifest, icons/
- app/src/main/java/com/mrevila55/neonmuse/
    MainActivity.java   shows the game full screen. Back closes an open window in the game first,
                        otherwise it sends the game to the background (progress is saved).
    CloudSave.java      cloud save through Google Play Games "saved games" (see CLOUD SAVE below).
    StepCounter.java    step rewards: reads the phone's step counter after the player turns it on in Goals > Steps
                        (asks for the Physical activity permission; steps never leave the phone).
    BillingBridge.java  in-app purchases through Google Play Billing (product list: play-console/IN_APP_PRODUCTS.md).
                        Shows prices in the player's currency. An item is only marked finished after it is in the save.
    SaveBridge.java     a second copy of the save in the app's own files (written every minute and when the app goes to
                        the background). If the WebView's storage is ever wiped, by an update or a reset, the game brings
                        the save back from this copy. These files are also part of Android's automatic Google backup.
    PlaceHelper.java    "Where you are": approximate location -> city name for Muse chatter, after the player turns it
                        on in Settings (asks for approximate location; only the place name reaches the game).
    (new in 1.6)
    MuseWidget.java, MuseWidgetLarge.java, StepsWidget.java, WidgetBase.java, WidgetArt.java, WidgetStore.java,
    WidgetBridge.java   the three home screen widgets (Muse, Muse large, Steps & Companion) and what the game saves for
                        them. Discreet mode shows only her face or the companion. Widgets only use Play-allowed looks.
    NotifyBridge.java, NotifyReceiver.java, BootReceiver.java   optional reminders, made on the phone (no server). Asks for
                        the Notifications permission only after the player says yes in the game; rescheduled after a reboot.
    GamesBridge.java    Google Play Games leaderboards (IDs in strings.xml, see play-console/UPLOAD_CHECKLIST.md STEP 10).
    RefBridge.java      reads Google Play's install referrer once, for invite and creator links.
    ShareBridge.java, ShareProvider.java   shares a picture (share cards) through Android's share sheet.
    WearSync.java, PetListener.java   talk to the Galaxy Watch app through the Wearable Data Layer.
- wear/                            the Galaxy Watch (Wear OS) app, new in 1.6: WatchActivity, StepTileService (the tile),
                                   StepService, WatchListener and friends. Same applicationId and signing key as the phone app.
- app/src/main/AndroidManifest.xml   the app, plus the Google Play Games project ID entry
- app/src/main/res/values/strings.xml   app name, game_services_project_id and the three leaderboard IDs (lb_*)
- app/src/main/res/mipmap-*        launcher icons (the neon heart "N")
- app/build.gradle                 app ID com.mrevila55.neonmuse, minSdk 24, targetSdk 36,
                                   dependencies play-services-games-v2:21.0.0, billing:7.1.1, play-services-wearable:19.0.0
                                   and installreferrer:2.2
- build.gradle, settings.gradle, gradle/, gradlew, gradlew.bat   the Gradle build (Android Gradle Plugin 8.12)
- play-console/                   everything for Google Play Console: store-listing.md (texts), UPLOAD_CHECKLIST.md
                                   (every Console step and form answer), privacy-policy.md, graphics/ (icon, feature
                                   graphic, 8 phone screenshots). Privacy policy link: https://claude.ai/artifact/3qNpeiqK65xtXf2WqmQvto

BUILD THE GOOGLE PLAY FILE (.aab) IN ANDROID STUDIO
1. Unzip this somewhere simple, for example C:\NeonMuse-AndroidStudio
2. Android Studio > File > Open > pick the NeonMuse-AndroidStudio folder > OK. Choose "Trust project".
3. Wait for "Gradle sync" to finish (5-15 minutes the first time). If it asks to install Android SDK 36, click Install.
4. Build > Generate Signed App Bundle or APK > "Android App Bundle" > Next.
5. Key store path: "Create new...". Save the .jks file somewhere safe. Alias: upload. Pick passwords. OK > Next.
6. Choose "release" > Create.
7. Your file: app/release/app-release.aab -> upload it in Google Play Console.
KEEP THE .jks FILE AND BOTH PASSWORDS SAFE. Every future update must be signed with the same key.

BUILD FROM A COMMAND LINE OR WITH ANOTHER TOOL / AI ASSISTANT
- Needs JDK 17 or newer (the one bundled with Android Studio works) and the Android SDK with platform 36.
- Unsigned release bundle:   ./gradlew bundleRelease      (Windows: gradlew.bat bundleRelease)
  Output: app/build/outputs/bundle/release/app-release.aab
- Google Play needs it signed with your upload key. Either sign it in Android Studio (steps above), or sign the
  output with:  jarsigner -keystore upload.jks app-release.aab upload
- Nothing in the project needs Node.js, Capacitor or any other setup. Do not change applicationId
  (com.mrevila55.neonmuse) - it must stay the same for every update on Google Play.

CLOUD SAVE (Google Play Games saved games)
The game uploads progress to the player's Google Play Games account and downloads it on a new phone.
Offline play is saved on the phone as always and syncs the next time the player is online and signed in.
If both the phone and the cloud moved on, the game asks which one to keep. The game also works without it.
To switch it on (one time, in Play Console):
1. Play Console > your app > Grow users > Play Games Services > Setup and management > Configuration.
   Choose "No, my game doesn't use Google APIs" > create the Play Games Services project.
2. Credentials > Add credential > Android. Package name com.mrevila55.neonmuse. Add the SHA-1 of your
   app signing key (Play Console > Test and release > App integrity > App signing) AND of your upload key.
3. Properties: turn "Saved Games" ON.
4. Copy the numeric "Project ID" shown on the Configuration page.
5. In this project open app/src/main/res/values/strings.xml and replace 000000000000 in
   game_services_project_id with that number. Build the .aab again.
6. Testers: Play Games Services > Testers > add the Google accounts of your testers (needed until the
   Play Games Services project is published), then Publish the Play Games Services configuration.
Players see "Cloud save" in Settings. It shows when it last synced, and tapping it signs in and syncs right away.

DATA SAFETY FORM (Play Console > App content > Data safety) WITH CLOUD SAVE
Google Play Games services collects some data for the game. Google's guidance:
https://developer.android.com/games/pgs/data-collection
- Does your app collect or share user data? Yes (through Google Play Games services).
- App activity > Other actions: saved game progress and leaderboard scores. Collected, not shared. Purpose: App functionality.
- App info and performance > Crash logs and Diagnostics: collected by the Play Games SDK. Purpose: Analytics.
- Personal info > User IDs: the player's Play Games profile (gamer name). Purpose: App functionality.
- Encrypted in transit: Yes. Users can request deletion: Yes (from their Play Games profile or Google account).
- Optional for the player: Yes (the game works without signing in).
- The developer receives nothing: the save lives in the player's own Google Play Games account.

IN-APP PURCHASES
- The Store sells gems, the Starter Pack, the Monthly Gem Card, the Premium Muse Pass, summon tokens and spark packs
  through Google Play. Create the 14 products in Play Console exactly as listed in play-console/IN_APP_PRODUCTS.md
  (a payments profile is needed first). Until they exist, buying says the item isn't available.
- Test with license testers (Play Console > Setup > License testing) on a build from an internal or closed testing track.

WHERE YOU ARE
- Settings > Where you are lets Muses comment on the player's city. Play Console Data safety: add
  Location > Approximate location (collected, ephemeral, optional, App functionality). See play-console/UPLOAD_CHECKLIST.md.

SAVES ARE SAFE ACROSS UPDATES (1.5.0 and 1.6.0)
- Keep the package name and the same .jks key, and keep loading the game from file:///android_asset/www/index.html.
  Then the save simply carries over. On top of that:
  - before a new version saves for the first time, the old save is copied to "Before the update" (Settings > Data > Load game)
  - a damaged save is put aside and the newest good copy is loaded instead, with a message to the player
  - SaveBridge.java keeps a copy in the app's files, so even a wiped WebView storage comes back
  Tested here: 1.4.0 and 1.5.0 saves open in 1.6.0 with every spark, gem, token, Muse and bond level intact.

COMPANIONS
- Pets menu: 98 companions hatch from eggs; one goes out with the Muse on stage. Everything is saved in the normal save
  (and cloud save). Starlit Eggs cost 150 gems; there are no new Play products to create.

STEP REWARDS
- Goals > Steps shows today's steps and daily (5,000), weekly (30,000), monthly (120,000) and yearly (1,200,000) goals.
  Rewards are sparks and companion eggs. Steps also warm companion eggs in Pets > Eggs. Play Console: App content > Health apps >
  "Activity and fitness". Nothing to add to Data safety.

WHAT'S NEW IN 1.6 (THE UNDEAD UPDATE)
- Zombies: a new rarity. 11 of the 14 Zombie designs are in this edition (the bikini, lace and sheer ones are web-only).
  Every Zombie summoned is a one-of-a-kind variant with its own colors, name and zombie personality.
- Day and night: the stage follows the phone's clock (sunrise, golden hour, sunset, dusk, starry night), with sunrise
  and sunset moving with the seasons. The widgets' glass follows the same sky.
- Home screen widgets (long-press the home screen > Widgets > Neon Muse) and the Galaxy Watch app (wear/ module).
- Leaderboards, share cards, invites with friend rewards, creator codes, optional reminders.
- The privacy policy opens the first time the game starts after install, and stays in Settings > Data.
- Play Console steps for all of this: play-console/UPLOAD_CHECKLIST.md (STEP 5 answers, STEPS 9 to 11).
- Build the watch bundle: Build > Generate Signed App Bundle > module "wear" > the same .jks.

FOR THE NEXT UPDATE
- Put the new game files in app/src/main/assets/www (index.html, cast3.js, cast4.js and art1.js to art4.js).
- In app/build.gradle raise versionCode by 1 and update versionName.
- Build the bundle again with the SAME .jks key.

TRY IT ON YOUR PHONE (optional)
- Turn on USB debugging on the phone, plug it in, pick it at the top of Android Studio, press Run.

IF SOMETHING GOES WRONG
- "SDK location not found" or "Android SDK 36": Tools > SDK Manager > tick Android 16 (API 36) > Apply,
  then File > Sync Project with Gradle Files.
- Errors about Java/JDK: Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK = the bundled one.
- If Play Console says version code 14 is already used, raise versionCode in app/build.gradle (and the watch's in wear/build.gradle to 1,000,000 + that number).
- Cloud save says "Sign in to Google Play Games": the Project ID is still 000000000000, the SHA-1 credentials
  are missing, or the tester account isn't added yet (see CLOUD SAVE).

Game by MREVILA55. Copyright (c) 2026 MREVILA55. All rights reserved.
