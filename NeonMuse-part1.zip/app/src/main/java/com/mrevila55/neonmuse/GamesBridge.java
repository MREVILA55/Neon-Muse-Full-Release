package com.mrevila55.neonmuse;

import android.app.Activity;
import android.webkit.JavascriptInterface;

import com.google.android.gms.games.PlayGames;

/**
 * Google Play Games leaderboards: best combo, collection size and steps this week.
 * Put the leaderboard IDs from Play Console in res/values/strings.xml (lb_combo, lb_collection, lb_steps).
 * Until they're filled in, configured() answers "0" and the game hides the Leaderboards button.
 * window.NMGames: configured(), submit(key, score), show().
 */
public class GamesBridge {
    static final int RC_BOARDS = 7051;
    private final Activity act;

    GamesBridge(Activity act) { this.act = act; }

    private String id(String key) {
        int r;
        switch (key == null ? "" : key) {
            case "combo": r = R.string.lb_combo; break;
            case "collection": r = R.string.lb_collection; break;
            case "steps": r = R.string.lb_steps; break;
            default: return null;
        }
        String s = act.getString(r);
        return s.startsWith("REPLACE") || s.isEmpty() ? null : s;
    }

    @JavascriptInterface
    public String configured() {
        String p = act.getString(R.string.game_services_project_id);
        return !p.matches("0+") && id("combo") != null ? "1" : "0";
    }

    @JavascriptInterface
    public void submit(String key, String score) {
        final String lb = id(key);
        if (lb == null) return;
        final long v;
        try { v = Long.parseLong(score); } catch (Exception e) { return; }
        if (v <= 0) return;
        act.runOnUiThread(() -> {
            try {
                PlayGames.getGamesSignInClient(act).isAuthenticated().addOnCompleteListener(t -> {
                    if (t.isSuccessful() && t.getResult() != null && t.getResult().isAuthenticated())
                        PlayGames.getLeaderboardsClient(act).submitScore(lb, v);
                });
            } catch (Throwable ignored) { }
        });
    }

    @JavascriptInterface
    public void show(String unused) {
        act.runOnUiThread(() -> {
            try {
                PlayGames.getGamesSignInClient(act).isAuthenticated().addOnCompleteListener(t -> {
                    boolean in = t.isSuccessful() && t.getResult() != null && t.getResult().isAuthenticated();
                    if (in) open();
                    else PlayGames.getGamesSignInClient(act).signIn().addOnCompleteListener(s -> {
                        if (s.isSuccessful() && s.getResult() != null && s.getResult().isAuthenticated()) open();
                    });
                });
            } catch (Throwable ignored) { }
        });
    }

    private void open() {
        PlayGames.getLeaderboardsClient(act).getAllLeaderboardsIntent()
                .addOnSuccessListener(i -> { try { act.startActivityForResult(i, RC_BOARDS); } catch (Exception ignored) { } });
    }
}
