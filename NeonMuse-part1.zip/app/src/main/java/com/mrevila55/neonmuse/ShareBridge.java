package com.mrevila55.neonmuse;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Share cards and invites go through Android's share sheet. window.NMShare: image(pngDataUrl, text), text(text).
 * The picture is written to the app's cache and handed over through ShareProvider for just that share.
 */
public class ShareBridge {
    private final Activity act;

    ShareBridge(Activity act) { this.act = act; }

    @JavascriptInterface
    public void image(String dataUrl, String text) {
        int k = dataUrl == null ? -1 : dataUrl.indexOf("base64,");
        if (k < 0 || dataUrl.length() > 12_000_000) { text(text); return; }
        try {
            byte[] b = Base64.decode(dataUrl.substring(k + 7), Base64.DEFAULT);
            File dir = new File(act.getCacheDir(), "share");
            if (!dir.exists()) dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) if (System.currentTimeMillis() - f.lastModified() > 3600_000L) f.delete();
            String name = "neon-muse-" + System.currentTimeMillis() + ".png";
            try (FileOutputStream o = new FileOutputStream(new File(dir, name))) { o.write(b); }
            Uri u = ShareProvider.uri(act, name);
            Intent s = new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, u)
                    .putExtra(Intent.EXTRA_TEXT, text == null ? "" : text).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            s.setClipData(ClipData.newRawUri("", u));
            act.runOnUiThread(() -> { try { act.startActivity(Intent.createChooser(s, null)); } catch (Exception ignored) { } });
        } catch (Exception e) { text(text); }
    }

    @JavascriptInterface
    public void text(String text) {
        Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
        act.runOnUiThread(() -> { try { act.startActivity(Intent.createChooser(s, null)); } catch (Exception ignored) { } });
    }
}
