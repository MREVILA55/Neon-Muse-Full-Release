package com.mrevila55.neonmuse;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

import org.json.JSONObject;

/**
 * Phone to watch: your companion, its picture, today's goal and the step count the game knows, so the watch app and
 * tile show the same companion as the game. Nothing leaves the phone except to your own paired watch.
 */
final class WearSync {
    private WearSync() { }
    static final String PATH_PET = "/nm/pet", PATH_PIC = "/nm/pic", PATH_STEPS = "/nm/steps";

    static void push(Context c, JSONObject d) {
        try {
            JSONObject pet = d.optJSONObject("pet");
            String sig = d.optString("day") + "|" + d.optLong("steps") + "|" + d.optLong("goal") + "|" + (pet == null ? "" : pet.toString())
                    + "|" + d.optBoolean("disc") + "|" + d.optString("lang") + "|" + d.optString("name");
            SharedPreferences p = c.getSharedPreferences("nm_wear", Context.MODE_PRIVATE);
            if (sig.equals(p.getString("sig", ""))) return;
            p.edit().putString("sig", sig).apply();
            PutDataMapRequest r = PutDataMapRequest.create(PATH_PET);
            r.getDataMap().putString("day", d.optString("day"));
            r.getDataMap().putLong("steps", d.optLong("steps"));
            r.getDataMap().putLong("goal", Math.max(1, d.optLong("goal", 5000)));
            r.getDataMap().putString("muse", d.optBoolean("disc") ? "" : d.optString("name"));
            r.getDataMap().putString("pet", pet == null ? "" : pet.optString("nm"));
            r.getDataMap().putString("mood", pet == null ? "" : pet.optString("mood"));
            JSONObject tx = d.optJSONObject("tx");
            r.getDataMap().putString("ofGoal", tx == null ? "of {0}" : tx.optString("steps", "of {0}"));
            r.getDataMap().putString("egg", d.optJSONObject("egg") == null ? "" : d.optJSONObject("egg").optString("n"));
            r.getDataMap().putInt("eggP", d.optJSONObject("egg") == null ? -1 : d.optJSONObject("egg").optInt("p"));
            PutDataRequest q = r.asPutDataRequest();
            q.setUrgent();
            Wearable.getDataClient(c).putDataItem(q);
        } catch (Throwable ignored) { }
    }

    static void pushPet(Context c, byte[] png) {
        try {
            PutDataMapRequest r = PutDataMapRequest.create(PATH_PIC);
            r.getDataMap().putAsset("pic", Asset.createFromBytes(png));
            r.getDataMap().putLong("t", png.length);
            Wearable.getDataClient(c).putDataItem(r.asPutDataRequest().setUrgent());
        } catch (Throwable ignored) { }
    }
}
