package com.mrevila55.neonmuse;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

/**
 * Step rewards: reads the phone's built-in step counter (steps since the phone started) and hands the number to the game
 * with nmStepsUpdate(total). The game keeps its own daily totals on the phone. Nothing is sent anywhere.
 * The game talks to it with window.NMSteps: available(), permission(), request().
 */
public class StepCounter implements SensorEventListener {
    static final int REQ = 7041;
    private final Activity act;
    private final WebView web;
    private final SensorManager sm;
    private final Sensor sensor;
    private boolean on = false;

    StepCounter(Activity act, WebView web) {
        this.act = act;
        this.web = web;
        this.sm = (SensorManager) act.getSystemService(Context.SENSOR_SERVICE);
        this.sensor = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
    }

    private boolean granted() {
        if (Build.VERSION.SDK_INT < 29) return true;   // Android 9 and older: no runtime permission for the step counter
        return act.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public String available() { return sensor != null ? "1" : "0"; }

    @JavascriptInterface
    public String permission() { return granted() ? "granted" : "prompt"; }

    @JavascriptInterface
    public void request(String unused) {
        act.runOnUiThread(() -> {
            if (granted()) { start(); js("window.nmStepsPerm&&nmStepsPerm(true)"); return; }
            if (Build.VERSION.SDK_INT >= 29) act.requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ);
        });
    }

    /** Called from MainActivity.onRequestPermissionsResult. */
    void onPermission(boolean ok) {
        if (ok) start();
        js("window.nmStepsPerm&&nmStepsPerm(" + ok + ")");
    }

    void start() {
        if (on || sensor == null || !granted()) return;
        on = sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    void stop() {
        if (!on) return;
        sm.unregisterListener(this);
        on = false;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (e == null || e.values == null || e.values.length == 0) return;
        final long total = (long) e.values[0];
        WidgetStore.phoneRaw(act, total);   // the Steps widget starts from the same count
        js("window.nmStepsUpdate&&nmStepsUpdate(" + total + ")");
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) { }

    private void js(final String code) {
        act.runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }
}
