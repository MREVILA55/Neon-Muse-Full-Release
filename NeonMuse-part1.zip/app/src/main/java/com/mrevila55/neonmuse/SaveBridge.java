package com.mrevila55.neonmuse;

import android.content.Context;
import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * A second copy of the save in the app's own files, so progress survives an app update, a WebView data reset,
 * or a reinstall (files here are included in Android's automatic Google backup). The game talks to it with window.NMSave:
 *   put(name, text)   writes files/saves/name.json safely (to a temporary file first, then swapped in)
 *   get(name)         returns that text, or "" when there is none
 *   time(name)        when it was last written, in milliseconds (0 when there is none)
 */
public class SaveBridge {
    private final File dir;

    SaveBridge(Context c) {
        dir = new File(c.getFilesDir(), "saves");
        if (!dir.exists()) dir.mkdirs();
    }

    private File file(String name) {
        String n = name == null ? "" : name.replaceAll("[^A-Za-z0-9_-]", "");
        if (n.isEmpty()) n = "save";
        return new File(dir, n + ".json");
    }

    @JavascriptInterface
    public synchronized boolean put(String name, String text) {
        if (text == null || text.isEmpty()) return false;
        File tmp = new File(dir, "tmp-" + System.nanoTime());
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(text.getBytes(StandardCharsets.UTF_8));
            o.getFD().sync();
        } catch (IOException e) {
            tmp.delete();
            return false;
        }
        File dst = file(name);
        if (!tmp.renameTo(dst)) {
            dst.delete();
            if (!tmp.renameTo(dst)) { tmp.delete(); return false; }
        }
        return true;
    }

    @JavascriptInterface
    public synchronized String get(String name) {
        File f = file(name);
        if (!f.exists()) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return new String(b.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    @JavascriptInterface
    public long time(String name) {
        File f = file(name);
        return f.exists() ? f.lastModified() : 0;
    }
}
