package com.mrevila55.neonmuse;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * In-app purchases through Google Play Billing. The game talks to it with window.NMBilling:
 *   buy(req, productId)        opens Google Play checkout for that in-app product
 *   finish(token, consume)     after the game has given the item: "1" consumes it (can be bought again), "0" acknowledges it (one-time)
 *   restore("")                re-sends purchases that were paid for but not finished yet (for example, the app closed mid-purchase)
 *   prices(csv)                asks Google Play for the local price of each product; they arrive as nmBillPrices({productId: "€4,99", ...})
 * Results arrive in the game as nmBillDone({req, ok, pid, token, err, restored}).
 * The game only calls finish() after the item is in the player's save, so nothing paid for is ever consumed without being delivered.
 * Product ids: see play-console/IN_APP_PRODUCTS.md.
 */
public class BillingBridge implements PurchasesUpdatedListener {
    private final Activity act;
    private final WebView web;
    private final BillingClient client;
    private String lastReq = "";

    BillingBridge(Activity act, WebView web) {
        this.act = act;
        this.web = web;
        client = BillingClient.newBuilder(act)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build();
        connect(null);
    }

    private void connect(final Runnable then) {
        if (client.isReady()) { if (then != null) then.run(); return; }
        client.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult r) {
                if (r.getResponseCode() == BillingClient.BillingResponseCode.OK && then != null) then.run();
                else if (then != null) send(lastReq, false, null, null, "unavailable", false);
            }
            @Override public void onBillingServiceDisconnected() { }
        });
    }

    @JavascriptInterface
    public void buy(final String req, final String productId) { buyFor(req, productId, ""); }

    /**
     * Same as buy(), with the creator code the player is supporting attached to the order as its obfuscated profile ID
     * (for example "cr_MREVILA55"). It shows up on the order in the Google Play Developer API, so creator payouts can be
     * worked out from real orders. It never holds anything about the player.
     */
    @JavascriptInterface
    public void buyFor(final String req, final String productId, final String creator) {
        final String tag = creator == null ? "" : creator.replaceAll("[^A-Za-z0-9_-]", "");
        lastReq = req;
        connect(() -> {
            QueryProductDetailsParams q = QueryProductDetailsParams.newBuilder()
                    .setProductList(Collections.singletonList(QueryProductDetailsParams.Product.newBuilder()
                            .setProductId(productId).setProductType(BillingClient.ProductType.INAPP).build()))
                    .build();
            client.queryProductDetailsAsync(q, (r, list) -> {
                if (r.getResponseCode() != BillingClient.BillingResponseCode.OK || list == null || list.isEmpty()) {
                    send(req, false, productId, null, "unavailable", false); return;
                }
                ProductDetails pd = list.get(0);
                BillingFlowParams.Builder b = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(Collections.singletonList(
                                BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).build()));
                if (!tag.isEmpty()) b.setObfuscatedProfileId(tag.length() > 64 ? tag.substring(0, 64) : tag);
                BillingFlowParams p = b.build();
                act.runOnUiThread(() -> client.launchBillingFlow(act, p));
            });
        });
    }

    @Override
    public void onPurchasesUpdated(BillingResult r, List<Purchase> purchases) {
        int code = r.getResponseCode();
        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase p : purchases) handle(p, lastReq, false);
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            send(lastReq, false, null, null, "cancel", false);
        } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            // the last purchase of this item is still being delivered: deliver it now, and tell the player to try again in a moment
            send(lastReq, false, null, null, "owned", false);
            restore("");
        } else {
            send(lastReq, false, null, null, "error", false);
        }
    }

    private void handle(Purchase p, String req, boolean restored) {
        String pid = p.getProducts().isEmpty() ? "" : p.getProducts().get(0);
        if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) send(req, true, pid, p.getPurchaseToken(), null, restored);
        else if (p.getPurchaseState() == Purchase.PurchaseState.PENDING && !restored) send(req, false, pid, null, "pending", false);
    }

    @JavascriptInterface
    public void finish(final String token, final String consume) {
        connect(() -> {
            if ("1".equals(consume)) {
                client.consumeAsync(ConsumeParams.newBuilder().setPurchaseToken(token).build(), (r, t) -> { });
            } else {
                client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(token).build(), r -> { });
            }
        });
    }

    @JavascriptInterface
    public void restore(String unused) {
        connect(() -> client.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(),
                (r, list) -> {
                    if (r.getResponseCode() != BillingClient.BillingResponseCode.OK || list == null) return;
                    for (Purchase p : list) {
                        // consumables that were never consumed, and one-time items that were never acknowledged
                        if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) handle(p, "", true);
                    }
                }));
    }

    @JavascriptInterface
    public void prices(final String csv) {
        if (csv == null || csv.isEmpty()) return;
        connect(() -> {
            List<QueryProductDetailsParams.Product> L = new ArrayList<>();
            for (String id : csv.split(",")) {
                String t = id.trim();
                if (!t.isEmpty()) L.add(QueryProductDetailsParams.Product.newBuilder().setProductId(t).setProductType(BillingClient.ProductType.INAPP).build());
            }
            if (L.isEmpty()) return;
            client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(L).build(), (r, list) -> {
                if (r.getResponseCode() != BillingClient.BillingResponseCode.OK || list == null) return;
                try {
                    JSONObject o = new JSONObject();
                    for (ProductDetails pd : list) {
                        ProductDetails.OneTimePurchaseOfferDetails d = pd.getOneTimePurchaseOfferDetails();
                        if (d != null) o.put(pd.getProductId(), d.getFormattedPrice());
                    }
                    final String js = "window.nmBillPrices&&nmBillPrices(" + o.toString() + ")";
                    act.runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
                } catch (Exception ignored) { }
            });
        });
    }

    private void send(String req, boolean ok, String pid, String token, String err, boolean restored) {
        try {
            JSONObject o = new JSONObject();
            o.put("req", req == null ? "" : req);
            o.put("ok", ok);
            if (pid != null) o.put("pid", pid);
            if (token != null) o.put("token", token);
            if (err != null) o.put("err", err);
            o.put("restored", restored);
            final String js = "window.nmBillDone&&nmBillDone(" + o.toString() + ")";
            act.runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
        } catch (Exception ignored) { }
    }

    void end() { try { client.endConnection(); } catch (Throwable ignored) { } }
}
