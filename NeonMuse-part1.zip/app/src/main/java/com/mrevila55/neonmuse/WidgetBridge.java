package com.mrevila55.neonmuse;

import android.content.Context;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.io.File;

/**
 * The game hands the widgets (and the watch) a fresh snapshot whenever you leave it or something changes.
 * window.NMWidget: save(json), image(name, dataUrl), refresh(), takeCuddles().
 */
public class WidgetBridge {
    private final Context c;
    private long lastRefresh = 0;

    WidgetBridge(Context c) { this.c = c.getApplicationContext(); }

    @JavascriptInterface
    public void save(String json) {
        if (json == null || json.length() > 200_000) return;
        try {
            JSONObject d = new JSONObject(json);
            WidgetStore.writeText(c, "data.json", json);
            WidgetStore.gameSteps(c, d.optString("day"), d.optLong("steps", 0));
            WearSync.push(c, d);
        } catch (Exception ignored) { }
    }

    /** name is muse, head or pet; an empty picture removes it (no companion out). */
    @JavascriptInterface
    public void image(String name, String dataUrl) {
        if (name == null || !name.matches("muse|head|pet")) return;
        if (dataUrl == null || dataUrl.isEmpty()) { new File(WidgetStore.dir(c), name + ".png").delete(); return; }
        int k = dataUrl.indexOf("base64,");
        if (k < 0 || dataUrl.length() > 6_000_000) return;
        try {
            byte[] b = Base64.decode(dataUrl.substring(k + 7), Base64.DEFAULT);
            WidgetStore.writeBytes(c, name + ".png", b);
            if ("pet".equals(name)) WearSync.pushPet(c, b);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void refresh(String unused) {
        long now = System.currentTimeMillis();
        if (now - lastRefresh < 1500) return;
        lastRefresh = now;
        if (WidgetBase.any(c)) WidgetBase.refreshAll(c);
    }

    @JavascriptInterface
    public int takeCuddles(String unused) { return WidgetStore.takeCuddles(c); }

    /** Whether any of the widgets is on the home screen (the game only makes widget pictures when one is). */
    @JavascriptInterface
    public String placed() { return WidgetBase.any(c) ? "1" : "0"; }
}
