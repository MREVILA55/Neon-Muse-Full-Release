package com.mrevila55.neonmuse;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * What the home screen widgets and the watch show: a small snapshot the game writes whenever you leave it
 * (files/widget/data.json plus portrait, head and companion pictures), today's steps from the phone and the watch,
 * and the cuddles given from the widget that the game hasn't collected yet.
 */
final class WidgetStore {
    private WidgetStore() { }

    static File dir(Context c) { File d = new File(c.getFilesDir(), "widget"); if (!d.exists()) d.mkdirs(); return d; }
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("nm_widget", Context.MODE_PRIVATE); }
    static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    static synchronized void writeText(Context c, String name, String text) {
        File tmp = new File(dir(c), name + ".tmp"), dst = new File(dir(c), name);
        try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(text.getBytes(StandardCharsets.UTF_8)); } catch (Exception e) { tmp.delete(); return; }
        if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst); }
    }

    static synchronized void writeBytes(Context c, String name, byte[] data) {
        File tmp = new File(dir(c), name + ".tmp"), dst = new File(dir(c), name);
        try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(data); } catch (Exception e) { tmp.delete(); return; }
        if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst); }
    }

    static byte[] readBytes(Context c, String name) {
        File f = new File(dir(c), name);
        if (!f.exists()) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[32768]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        } catch (Exception e) { return null; }
    }

    static JSONObject data(Context c) {
        byte[] b = readBytes(c, "data.json");
        if (b == null) return null;
        try { return new JSONObject(new String(b, StandardCharsets.UTF_8)); } catch (Exception e) { return null; }
    }

    static Bitmap image(Context c, String name) {
        byte[] b = readBytes(c, name + ".png");
        if (b == null || b.length == 0) return null;
        try { return BitmapFactory.decodeByteArray(b, 0, b.length); } catch (Throwable t) { return null; }
    }

    // ---- steps: the phone's sensor (total since boot) and the watch's daily count ----
    /** Called with the phone's raw step counter; keeps today's count in step with what the game last saw. */
    static synchronized void phoneRaw(Context c, long raw) {
        SharedPreferences p = prefs(c); String d = today();
        SharedPreferences.Editor e = p.edit();
        if (!d.equals(p.getString("pDay", ""))) { e.putString("pDay", d).putLong("pBase", raw).putLong("pToday", 0); }
        else {
            long base = p.getLong("pBase", raw);
            if (raw < base) base = raw - p.getLong("pToday", 0);        // the phone restarted: keep counting from where we were
            e.putLong("pBase", base).putLong("pToday", Math.max(p.getLong("pToday", 0), raw - base));
        }
        e.putLong("pRaw", raw).apply();
    }

    /** The game tells us how many steps it counted today, so the widget starts from the same number. */
    static synchronized void gameSteps(Context c, String day, long steps) {
        SharedPreferences p = prefs(c);
        if (!today().equals(day)) return;
        long raw = p.getLong("pRaw", -1);
        SharedPreferences.Editor e = p.edit().putString("pDay", day).putLong("pToday", Math.max(steps, p.getLong("pToday", 0)));
        if (raw >= 0) e.putLong("pBase", raw - Math.max(steps, p.getLong("pToday", 0)));
        e.apply();
    }

    static synchronized void watchSteps(Context c, String day, long steps) {
        prefs(c).edit().putString("wDay", day).putLong("wToday", steps).apply();
    }

    static long stepsToday(Context c) {
        SharedPreferences p = prefs(c); String d = today();
        long ph = d.equals(p.getString("pDay", "")) ? p.getLong("pToday", 0) : 0;
        long w = d.equals(p.getString("wDay", "")) ? p.getLong("wToday", 0) : 0;
        return Math.max(ph, w);
    }

    // ---- cuddles given from the widget ----
    static synchronized int addCuddle(Context c) {
        SharedPreferences p = prefs(c); int n = p.getInt("cuddles", 0) + 1;
        p.edit().putInt("cuddles", n).putLong("cuddleAt", System.currentTimeMillis()).apply();
        return n;
    }

    static synchronized int takeCuddles(Context c) {
        SharedPreferences p = prefs(c); int n = p.getInt("cuddles", 0);
        p.edit().putInt("cuddles", 0).apply();
        return n;
    }

    static long lastCuddle(Context c) { return prefs(c).getLong("cuddleAt", 0); }
}
