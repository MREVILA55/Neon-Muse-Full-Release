package com.mrevila55.neonmuse;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import com.google.android.gms.games.PlayGamesSdk;
import android.window.OnBackInvokedDispatcher;

/** Neon Muse: shows the game (app/src/main/assets/www) full screen. */
public class MainActivity extends Activity {

    private WebView web;
    private StepCounter steps;
    private PlaceHelper place;
    private BillingBridge billing;
    private NotifyBridge notify;
    private boolean loaded = false;
    private String pendingDeep = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try { PlayGamesSdk.initialize(this); } catch (Throwable ignored) { }   // cloud save (Google Play Games)

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#120C16"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#120C16"));
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Draw behind the system bars on every Android version, then pad the game to the safe area (below)
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        // Keep the game clear of the status bar, navigation bar and camera cutout
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                l = i.left; t = i.top; r = i.right; b = i.bottom;
            } else {
                l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(l, t, r, b);
            return insets;
        });
        root.requestApplyInsets();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // saves the game
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                loaded = true;
                deliverDeep();
                deliverWatchSteps();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;   // the game itself
                try {                                              // links open in the browser
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        // Back closes an open window in the game first; otherwise the game goes to the background (it keeps its save)
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }

        web.addJavascriptInterface(new SaveBridge(this), "NMSave");   // a second copy of the save in the app's files (see SaveBridge.java)
        web.addJavascriptInterface(new CloudSave(this, web), "NMCloud");   // only the game inside the app can call it
        steps = new StepCounter(this, web);
        web.addJavascriptInterface(steps, "NMSteps");   // step rewards (see StepCounter.java)
        place = new PlaceHelper(this, web);
        web.addJavascriptInterface(place, "NMPlace");   // Muses comment on your city (see PlaceHelper.java)
        billing = new BillingBridge(this, web);
        web.addJavascriptInterface(billing, "NMBilling");   // in-app purchases (see BillingBridge.java)
        web.addJavascriptInterface(new WidgetBridge(this), "NMWidget");   // home screen widgets and the watch (see WidgetBridge.java)
        notify = new NotifyBridge(this, web);
        web.addJavascriptInterface(notify, "NMNotify");   // opt-in reminders (see NotifyBridge.java)
        web.addJavascriptInterface(new ShareBridge(this), "NMShare");   // share cards and invites
        web.addJavascriptInterface(new GamesBridge(this), "NMGames");   // Google Play Games leaderboards
        web.addJavascriptInterface(new RefBridge(this, web), "NMRef");   // invite codes from Google Play install links
        NotifyBridge.channel(this);
        pendingDeep = deepOf(getIntent());

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("file:///android_asset/www/index.html");
    }

    /** A widget or reminder can open a part of the game: muse:today, muse:chat, pets, summon, steps, invite. */
    private static String deepOf(Intent i) {
        String d = i == null ? null : i.getStringExtra("deep");
        return d == null || d.isEmpty() || !d.matches("[a-z:]{1,24}") ? null : d;
    }

    private void deliverDeep() {
        if (!loaded || web == null || pendingDeep == null) return;
        final String d = pendingDeep;
        pendingDeep = null;
        web.evaluateJavascript("window.nmDeep&&nmDeep('" + d + "')", null);
    }

    /** The watch's step count for today (the game keeps the higher of the phone's and the watch's). */
    private void deliverWatchSteps() {
        if (!loaded || web == null) return;
        android.content.SharedPreferences p = WidgetStore.prefs(this);
        String day = WidgetStore.today();
        if (!day.equals(p.getString("wDay", ""))) return;
        long n = p.getLong("wToday", 0);
        if (n > 0) web.evaluateJavascript("window.nmWatchSteps&&nmWatchSteps('" + day + "'," + n + ")", null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String d = deepOf(intent);
        if (d != null) { pendingDeep = d; deliverDeep(); }
    }

    private void handleBack() {
        if (web == null) { moveTaskToBack(true); return; }
        web.evaluateJavascript(
                "(function(){try{var m=document.getElementById('modal');"
                + "if(m&&m.classList.contains('on')&&typeof closeModal==='function'){closeModal();return 1;}}catch(e){}return 0;})()",
                value -> { if (!"1".equals(value)) moveTaskToBack(true); });
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {   // Android 12 and older
        handleBack();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onPause() {
        // save right away (and copy the save to the app's files) before the game is paused
        if (web != null) web.evaluateJavascript("window.nmPause&&nmPause()", null);
        if (steps != null) steps.stop();
        if (web != null) { web.onPause(); web.pauseTimers(); }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) { web.resumeTimers(); web.onResume(); }
        if (steps != null) steps.start();
        deliverWatchSteps();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == StepCounter.REQ && steps != null)
            steps.onPermission(res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED);
        if (code == PlaceHelper.REQ && place != null)
            place.onPermission(res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED);
        if (code == NotifyBridge.REQ && notify != null)
            notify.onPermission(res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED);
    }

    @Override
    protected void onDestroy() {
        if (billing != null) billing.end();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
