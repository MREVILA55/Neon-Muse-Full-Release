package com.mrevila55.neonmuse;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Opt-in reminders. The game decides what to say and when (at most two a day, nothing at night) and hands them over
 * with schedule(); clear() removes everything planned. window.NMNotify: available(), permission(), request(),
 * schedule(id, atMillis, title, text, deepLink), clear().
 */
public class NotifyBridge {
    static final int REQ = 7043;
    static final String CHANNEL = "muse";
    private final Activity act;
    private final WebView web;

    NotifyBridge(Activity act, WebView web) { this.act = act; this.web = web; }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("nm_notify", Context.MODE_PRIVATE); }

    static boolean granted(Context c) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm == null || nm.areNotificationsEnabled();
    }

    static void channel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, c.getString(R.string.notify_channel), NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription(c.getString(R.string.notify_channel_about));
        ch.enableLights(true); ch.setLightColor(0xFFFF5FD2);
        nm.createNotificationChannel(ch);
    }

    @JavascriptInterface
    public String available() { return "1"; }

    @JavascriptInterface
    public String permission() {
        if (granted(act)) return "granted";
        return prefs(act).getBoolean("asked", false) ? "denied" : "prompt";
    }

    @JavascriptInterface
    public void request(String unused) {
        act.runOnUiThread(() -> {
            channel(act);
            if (granted(act)) { js("window.nmNotifyPerm&&nmNotifyPerm(true)"); return; }
            if (Build.VERSION.SDK_INT >= 33 && !prefs(act).getBoolean("asked", false)) {
                prefs(act).edit().putBoolean("asked", true).apply();
                act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ);
                return;
            }
            // turned off for the app in Android's settings: open that page so the player can turn them on
            try {
                Intent i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", act.getPackageName());
                act.startActivity(i);
            } catch (Exception e) { js("window.nmNotifyPerm&&nmNotifyPerm(false)"); }
        });
    }

    void onPermission(boolean ok) { js("window.nmNotifyPerm&&nmNotifyPerm(" + ok + ")"); }

    @JavascriptInterface
    public void schedule(String id, String at, String title, String text, String deep) {
        try {
            int n = Integer.parseInt(id);
            long when = Long.parseLong(at);
            if (n < 1 || n > 50 || when < System.currentTimeMillis()) return;
            JSONObject o = new JSONObject().put("id", n).put("at", when).put("ti", clip(title, 80)).put("tx", clip(text, 240)).put("dp", clip(deep, 40));
            SharedPreferences p = prefs(act);
            JSONArray all = new JSONArray(p.getString("plan", "[]")), keep = new JSONArray();
            for (int k = 0; k < all.length(); k++) if (all.getJSONObject(k).optInt("id") != n) keep.put(all.getJSONObject(k));
            keep.put(o);
            p.edit().putString("plan", keep.toString()).apply();
            arm(act, o);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void clear(String unused) {
        try {
            SharedPreferences p = prefs(act);
            JSONArray all = new JSONArray(p.getString("plan", "[]"));
            AlarmManager am = (AlarmManager) act.getSystemService(Context.ALARM_SERVICE);
            for (int k = 0; k < all.length(); k++) am.cancel(pending(act, all.getJSONObject(k).optInt("id"), null));
            p.edit().putString("plan", "[]").apply();
            NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancelAll();   // you're here now, so the old ones aren't needed
        } catch (Exception ignored) { }
    }

    static PendingIntent pending(Context c, int id, JSONObject o) {
        Intent i = new Intent(c, NotifyReceiver.class).setAction(NotifyReceiver.ACTION_SHOW + "." + id);
        if (o != null) i.putExtra("id", id).putExtra("ti", o.optString("ti")).putExtra("tx", o.optString("tx")).putExtra("dp", o.optString("dp"));
        return PendingIntent.getBroadcast(c, 900 + id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** An inexact alarm is all a reminder needs, so no special alarm permission is required. */
    static void arm(Context c, JSONObject o) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = o.optLong("at");
        if (at < System.currentTimeMillis()) return;
        PendingIntent pi = pending(c, o.optInt("id"), o);
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC, at, pi);
        else am.set(AlarmManager.RTC, at, pi);
    }

    /** After a restart Android forgets alarms; put the plan back. */
    static void rearm(Context c) {
        try {
            JSONArray all = new JSONArray(prefs(c).getString("plan", "[]"));
            for (int k = 0; k < all.length(); k++) arm(c, all.getJSONObject(k));
        } catch (Exception ignored) { }
    }

    private static String clip(String s, int n) { s = s == null ? "" : s; return s.length() > n ? s.substring(0, n) : s; }

    private void js(final String code) { act.runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); }); }
}
