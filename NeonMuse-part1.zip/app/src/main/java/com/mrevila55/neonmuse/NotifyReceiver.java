package com.mrevila55.neonmuse;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Build;

import org.json.JSONArray;

/** Shows a planned reminder (BootReceiver puts the plan back after the phone restarts). */
public class NotifyReceiver extends BroadcastReceiver {
    static final String ACTION_SHOW = "com.mrevila55.neonmuse.NOTIFY";

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        if (a == null) return;
        if (!a.startsWith(ACTION_SHOW)) return;
        int id = i.getIntExtra("id", 0);
        forget(c, id);
        if (!NotifyBridge.granted(c)) return;
        NotifyBridge.channel(c);
        String dp = i.getStringExtra("dp");
        Intent open = new Intent(c, MainActivity.class).setAction(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("deep", dp == null ? "" : dp);
        PendingIntent pi = PendingIntent.getActivity(c, 1200 + id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, NotifyBridge.CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_stat_neon).setColor(0xFFFF5FD2)
                .setContentTitle(i.getStringExtra("ti")).setContentText(i.getStringExtra("tx"))
                .setStyle(new Notification.BigTextStyle().bigText(i.getStringExtra("tx")))
                .setContentIntent(pi).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER);
        // the Muse's face, unless Discreet widgets is on
        org.json.JSONObject d = WidgetStore.data(c);
        if (d != null && !d.optBoolean("disc") && (id == 1 || id == 2)) {
            Bitmap h = WidgetStore.image(c, "head");
            if (h != null) b.setLargeIcon(circle(h));
        }
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) try { nm.notify(id, b.build()); } catch (SecurityException ignored) { }
    }

    private static void forget(Context c, int id) {
        try {
            SharedPreferences p = NotifyBridge.prefs(c);
            JSONArray all = new JSONArray(p.getString("plan", "[]")), keep = new JSONArray();
            for (int k = 0; k < all.length(); k++) if (all.getJSONObject(k).optInt("id") != id) keep.put(all.getJSONObject(k));
            p.edit().putString("plan", keep.toString()).apply();
        } catch (Exception ignored) { }
    }

    private static Bitmap circle(Bitmap s) {
        int n = Math.min(s.getWidth(), s.getHeight());
        Bitmap o = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new BitmapShader(s, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        new Canvas(o).drawCircle(n / 2f, n / 2f, n / 2f, p);
        return o;
    }
}
