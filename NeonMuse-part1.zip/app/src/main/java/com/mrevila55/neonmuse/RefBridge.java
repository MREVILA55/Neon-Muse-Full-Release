package com.mrevila55.neonmuse;

import android.app.Activity;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import com.android.installreferrer.api.ReferrerDetails;

import org.json.JSONObject;

/**
 * Invites: when someone installs from a friend's invite link, Google Play passes the friend's code along
 * (referrer=invite=NM-XXXXXX). The game reads it once with window.NMRef.check() and gets nmReferrer(text).
 */
public class RefBridge {
    private final Activity act;
    private final WebView web;

    RefBridge(Activity act, WebView web) { this.act = act; this.web = web; }

    @JavascriptInterface
    public void check(String unused) {
        final SharedPreferences p = act.getSharedPreferences("nm_ref", Activity.MODE_PRIVATE);
        if (p.contains("ref")) { deliver(p.getString("ref", "")); return; }
        if (p.getInt("tries", 0) >= 5) return;
        p.edit().putInt("tries", p.getInt("tries", 0) + 1).apply();
        act.runOnUiThread(() -> {
            try {
                final InstallReferrerClient rc = InstallReferrerClient.newBuilder(act).build();
                rc.startConnection(new InstallReferrerStateListener() {
                    @Override
                    public void onInstallReferrerSetupFinished(int code) {
                        try {
                            if (code == InstallReferrerClient.InstallReferrerResponse.OK) {
                                ReferrerDetails d = rc.getInstallReferrer();
                                String ref = d == null || d.getInstallReferrer() == null ? "" : d.getInstallReferrer();
                                p.edit().putString("ref", ref).apply();
                                deliver(ref);
                            } else if (code == InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED) {
                                p.edit().putString("ref", "").apply();
                            }
                        } catch (Exception ignored) { }
                        try { rc.endConnection(); } catch (Exception ignored) { }
                    }

                    @Override
                    public void onInstallReferrerServiceDisconnected() { }
                });
            } catch (Throwable ignored) { }
        });
    }

    private void deliver(String ref) {
        if (ref == null || ref.isEmpty() || ref.startsWith("utm_source=google-play&utm_medium=organic")) return;
        final String q = JSONObject.quote(ref);
        act.runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.nmReferrer&&nmReferrer(" + q + ")", null); });
    }
}
