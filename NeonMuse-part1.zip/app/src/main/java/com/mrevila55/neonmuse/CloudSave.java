package com.mrevila55.neonmuse;

import android.app.Activity;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.android.gms.games.AuthenticationResult;
import com.google.android.gms.games.GamesSignInClient;
import com.google.android.gms.games.PlayGames;
import com.google.android.gms.games.SnapshotsClient;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.games.snapshot.SnapshotMetadataChange;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Cloud save through Google Play Games "saved games". The game talks to it with window.NMCloud:
 *   signIn(id,"")  shows the Google Play Games sign-in if needed
 *   load(id,"")    reads the cloud save (silent: answers err "signin" when nobody is signed in)
 *   save(id,b64)   writes the cloud save (b64 = the save text, UTF-8, Base64)
 * Every call answers by running nmCloudDone(id, base64-of-a-JSON-answer) in the game.
 */
public class CloudSave {
    private static final String SNAP = "neonmuse_save";
    private final Activity act;
    private final WebView web;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    CloudSave(Activity act, WebView web) { this.act = act; this.web = web; }

    private void reply(String id, JSONObject o) {
        final String b64 = Base64.encodeToString(o.toString().getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        act.runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript("window.nmCloudDone&&nmCloudDone('" + id + "','" + b64 + "')", null);
        });
    }

    private void answer(String id, boolean ok, String err, String data) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (err != null) o.put("err", err);
            if (data != null) o.put("data", data);
            reply(id, o);
        } catch (Exception ignored) { }
    }

    /** Runs next(true) when a Google Play Games player is signed in, else next(false). */
    private interface Auth { void done(boolean signedIn); }

    private void check(boolean interactive, Auth next) {
        try {
            final GamesSignInClient c = PlayGames.getGamesSignInClient(act);
            c.isAuthenticated().addOnCompleteListener(t -> {
                AuthenticationResult r = t.isSuccessful() ? t.getResult() : null;
                if (r != null && r.isAuthenticated()) { next.done(true); return; }
                if (!interactive) { next.done(false); return; }
                c.signIn().addOnCompleteListener(t2 -> {
                    AuthenticationResult r2 = t2.isSuccessful() ? t2.getResult() : null;
                    next.done(r2 != null && r2.isAuthenticated());
                });
            });
        } catch (Throwable e) {
            next.done(false);
        }
    }

    @JavascriptInterface
    public void signIn(final String id, String unused) {
        act.runOnUiThread(() -> check(true, ok -> answer(id, ok, ok ? null : "signin", null)));
    }

    @JavascriptInterface
    public void load(final String id, String unused) {
        act.runOnUiThread(() -> check(false, ok -> {
            if (!ok) { answer(id, false, "signin", null); return; }
            final SnapshotsClient sc = PlayGames.getSnapshotsClient(act);
            sc.open(SNAP, true, SnapshotsClient.RESOLUTION_POLICY_MOST_RECENTLY_MODIFIED).addOnCompleteListener(t -> {
                if (!t.isSuccessful() || t.getResult() == null || t.getResult().isConflict()) { answer(id, false, "network", null); return; }
                final Snapshot snap = t.getResult().getData();
                io.execute(() -> {
                    try {
                        byte[] b = snap.getSnapshotContents().readFully();
                        sc.discardAndClose(snap);
                        answer(id, true, null, b == null || b.length == 0 ? null : new String(b, StandardCharsets.UTF_8));
                    } catch (Throwable e) {
                        try { sc.discardAndClose(snap); } catch (Throwable ignored) { }
                        answer(id, false, "error", null);
                    }
                });
            });
        }));
    }

    @JavascriptInterface
    public void save(final String id, final String b64) {
        act.runOnUiThread(() -> check(false, ok -> {
            if (!ok) { answer(id, false, "signin", null); return; }
            final SnapshotsClient sc = PlayGames.getSnapshotsClient(act);
            sc.open(SNAP, true, SnapshotsClient.RESOLUTION_POLICY_MOST_RECENTLY_MODIFIED).addOnCompleteListener(t -> {
                if (!t.isSuccessful() || t.getResult() == null || t.getResult().isConflict()) { answer(id, false, "network", null); return; }
                final Snapshot snap = t.getResult().getData();
                io.execute(() -> {
                    try {
                        byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                        snap.getSnapshotContents().writeBytes(bytes);
                        SnapshotMetadataChange meta = new SnapshotMetadataChange.Builder()
                                .setDescription("Neon Muse progress").build();
                        sc.commitAndClose(snap, meta).addOnCompleteListener(t2 ->
                                answer(id, t2.isSuccessful(), t2.isSuccessful() ? null : "network", null));
                    } catch (Throwable e) {
                        try { sc.discardAndClose(snap); } catch (Throwable ignored) { }
                        answer(id, false, "error", null);
                    }
                });
            });
        }));
    }
}
