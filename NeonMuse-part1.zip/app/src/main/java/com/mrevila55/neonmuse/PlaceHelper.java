package com.mrevila55.neonmuse;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * "Where you are" comments: with the player's permission, reads the phone's approximate (city-level) location and turns it
 * into a place name (city, region, country) with Android's Geocoder. Only the place name goes to the game, never the
 * coordinates, and it stays on the phone. The game talks to it with window.NMPlace: available(), permission(), request(), lookup().
 * Answers arrive in the game as nmPlace({city,region,country}) or nmPlace(null).
 */
public class PlaceHelper {
    static final int REQ = 7042;
    private final Activity act;
    private final WebView web;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    PlaceHelper(Activity act, WebView web) { this.act = act; this.web = web; }

    private boolean granted() {
        return act.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public String available() { return Geocoder.isPresent() ? "1" : "0"; }

    @JavascriptInterface
    public String permission() { return granted() ? "granted" : "prompt"; }

    @JavascriptInterface
    public void request(String unused) {
        act.runOnUiThread(() -> {
            if (granted()) { lookup(""); return; }
            act.requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ);
        });
    }

    /** Called from MainActivity.onRequestPermissionsResult. */
    void onPermission(boolean ok) {
        if (ok) lookup("");
        else js("window.nmPlace&&nmPlace(null)");
    }

    @JavascriptInterface
    public void lookup(String unused) {
        if (!granted()) { js("window.nmPlace&&nmPlace(null)"); return; }
        io.execute(() -> {
            try {
                LocationManager lm = (LocationManager) act.getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                if (lm != null) {
                    for (String p : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER}) {
                        try {
                            Location l = lm.getLastKnownLocation(p);
                            if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                        } catch (SecurityException | IllegalArgumentException ignored) { }
                    }
                }
                if (best == null) { js("window.nmPlace&&nmPlace(null)"); return; }
                Geocoder g = new Geocoder(act, Locale.getDefault());
                @SuppressWarnings("deprecation")
                List<Address> list = g.getFromLocation(best.getLatitude(), best.getLongitude(), 1);
                if (list == null || list.isEmpty()) { js("window.nmPlace&&nmPlace(null)"); return; }
                Address a = list.get(0);
                JSONObject o = new JSONObject();
                o.put("city", a.getLocality() != null ? a.getLocality() : (a.getSubAdminArea() != null ? a.getSubAdminArea() : ""));
                o.put("region", a.getAdminArea() != null ? a.getAdminArea() : "");
                o.put("country", a.getCountryName() != null ? a.getCountryName() : "");
                js("window.nmPlace&&nmPlace(" + o.toString() + ")");
            } catch (Throwable e) {
                js("window.nmPlace&&nmPlace(null)");
            }
        });
    }

    private void js(final String code) {
        act.runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }
}
