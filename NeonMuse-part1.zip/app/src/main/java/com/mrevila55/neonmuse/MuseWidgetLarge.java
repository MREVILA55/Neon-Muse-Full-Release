package com.mrevila55.neonmuse;

/** The large Muse widget (4x4): the same widget with room for the group chat, your streak, the daily gift and Spotlights. */
public class MuseWidgetLarge extends MuseWidget {
    @Override int defW() { return 250; }
    @Override int defH() { return 280; }
}
