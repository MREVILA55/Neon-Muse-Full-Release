package com.mrevila55.neonmuse;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Draws the widgets as one crisp picture at the widget's exact size in pixels (dark glass, neon edge, the Muse or companion art),
 * so they look the same on every launcher and stay sharp at any size.
 */
final class WidgetArt {
    private WidgetArt() { }

    static final int PINK = Color.rgb(255, 95, 210), CYAN = Color.rgb(95, 243, 255), GOLD = Color.rgb(255, 209, 102);
    private static final Typeface BOLD = Typeface.create("sans-serif", Typeface.BOLD);
    private static final Typeface MED = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private static final Typeface REG = Typeface.create("sans-serif", Typeface.NORMAL);

    static float dp(Context c, float v) { return v * c.getResources().getDisplayMetrics().density; }

    // ---- day and night: the card's glass takes the colour of the sky outside, like the game's stage ----
    private static float smooth(float a, float b, float x) { float t = Math.max(0f, Math.min(1f, (x - a) / (b - a))); return t * t * (3 - 2 * t); }
    private static int mix(int a, int b, float t) {
        return Color.rgb(Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t), Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t), Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    /** {night 0..1, sunrise or sunset glow 0..1, where the light comes from 0 = left .. 1 = right}. Sunrise and sunset move with the
     *  seasons and summer time, the same way the game works them out; all zero when the player turned the clock light off. */
    static float[] daylight(Context c) {
        JSONObject d = WidgetStore.data(c);
        if (d != null && !d.optBoolean("dn", true)) return new float[]{0, 0, 0.5f};
        Calendar k = Calendar.getInstance();
        float h = k.get(Calendar.HOUR_OF_DAY) + k.get(Calendar.MINUTE) / 60f;
        boolean dst = k.getTimeZone().inDaylightTime(k.getTime());
        double len = 12 + 2.3 * Math.cos(2 * Math.PI * (k.get(Calendar.DAY_OF_YEAR) - 1 - 172) / 365.25);
        if (d != null && "south".equals(d.optString("hemi"))) len = 24 - len;
        float noon = dst ? 13f : 12f, sr = (float) (noon - len / 2), ss = (float) (noon + len / 2);
        float night = h < noon ? 1 - smooth(sr - 1.0f, sr + 0.4f, h) : smooth(ss - 0.2f, ss + 1.3f, h);
        float warm = Math.max(1 - Math.abs(h - (sr + 0.1f)) / 1.1f, 1 - Math.abs(h - ss) / 1.2f);
        return new float[]{night, Math.max(0f, Math.min(1f, warm)), h < noon ? 0.15f : 0.85f};
    }

    /** The dark glass card every widget sits on. */
    static void card(Canvas cv, Context c, int w, int h, float radius, int glow) {
        RectF r = new RectF(0, 0, w, h);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float[] sky = daylight(c);
        int top = mix(mix(Color.rgb(44, 18, 68), Color.rgb(14, 18, 58), sky[0]), Color.rgb(84, 30, 76), sky[1] * 0.55f);
        int bottom = mix(Color.rgb(17, 8, 32), Color.rgb(8, 8, 26), sky[0]);
        p.setShader(new LinearGradient(0, 0, w * 0.35f, h, (240 << 24) | (top & 0xFFFFFF), (240 << 24) | (bottom & 0xFFFFFF), Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, radius, radius, p);
        if (sky[1] > 0.02f) {   // the low sun: a warm glow rising from its side
            p.setShader(new RadialGradient(w * sky[2], h * 1.05f, Math.max(w, h) * 0.85f, Color.argb(Math.round(80 * sky[1]), 255, 128, 84), Color.TRANSPARENT, Shader.TileMode.CLAMP));
            cv.drawRoundRect(r, radius, radius, p);
        }
        if (sky[0] > 0.02f) {   // night: a pale moon glow and a few stars
            p.setShader(new RadialGradient(w * 0.82f, 0, Math.max(w, h) * 0.6f, Color.argb(Math.round(46 * sky[0]), 150, 180, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP));
            cv.drawRoundRect(r, radius, radius, p);
            p.setShader(null);
            float u = dp(c, 1);
            for (int i = 0; i < 16; i++) {
                float x = (float) ((i * 0.6180339 + 0.13) % 1.0) * w, y = (float) ((i * 0.4142135 + 0.71) % 1.0) * h * 0.55f;
                p.setColor(Color.argb(Math.round((70 + (i % 4) * 30) * sky[0] * (1 - y / (h * 0.6f))), 255, 255, 255));
                cv.drawCircle(x, y, (0.7f + (i % 3) * 0.35f) * u, p);
            }
        }
        p.setShader(new RadialGradient(w * 0.15f, h, Math.max(w, h) * 0.9f, Color.argb(60, Color.red(glow), Color.green(glow), Color.blue(glow)), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, radius, radius, p);
        p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(c, 1.2f)); p.setColor(Color.argb(110, 255, 120, 210));
        float i = p.getStrokeWidth() / 2f;
        cv.drawRoundRect(new RectF(i, i, w - i, h - i), radius - i, radius - i, p);
    }

    static TextPaint text(Context c, float sp, int color, Typeface tf) {
        TextPaint t = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        t.setTextSize(android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP, sp, c.getResources().getDisplayMetrics()));   // follows the phone's font size
        t.setColor(color); t.setTypeface(tf); return t;
    }

    /** Breaks text into lines that fit maxW. */
    static List<String> wrap(String s, TextPaint t, float maxW) {
        List<String> lines = new ArrayList<>();
        if (s == null || s.isEmpty()) return lines;
        StringBuilder line = new StringBuilder();
        for (String w : s.split(" ")) {
            String tryL = line.length() == 0 ? w : line + " " + w;
            if (t.measureText(tryL) > maxW && line.length() > 0) { lines.add(line.toString()); line = new StringBuilder(w); }
            else line = new StringBuilder(tryL);
        }
        if (line.length() > 0) lines.add(line.toString());
        return lines;
    }

    /** Draws up to maxLines of wrapped text, the last one ending in "…" when there's more. */
    static void para(Canvas cv, List<String> lines, TextPaint t, float x, float y, float maxW, int maxLines) {
        float lh = t.getTextSize() * 1.32f, yy = y;
        for (int k = 0; k < lines.size() && k < maxLines; k++) {
            String l = lines.get(k);
            if (k == maxLines - 1 && lines.size() > maxLines) l = TextUtils.ellipsize(l + " " + lines.get(k + 1), t, maxW, TextUtils.TruncateAt.END).toString();
            else l = TextUtils.ellipsize(l, t, maxW, TextUtils.TruncateAt.END).toString();
            yy += lh; cv.drawText(l, x, yy - t.getTextSize() * 0.3f, t);
        }
    }

    // ---- chips: small rounded labels with a drawn icon (the same on every phone, unlike emoji) ----
    static final int IC_SPARK = 0, IC_LETTER = 1, IC_CHAT = 2;

    static TextPaint chipText(Context c) { return text(c, 11.5f, Color.WHITE, MED); }

    static float chipW(Context c, String s) { return chipText(c).measureText(s) + dp(c, 9) * 2 + dp(c, 15); }

    static void chip(Canvas cv, Context c, int icon, String s, float x, float cy, int col) {
        TextPaint t = chipText(c);
        float pad = dp(c, 9), h = dp(c, 24), w = chipW(c, s);
        RectF r = new RectF(x, cy - h / 2, x + w, cy + h / 2);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.argb(46, Color.red(col), Color.green(col), Color.blue(col))); cv.drawRoundRect(r, h / 2, h / 2, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(c, 1)); p.setColor(Color.argb(120, Color.red(col), Color.green(col), Color.blue(col))); cv.drawRoundRect(r, h / 2, h / 2, p);
        int light = Color.rgb(Math.min(255, Color.red(col) + 60), Math.min(255, Color.green(col) + 60), Math.min(255, Color.blue(col) + 60));
        icon(cv, c, icon, x + pad + dp(c, 5), cy, light);
        t.setColor(light);
        cv.drawText(s, x + pad + dp(c, 15), cy + t.getTextSize() * 0.35f, t);
    }

    static void icon(Canvas cv, Context c, int kind, float cx, float cy, int col) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(col);
        float u = dp(c, 1);
        if (kind == IC_SPARK) {
            Path s = new Path(); float r = 5.2f * u, k = 1.3f * u;
            s.moveTo(cx, cy - r); s.cubicTo(cx + k * 0.3f, cy - k, cx + k, cy - k * 0.3f, cx + r, cy);
            s.cubicTo(cx + k, cy + k * 0.3f, cx + k * 0.3f, cy + k, cx, cy + r);
            s.cubicTo(cx - k * 0.3f, cy + k, cx - k, cy + k * 0.3f, cx - r, cy);
            s.cubicTo(cx - k, cy - k * 0.3f, cx - k * 0.3f, cy - k, cx, cy - r);
            cv.drawPath(s, p);
        } else if (kind == IC_LETTER) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.3f * u); p.setStrokeCap(Paint.Cap.ROUND);
            RectF r = new RectF(cx - 5.5f * u, cy - 4f * u, cx + 5.5f * u, cy + 4f * u);
            cv.drawRoundRect(r, 1.2f * u, 1.2f * u, p);
            Path v = new Path(); v.moveTo(r.left + u, r.top + u); v.cubicTo(cx - 2 * u, cy, cx - u, cy + 0.6f * u, cx, cy + 0.6f * u);
            v.cubicTo(cx + u, cy + 0.6f * u, cx + 2 * u, cy, r.right - u, r.top + u);
            cv.drawPath(v, p);
        } else {
            RectF r = new RectF(cx - 5.5f * u, cy - 4.6f * u, cx + 5.5f * u, cy + 3f * u);
            cv.drawRoundRect(r, 3.4f * u, 3.4f * u, p);
            Path t = new Path(); t.moveTo(cx - 3.2f * u, cy + 2f * u); t.cubicTo(cx - 3.4f * u, cy + 3.6f * u, cx - 4f * u, cy + 4.8f * u, cx - 4.6f * u, cy + 5.6f * u);
            t.cubicTo(cx - 2.6f * u, cy + 5.2f * u, cx - 1.2f * u, cy + 4f * u, cx, cy + 2.4f * u); cv.drawPath(t, p);
        }
    }

    static String fmt(double n) {
        if (n < 1000) return String.valueOf((long) Math.floor(n));
        String[] u = {"K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"};
        int k = -1; while (n >= 1000 && k < u.length - 1) { n /= 1000; k++; }
        return (n >= 100 ? String.valueOf((long) n) : n >= 10 ? String.format(java.util.Locale.US, "%.1f", n) : String.format(java.util.Locale.US, "%.2f", n)).replaceAll("\\.?0+$", "") + u[k];
    }

    static String opt(JSONObject o, String k, String d) { return o == null ? d : o.optString(k, d); }
    static String tx(JSONObject o, String k, String d) { JSONObject t = o == null ? null : o.optJSONObject("tx"); return t == null ? d : t.optString(k, d); }

    /** The line the Muse says right now: rotates through the day. */
    static String line(JSONObject d) {
        JSONArray L = d.optJSONArray("lines");
        if (L == null || L.length() == 0) return "";
        Calendar c = Calendar.getInstance();
        int k = (c.get(Calendar.HOUR_OF_DAY) / 2 + c.get(Calendar.DAY_OF_YEAR)) % L.length();
        return L.optString(k, "");
    }

    /** Group chat messages already sent today (the chat runs from 8 in the morning). */
    static List<JSONObject> chatNow(JSONObject d) {
        List<JSONObject> out = new ArrayList<>();
        if (!WidgetStore.today().equals(d.optString("day"))) return out;
        Calendar c = Calendar.getInstance(); int now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        JSONArray m = d.optJSONArray("chat");
        if (m == null) return out;
        for (int k = 0; k < m.length(); k++) { JSONObject x = m.optJSONObject(k); if (x != null && x.optInt("t", 9999) <= now) out.add(x); }
        return out;
    }

    static int unread(JSONObject d) { return Math.max(0, chatNow(d).size() - d.optInt("seen", 0)); }

    static double sparksWaiting(JSONObject d) {
        double sec = Math.min(d.optDouble("cap", 7200), Math.max(0, (System.currentTimeMillis() - d.optLong("last", System.currentTimeMillis())) / 1000.0));
        return sec * d.optDouble("rate", 0);
    }

    static void drawImageFill(Canvas cv, Bitmap b, RectF dst, boolean alignTop) {
        if (b == null) return;
        float s = Math.max(dst.width() / b.getWidth(), dst.height() / b.getHeight());
        float sw = dst.width() / s, sh = dst.height() / s;
        float sx = (b.getWidth() - sw) / 2f, sy = alignTop ? 0 : (b.getHeight() - sh) / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        cv.drawBitmap(b, new Rect((int) sx, (int) sy, (int) (sx + sw), (int) (sy + sh)), dst, p);
    }

    static void drawFit(Canvas cv, Bitmap b, RectF box) {
        if (b == null) return;
        float s = Math.min(box.width() / b.getWidth(), box.height() / b.getHeight());
        float w = b.getWidth() * s, h = b.getHeight() * s;
        RectF d = new RectF(box.centerX() - w / 2, box.bottom - h, box.centerX() + w / 2, box.bottom);
        cv.drawBitmap(b, null, d, new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
    }

    static int parse(String col, int d) { try { return Color.parseColor(col); } catch (Exception e) { return d; } }

    // ===================== the Muse widget =====================
    static Bitmap muse(Context c, int w, int h) {
        Bitmap bm = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        JSONObject d = WidgetStore.data(c);
        float R = Math.min(dp(c, 26), h / 5f);
        card(cv, c, w, h, R, PINK);
        if (d == null) { empty(cv, c, w, h); return bm; }
        boolean large = h >= dp(c, 250), disc = d.optBoolean("disc");
        float topH = large ? Math.min(h * 0.58f, dp(c, 240)) : h;
        // the portrait (or, with Discreet widgets on, just her face in a circle)
        float pw = Math.min(w * (large ? 0.42f : 0.38f), topH * (large ? 0.75f : 0.95f));
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setShader(new RadialGradient(pw / 2, topH, topH * 0.9f, Color.argb(95, 255, 95, 210), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        cv.save(); Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, pw + R, topH), new float[]{R, R, 0, 0, 0, 0, large ? 0 : R, large ? 0 : R}, Path.Direction.CW);
        cv.clipPath(clip); cv.drawRect(new RectF(0, 0, pw, topH), glow);
        if (disc) {
            Bitmap head = WidgetStore.image(c, "head"); if (head == null) head = WidgetStore.image(c, "pet");
            float rr = Math.min(pw, topH) * 0.36f, cx = pw / 2, cy = topH / 2;
            if (head != null) {
                cv.save(); Path circ = new Path(); circ.addCircle(cx, cy, rr, Path.Direction.CW); cv.clipPath(circ);
                drawImageFill(cv, head, new RectF(cx - rr, cy - rr, cx + rr, cy + rr), false); cv.restore();
                Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG); ring.setStyle(Paint.Style.STROKE); ring.setStrokeWidth(dp(c, 2)); ring.setColor(Color.argb(170, 255, 95, 210));
                cv.drawCircle(cx, cy, rr, ring);
            }
        } else drawImageFill(cv, WidgetStore.image(c, "muse"), new RectF(0, dp(c, 4), pw, topH), true);
        cv.restore();

        // name, mood dot and mood
        float x = pw + dp(c, 12), right = w - dp(c, 14), y = dp(c, 14);
        TextPaint name = text(c, large ? 18 : 16.5f, Color.WHITE, BOLD);
        TextPaint mood = text(c, 12, Color.argb(175, 255, 255, 255), MED);
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG); int mc = parse(d.optString("moodCol"), CYAN);
        float ds = dp(c, 6), base = y + name.getTextSize() * 0.92f;
        dot.setColor(Color.argb(70, Color.red(mc), Color.green(mc), Color.blue(mc))); cv.drawCircle(x + ds, base - name.getTextSize() * 0.36f, ds * 1.6f, dot);
        dot.setColor(mc); cv.drawCircle(x + ds, base - name.getTextSize() * 0.36f, ds, dot);
        float nx = x + ds * 2 + dp(c, 8);
        String nm = TextUtils.ellipsize(d.optString("name"), name, right - nx, TextUtils.TruncateAt.END).toString();
        cv.drawText(nm, nx, base, name);
        String ms = d.optString("mood") + " · ♥ " + d.optInt("bond", 1) + (d.optString("path").isEmpty() ? "" : " · " + d.optString("path"));
        if (large) {
            cv.drawText(TextUtils.ellipsize(ms, mood, right - nx, TextUtils.TruncateAt.END).toString(), nx, base + mood.getTextSize() * 1.55f, mood);
            y = base + mood.getTextSize() * 1.55f + dp(c, 10);
        } else {
            // the fullest version of "Happy · ♥ 12 · Light" that fits, never a cut-off fragment
            float mx = nx + name.measureText(nm) + dp(c, 8);
            String m1 = d.optString("mood"), m2 = m1 + " · ♥ " + d.optInt("bond", 1);
            for (String cand : new String[]{ms, m2, m1}) if (!cand.isEmpty() && mood.measureText(cand) <= right - mx) { cv.drawText(cand, mx, base, mood); break; }
            y = base + dp(c, 10);
        }

        // what's waiting: sparks, today's letter, unread group chat (wraps to a second row when narrow)
        List<Object[]> chips = new ArrayList<>();
        double sp = sparksWaiting(d);
        if (sp >= 1) chips.add(new Object[]{IC_SPARK, fmt(sp) + " " + tx(d, "sparks", "sparks"), PINK});
        if (d.optBoolean("letter")) chips.add(new Object[]{IC_LETTER, tx(d, "letter", "Letter"), CYAN});
        int un = unread(d); if (un > 0) chips.add(new Object[]{IC_CHAT, String.valueOf(un), CYAN});
        float chipH = dp(c, 24), gap = dp(c, 6), avail = right - x;
        List<List<Object[]>> rows = new ArrayList<>();
        for (Object[] ch : chips) {
            float cw = chipW(c, (String) ch[1]);
            if (cw > avail) continue;
            List<Object[]> row = rows.isEmpty() ? null : rows.get(rows.size() - 1);
            float used = 0; if (row != null) for (Object[] o : row) used += chipW(c, (String) o[1]) + gap;
            if (row == null || used + cw > avail) { row = new ArrayList<>(); rows.add(row); }
            row.add(ch);
        }
        // the speech bubble: as many lines as fit between the name and the chips
        TextPaint q = text(c, large ? 14.5f : 13.5f, Color.WHITE, REG);
        float lh = q.getTextSize() * 1.32f, bpadX = dp(c, 10), bpadY = dp(c, 7);
        List<String> lines = wrap(line(d), q, right - x - bpadX * 2);
        int nRows = rows.size(), fit;
        while (true) {
            float chipsTop = topH - dp(c, 12) - nRows * chipH - Math.max(0, nRows - 1) * gap;
            fit = (int) ((chipsTop - dp(c, 8) - y - bpadY * 2) / lh);
            if (fit >= Math.min(3, Math.max(1, lines.size())) || nRows <= 1) break;
            nRows--;   // not enough room: keep the most important chips
        }
        fit = Math.max(1, Math.min(fit, large ? 5 : 4));
        int show = Math.min(lines.size(), fit);
        if (show > 0) {
            RectF bub = new RectF(x - dp(c, 2), y, right, y + show * lh + bpadY * 2);
            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG); bp.setColor(Color.argb(22, 255, 255, 255));
            Path bubble = new Path(); float br = dp(c, 13);
            bubble.addRoundRect(bub, new float[]{dp(c, 4), dp(c, 4), br, br, br, br, br, br}, Path.Direction.CW); cv.drawPath(bubble, bp);
            para(cv, lines, q, bub.left + bpadX, bub.top + bpadY, bub.width() - bpadX * 2, fit);
        }
        for (int r = 0; r < nRows; r++) {
            float cy = topH - dp(c, 12) - (nRows - 1 - r) * (chipH + gap) - chipH / 2, cx = x;
            for (Object[] ch : rows.get(r)) { chip(cv, c, (Integer) ch[0], (String) ch[1], cx, cy, (Integer) ch[2]); cx += chipW(c, (String) ch[1]) + gap; }
        }
        if (!large) return bm;

        // large: the latest group chat messages, then streak, gift and the Spotlight countdown
        float cy = topH + dp(c, 12);
        List<JSONObject> msgs = chatNow(d);
        TextPaint cn = text(c, 12.5f, Color.rgb(255, 185, 236), BOLD), ct = text(c, 12.5f, Color.argb(235, 239, 230, 255), REG);
        int[] cols = {Color.rgb(255, 185, 236), Color.rgb(157, 245, 192), GOLD, CYAN};
        float footTop = h - dp(c, 58);
        int maxMsg = Math.max(0, (int) ((footTop - cy - dp(c, 4)) / (ct.getTextSize() * 1.6f)));
        if (msgs.isEmpty() && maxMsg > 0) {
            TextPaint quiet = text(c, 12.5f, Color.argb(150, 255, 255, 255), REG);
            cv.drawText(TextUtils.ellipsize(tx(d, "quiet", "The group chat is quiet so far today."), quiet, w - dp(c, 32), TextUtils.TruncateAt.END).toString(), dp(c, 16), cy + ct.getTextSize() * 1.1f, quiet);
        }
        for (int k = Math.max(0, msgs.size() - maxMsg), n = 0; k < msgs.size(); k++, n++) {
            JSONObject mm = msgs.get(k); String who = mm.optString("n");
            cn.setColor(cols[Math.abs(who.hashCode()) % cols.length]);
            float yy = cy + ct.getTextSize() * 1.1f + n * ct.getTextSize() * 1.6f;
            cv.drawText(who, dp(c, 16), yy, cn);
            float tx0 = dp(c, 16) + cn.measureText(who) + dp(c, 6);
            cv.drawText(TextUtils.ellipsize(mm.optString("tx"), ct, w - tx0 - dp(c, 16), TextUtils.TruncateAt.END).toString(), tx0, yy, ct);
        }
        Paint ln = new Paint(); ln.setColor(Color.argb(22, 255, 255, 255)); cv.drawRect(dp(c, 14), footTop, w - dp(c, 14), footTop + dp(c, 1), ln);
        String[][] foot = {
                {tx(d, "day", "Day {0}").replace("{0}", String.valueOf(d.optInt("streak", 0))), tx(d, "streak", "streak")},
                {d.optBoolean("gift") ? tx(d, "ready", "Claim") : "✓", tx(d, "gift", "daily gift")},
                {countdown(d.optLong("spot", 0) - System.currentTimeMillis()), tx(d, "spot", "to Spotlights")}};
        TextPaint fb = text(c, 13.5f, Color.WHITE, BOLD), fs = text(c, 11, Color.argb(165, 255, 255, 255), REG);
        float colW = (w - dp(c, 32)) / 3f;
        for (int k = 0; k < 3; k++) {
            float fx = dp(c, 16) + colW * k;
            cv.drawText(TextUtils.ellipsize(foot[k][0], fb, colW - dp(c, 6), TextUtils.TruncateAt.END).toString(), fx, footTop + dp(c, 24), fb);
            cv.drawText(TextUtils.ellipsize(foot[k][1], fs, colW - dp(c, 6), TextUtils.TruncateAt.END).toString(), fx, footTop + dp(c, 41), fs);
        }
        return bm;
    }

    static String countdown(long ms) {
        if (ms <= 0) return "Now";
        long h = ms / 3600000L, d = h / 24; h %= 24;
        if (d > 0) return d + "d " + h + "h";
        long m = (ms / 60000L) % 60; return h + "h " + m + "m";
    }

    static void empty(Canvas cv, Context c, int w, int h) {
        TextPaint t = text(c, 14, Color.WHITE, MED); t.setTextAlign(Paint.Align.CENTER);
        cv.drawText("Neon Muse", w / 2f, h / 2f - dp(c, 4), t);
        TextPaint s = text(c, 12, Color.argb(170, 255, 255, 255), REG); s.setTextAlign(Paint.Align.CENTER);
        cv.drawText("Open the game once to meet your Muse here", w / 2f, h / 2f + dp(c, 16), s);
    }

    // ===================== Steps & Companion =====================
    /** Where the heart button sits; widget_steps.xml puts its tap target exactly here (centre 29dp from the right, 55dp from the bottom). */
    static final float HEART_DP = 34, HEART_RIGHT_DP = 29, HEART_BOTTOM_DP = 55;

    static Bitmap steps(Context c, int w, int h, boolean heartPop) {
        Bitmap bm = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        JSONObject d = WidgetStore.data(c);
        float R = Math.min(dp(c, 26), Math.min(w, h) / 5f);
        card(cv, c, w, h, R, CYAN);
        long steps = WidgetStore.stepsToday(c);
        if (d != null && WidgetStore.today().equals(d.optString("day"))) steps = Math.max(steps, d.optLong("steps", 0));
        long goal = d == null ? 5000 : Math.max(1, d.optLong("goal", 5000));
        JSONObject p = d == null ? null : d.optJSONObject("pet"), e = d == null ? null : d.optJSONObject("egg");
        boolean compact = w < dp(c, 140) || h < dp(c, 140);
        float pad = dp(c, compact ? 9 : 13), sw = dp(c, compact ? 5 : 7);
        float hs = dp(c, HEART_DP), hcx = w - dp(c, HEART_RIGHT_DP), hcy = h - dp(c, HEART_BOTTOM_DP);
        float eggH = e != null ? dp(c, compact ? 22 : 27) : 0;

        // the ring, kept clear of the heart button
        float areaB = h - pad - eggH;
        float ringD = Math.min(areaB - pad, (w - pad * 2) * (compact ? 0.62f : 0.54f));
        if (p != null) ringD = Math.min(ringD, Math.max(hcx - hs / 2 - dp(c, 3) - pad, (hcy - hs / 2 - dp(c, 3)) - pad));
        RectF rr = new RectF(pad + sw / 2, pad + sw / 2, pad + ringD - sw / 2, pad + ringD - sw / 2);
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG); ring.setStyle(Paint.Style.STROKE); ring.setStrokeWidth(sw); ring.setStrokeCap(Paint.Cap.ROUND);
        ring.setColor(Color.argb(30, 255, 255, 255)); cv.drawArc(rr, 0, 360, false, ring);
        float frac = Math.min(1f, steps / (float) goal);
        ring.setShader(new LinearGradient(rr.left, rr.bottom, rr.right, rr.top, CYAN, steps >= goal ? GOLD : PINK, Shader.TileMode.CLAMP));
        if (frac > 0) cv.drawArc(rr, -90, Math.max(4, 360 * frac), false, ring);
        // the count, sized to sit inside the ring
        float inner = ringD - sw * 2 - dp(c, 8);
        String num = String.format(java.util.Locale.getDefault(), "%,d", steps);
        TextPaint big = text(c, 19, Color.WHITE, BOLD); big.setTextAlign(Paint.Align.CENTER);
        while (big.measureText(num) > inner * 0.92f && big.getTextSize() > dp(c, 8)) big.setTextSize(big.getTextSize() * 0.94f);
        String of = tx(d, "steps", "of {0}").replace("{0}", String.format(java.util.Locale.getDefault(), "%,d", goal));
        TextPaint sm = text(c, 10.5f, Color.argb(175, 255, 255, 255), REG); sm.setTextAlign(Paint.Align.CENTER);
        while (sm.measureText(of) > inner * 0.88f && sm.getTextSize() > dp(c, 7)) sm.setTextSize(sm.getTextSize() * 0.94f);
        boolean showOf = sm.measureText(of) <= inner * 0.92f;
        float numY = rr.centerY() + big.getTextSize() * (showOf ? 0.18f : 0.36f);
        cv.drawText(num, rr.centerX(), numY, big);
        if (showOf) cv.drawText(of, rr.centerX(), numY + sm.getTextSize() * 1.3f, sm);

        // the companion beside the ring, or the egg when nothing has hatched yet
        float colL = pad + ringD + dp(c, 4), colR = w - pad;
        float colB = p != null ? hcy - hs / 2 - dp(c, 2) : areaB - dp(c, 2);
        RectF pb = new RectF(colL, pad, colR, Math.max(pad + dp(c, 10), colB));
        if (p != null) {   // wide and short: the space left of the heart can be roomier than the space above it
            RectF side = new RectF(colL, pad, hcx - hs / 2 - dp(c, 6), hcy - dp(c, 11));
            if (Math.min(side.width(), side.height()) > Math.min(pb.width(), pb.height())) pb = side;
        }
        Bitmap pet = WidgetStore.image(c, "pet");
        if (pb.width() >= dp(c, 36) && pb.height() >= dp(c, 30)) {
            if (p != null && pet != null) drawFit(cv, pet, pb);
            else if (e != null) egg(cv, c, pb);
        }
        if (p != null) {
            // its name and mood, left of the heart
            float lr = hcx - hs / 2 - dp(c, 7), ll = (pad + ringD > hcy - dp(c, 8)) ? colL : pad;
            TextPaint pm = text(c, 11, Color.rgb(255, 210, 242), MED); pm.setTextAlign(Paint.Align.RIGHT);
            String lab = p.optString("nm") + (p.optString("mood").isEmpty() ? "" : " · " + p.optString("mood"));
            if (lr - ll >= dp(c, 34)) cv.drawText(TextUtils.ellipsize(lab, pm, lr - ll, TextUtils.TruncateAt.END).toString(), lr, hcy + pm.getTextSize() * 0.36f, pm);
            Paint hb = new Paint(Paint.ANTI_ALIAS_FLAG); hb.setColor(Color.argb(heartPop ? 120 : 60, 255, 95, 210)); cv.drawCircle(hcx, hcy, hs / 2, hb);
            hb.setStyle(Paint.Style.STROKE); hb.setStrokeWidth(dp(c, 1.2f)); hb.setColor(Color.argb(160, 255, 95, 210)); cv.drawCircle(hcx, hcy, hs / 2, hb);
            heart(cv, hcx, hcy + dp(c, 1), hs * 0.42f * (heartPop ? 1.12f : 1f), Color.WHITE);
            if (heartPop) {
                Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG); gp.setMaskFilter(new BlurMaskFilter(dp(c, 5), BlurMaskFilter.Blur.NORMAL)); gp.setColor(Color.argb(150, 255, 111, 208));
                cv.drawCircle(hcx, hcy, hs * 0.62f, gp);
                float[][] hp = {{-1.45f, -0.95f, 0.28f}, {-0.55f, -1.55f, 0.36f}, {0.2f, -1.15f, 0.25f}};
                for (float[] k : hp) heart(cv, hcx + k[0] * hs, hcy + k[1] * hs, hs * k[2], Color.argb(235, 255, 111, 208));
            }
        }

        // the egg's warmth
        if (e != null) {
            float by = h - pad - dp(c, 3);
            TextPaint el = text(c, compact ? 9.5f : 10.5f, Color.argb(180, 255, 255, 255), REG);
            String pct = e.optInt("p") + "%";
            float pr = w - pad - el.measureText(pct) - dp(c, 6);
            cv.drawText(TextUtils.ellipsize(e.optString("n"), el, pr - pad, TextUtils.TruncateAt.END).toString(), pad, by - dp(c, 9), el);
            el.setTextAlign(Paint.Align.RIGHT); cv.drawText(pct, w - pad, by - dp(c, 9), el);
            Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG); bar.setColor(Color.argb(30, 255, 255, 255));
            RectF b0 = new RectF(pad, by - dp(c, 3), w - pad, by + dp(c, 3)); cv.drawRoundRect(b0, dp(c, 3), dp(c, 3), bar);
            bar.setShader(new LinearGradient(b0.left, 0, b0.right, 0, GOLD, Color.rgb(255, 143, 208), Shader.TileMode.CLAMP));
            float fw = b0.width() * Math.min(1f, e.optInt("p") / 100f);
            if (fw > 0) cv.drawRoundRect(new RectF(b0.left, b0.top, b0.left + Math.max(fw, b0.height()), b0.bottom), dp(c, 3), dp(c, 3), bar);
        }
        return bm;
    }

    /** A warm egg with a little sparkle, for when no companion has hatched yet. */
    static void egg(Canvas cv, Context c, RectF box) {
        float eh = Math.min(box.height() * 0.8f, box.width() * 0.95f), ew = eh * 0.78f, cx = box.centerX(), cy = box.centerY();
        Path e = new Path(); float t = cy - eh / 2, b = cy + eh / 2;
        e.moveTo(cx, t);
        e.cubicTo(cx + ew * 0.62f, t, cx + ew * 0.62f, b, cx, b);
        e.cubicTo(cx - ew * 0.62f, b, cx - ew * 0.62f, t, cx, t);
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setMaskFilter(new BlurMaskFilter(dp(c, 8), BlurMaskFilter.Blur.NORMAL)); g.setColor(Color.argb(90, 255, 160, 120)); cv.drawPath(e, g);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(cx - ew / 2, t, cx + ew / 2, b, Color.rgb(255, 232, 170), Color.rgb(255, 143, 208), Shader.TileMode.CLAMP));
        cv.drawPath(e, p);
        icon(cv, c, IC_SPARK, cx - ew * 0.18f, cy - eh * 0.16f, Color.argb(220, 255, 255, 255));
    }

    static void heart(Canvas cv, float cx, float cy, float s, int col) {
        Path p = new Path();
        p.moveTo(cx, cy + s * 0.9f);
        p.cubicTo(cx - s * 1.4f, cy - s * 0.1f, cx - s * 0.7f, cy - s * 1.2f, cx, cy - s * 0.45f);
        p.cubicTo(cx + s * 0.7f, cy - s * 1.2f, cx + s * 1.4f, cy - s * 0.1f, cx, cy + s * 0.9f);
        Paint pp = new Paint(Paint.ANTI_ALIAS_FLAG); pp.setColor(col); cv.drawPath(p, pp);
    }
}
