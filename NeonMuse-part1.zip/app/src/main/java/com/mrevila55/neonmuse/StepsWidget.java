package com.mrevila55.neonmuse;

import android.Manifest;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Steps & Companion (2x2): today's steps against your goal, how warm your egg is, and your companion.
 * Tap the heart to give your companion a cuddle; the game collects the cuddles the next time you open it.
 */
public class StepsWidget extends WidgetBase {
    static final String ACTION_CUDDLE = "com.mrevila55.neonmuse.CUDDLE";

    @Override
    public void onReceive(Context c, Intent i) {
        if (i != null && ACTION_CUDDLE.equals(i.getAction())) {
            WidgetStore.addCuddle(c);
            int id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
            if (id >= 0) render(c, AppWidgetManager.getInstance(c), new int[]{id}, i);
            return;
        }
        super.onReceive(c, i);
    }

    @Override
    long settleMs(Intent why) { return why != null && ACTION_CUDDLE.equals(why.getAction()) ? 2400 : 0; }

    @Override
    Bitmap draw(Context c, int w, int h, Intent why) {
        readSensor(c);
        boolean pop = why != null && ACTION_CUDDLE.equals(why.getAction());
        return WidgetArt.steps(c, w, h, pop);
    }

    @Override
    RemoteViews views(Context c, int id, Bitmap art) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_steps);
        v.setImageViewBitmap(R.id.w_art, art);
        v.setContentDescription(R.id.w_art, WidgetStore.stepsToday(c) + " steps today");
        v.setOnClickPendingIntent(R.id.w_root, openGame(c, "pets", 300 + id));
        org.json.JSONObject d = WidgetStore.data(c);
        boolean pet = d != null && d.optJSONObject("pet") != null;
        v.setViewVisibility(R.id.w_heart, pet ? android.view.View.VISIBLE : android.view.View.GONE);
        Intent cu = new Intent(c, StepsWidget.class).setAction(ACTION_CUDDLE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        v.setOnClickPendingIntent(R.id.w_heart, PendingIntent.getBroadcast(c, 500 + id, cu, flags()));
        return v;
    }

    @Override int defW() { return 110; }
    @Override int defH() { return 110; }

    /** A quick look at the phone's step counter, when step tracking is on (the game asks for the permission). */
    private static void readSensor(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 29 && c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) return;
            SensorManager sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
            Sensor s = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            if (s == null) return;
            final CountDownLatch got = new CountDownLatch(1);
            final long[] raw = {-1};
            SensorEventListener l = new SensorEventListener() {
                @Override public void onSensorChanged(SensorEvent e) { if (e.values.length > 0) { raw[0] = (long) e.values[0]; got.countDown(); } }
                @Override public void onAccuracyChanged(Sensor x, int a) { }
            };
            if (!sm.registerListener(l, s, SensorManager.SENSOR_DELAY_NORMAL, sensorThread())) return;
            got.await(1500, TimeUnit.MILLISECONDS);
            sm.unregisterListener(l);
            if (raw[0] >= 0) WidgetStore.phoneRaw(c, raw[0]);
        } catch (Throwable ignored) { }
    }
}
