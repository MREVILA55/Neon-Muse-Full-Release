package com.mrevila55.neonmuse;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.widget.RemoteViews;

/**
 * The Muse widget. Medium (4x2): your Muse, her mood and bond, what she's saying right now and what's waiting for you.
 * Large (4x4) adds the latest group chat messages, your streak, the daily gift and the Spotlight countdown.
 * With Discreet widgets on (Settings, Game) it shows only her face in a small circle.
 */
public class MuseWidget extends WidgetBase {
    @Override
    Bitmap draw(Context c, int w, int h, Intent why) { return WidgetArt.muse(c, w, h); }

    @Override
    RemoteViews views(Context c, int id, Bitmap art) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_muse);
        v.setImageViewBitmap(R.id.w_art, art);
        v.setContentDescription(R.id.w_art, WidgetArt.opt(WidgetStore.data(c), "name", c.getString(R.string.app_name)));
        v.setOnClickPendingIntent(R.id.w_root, openGame(c, "muse:today", 100 + id));
        return v;
    }

    @Override int defW() { return 250; }
    @Override int defH() { return 110; }
}
