package com.mrevila55.neonmuse;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.widget.RemoteViews;

/**
 * Shared plumbing for the home screen widgets: works out each widget's real size in pixels, draws it off the main thread
 * and keeps the picture inside the memory Android allows for widgets.
 */
abstract class WidgetBase extends AppWidgetProvider {
    private static HandlerThread thread, sensors;

    static synchronized Handler worker() {
        if (thread == null) { thread = new HandlerThread("nm-widgets"); thread.start(); }
        return new Handler(thread.getLooper());
    }

    /** Sensor readings arrive here, so the drawing thread can wait for them. */
    static synchronized Handler sensorThread() {
        if (sensors == null) { sensors = new HandlerThread("nm-widget-sensors"); sensors.start(); }
        return new Handler(sensors.getLooper());
    }

    /** A widget that animates (the cuddle hearts) draws a second frame after this many ms; 0 for none. */
    long settleMs(Intent why) { return 0; }

    /** Draws the picture for one widget at w x h pixels. */
    abstract Bitmap draw(Context c, int w, int h, Intent why);

    /** The layout and anything clickable on it besides "open the game". */
    abstract RemoteViews views(Context c, int id, Bitmap art);

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { render(c, m, ids, null); }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) { render(c, m, new int[]{id}, null); }

    void render(Context c, AppWidgetManager m, int[] ids, Intent why) {
        final PendingResult pr = goAsync();
        final Context app = c.getApplicationContext();
        worker().post(() -> {
            try {
                for (int id : ids) one(app, m, id, why);
                long wait = settleMs(why);
                if (wait > 0) { Thread.sleep(wait); for (int id : ids) one(app, m, id, null); }
            }
            catch (Throwable ignored) { }
            finally { try { pr.finish(); } catch (Throwable ignored) { } }
        });
    }

    private void one(Context c, AppWidgetManager m, int id, Intent why) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        Bundle o = m.getAppWidgetOptions(id);
        // portrait uses the narrow width and the tall height; landscape the other way round
        boolean land = c.getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        int wDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int hDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (wDp <= 0 || hDp <= 0) { wDp = defW(); hDp = defH(); }
        float scale = dm.density;
        // Android allows widget pictures up to 1.5 screens of memory; stay well under half of that
        long budget = (long) dm.widthPixels * dm.heightPixels * 4L * 3 / 4;
        while ((long) (wDp * scale) * (long) (hDp * scale) * 4L > budget && scale > 1f) scale *= 0.85f;
        int w = Math.round(wDp * scale), h = Math.round(hDp * scale);
        Bitmap art = draw(scaled(c, scale / dm.density), w, h, why);
        try { m.updateAppWidget(id, views(c, id, art)); }
        catch (RuntimeException tooBig) {   // a launcher with a smaller limit: send a lighter picture
            Bitmap small = Bitmap.createScaledBitmap(art, Math.max(1, w * 2 / 3), Math.max(1, h * 2 / 3), true);
            try { m.updateAppWidget(id, views(c, id, small)); } catch (RuntimeException ignored) { }
        }
    }

    int defW() { return 250; }
    int defH() { return 110; }

    /** When the picture has to be drawn smaller than the screen density, every dp shrinks with it. */
    private static Context scaled(Context c, float f) {
        if (Math.abs(f - 1f) < 0.01f) return c;
        android.content.res.Configuration cf = new android.content.res.Configuration(c.getResources().getConfiguration());
        cf.densityDpi = Math.max(80, Math.round(cf.densityDpi * f));
        return c.createConfigurationContext(cf);
    }

    static PendingIntent openGame(Context c, String deep, int req) {
        Intent i = new Intent(c, MainActivity.class).setAction(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (deep != null) i.putExtra("deep", deep);
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Redraws every widget (after the game saves a new snapshot, the watch sends steps, or a cuddle). */
    static void refreshAll(Context c) {
        Context app = c.getApplicationContext();
        AppWidgetManager m = AppWidgetManager.getInstance(app);
        for (Class<?> k : new Class<?>[]{MuseWidget.class, StepsWidget.class}) {
            int[] ids = m.getAppWidgetIds(new ComponentName(app, k));
            if (ids == null || ids.length == 0) continue;
            Intent u = new Intent(app, k).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            app.sendBroadcast(u);
        }
    }

    static boolean any(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> k : new Class<?>[]{MuseWidget.class, StepsWidget.class}) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, k));
            if (ids != null && ids.length > 0) return true;
        }
        return false;
    }

    static int flags() { return PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE; }
    static boolean s31() { return Build.VERSION.SDK_INT >= 31; }
}
