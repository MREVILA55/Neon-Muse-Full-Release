package com.mrevila55.neonmuse;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.WearableListenerService;

/** Watch to phone: the steps your Galaxy Watch counted today. The game uses the higher of the phone's and the watch's count. */
public class WatchListener extends WearableListenerService {
    @Override
    public void onDataChanged(DataEventBuffer events) {
        boolean changed = false;
        for (DataEvent e : events) {
            if (e.getType() != DataEvent.TYPE_CHANGED) continue;
            if (!WearSync.PATH_STEPS.equals(e.getDataItem().getUri().getPath())) continue;
            DataMap m = DataMapItem.fromDataItem(e.getDataItem()).getDataMap();
            String day = m.getString("day", "");
            long steps = m.getLong("steps", 0);
            if (WidgetStore.today().equals(day) && steps > 0) { WidgetStore.watchSteps(this, day, steps); changed = true; }
        }
        if (changed) WidgetBase.refreshAll(this);
    }
}
